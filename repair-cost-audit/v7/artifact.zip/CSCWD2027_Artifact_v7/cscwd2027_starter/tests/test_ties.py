import importlib.util
import itertools
import unittest

from rework.core import Instance, Problem, generate


@unittest.skipUnless(importlib.util.find_spec("scipy"), "optional SciPy required")
class TieEnvelopeTests(unittest.TestCase):
    def test_tie_can_fully_explain_apparent_loss(self):
        from rework.milp import additive_tie_envelope
        ins = Instance("tie_example", [1.] * 4, [[0, 1], [2, 3]],
                       [["e0", "e2"], ["e1"], ["e3"]], [1., 1., 1.], {})
        result = additive_tie_envelope(Problem(ins), timeout=5)
        self.assertTrue(result["range_certified"])
        self.assertAlmostEqual(result["additive_optimum"], 4.)
        self.assertAlmostEqual(result["best_union_cost"], 3.)
        self.assertAlmostEqual(result["worst_union_cost"], 4.)

    def test_unique_model_mismatch_survives_tie_handling(self):
        from rework.milp import additive_tie_envelope
        ins = Instance("strict_example", [1.] * 4, [[0, 1], [2, 3]],
                       [["e0", "e2"], ["e1"], ["e3"]], [8., 5., 5.], {})
        result = additive_tie_envelope(Problem(ins), timeout=5)
        self.assertTrue(result["range_certified"])
        self.assertAlmostEqual(result["best_union_cost"], 12.)
        self.assertAlmostEqual(result["worst_union_cost"], 12.)

    def test_range_matches_independent_enumeration(self):
        from rework.milp import additive_tie_envelope
        for seed in range(5):
            ins = generate(seed=seed, n=8)
            p = Problem(ins)
            costs = []
            for bits in itertools.product((False, True), repeat=8):
                removed = {i for i, b in enumerate(bits) if b}
                if p.feasible(removed):
                    costs.append((p.cost(removed, "additive"), p.cost(removed, "union")))
            minimum = min(a for a, _ in costs)
            union = [u for a, u in costs if abs(a - minimum) < 1e-8]
            result = additive_tie_envelope(p, timeout=5)
            self.assertTrue(result["range_certified"])
            self.assertAlmostEqual(result["best_union_cost"], min(union))
            self.assertAlmostEqual(result["worst_union_cost"], max(union))


if __name__ == "__main__":
    unittest.main()
