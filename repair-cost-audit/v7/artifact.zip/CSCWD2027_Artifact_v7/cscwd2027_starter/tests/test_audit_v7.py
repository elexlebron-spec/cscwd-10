import itertools,unittest
from rework.core import Instance,Problem
from rework.tie_study import normalized
from extensions.audit_v7 import integer_vectors,integer_value,integer_audit,core_select

class RevisionAuditTests(unittest.TestCase):
    def instance(self):return Instance('check',[2,3,1],[[0,1],[1,2]],[['e0'],['e1'],['e2'],['a0','a1','a2']],[2,3,4,20],{})
    def test_integer_equivalence_at_all_prescribed_weights(self):
        ins=self.instance()
        for alpha in [.1,1.,10.]:
            _,_,scale=integer_vectors(ins,alpha);p=Problem(normalized(ins),alpha)
            for mask in range(8):
                r={i for i in range(3) if mask>>i&1}
                for model in ['additive','union']:self.assertAlmostEqual(integer_value(ins,r,alpha,model)/scale,p.cost(r,model),places=12)
    def test_core_baseline_matches_enumeration_with_shared_core(self):
        ins=self.instance();p=Problem(normalized(ins),1.)
        feasible=[{i for i in range(3) if m>>i&1} for m in range(8) if p.feasible({i for i in range(3) if m>>i&1})]
        row=core_select(ins,1.,'core',2.)
        self.assertTrue(row['certified'] and row['core_exact'])
        self.assertAlmostEqual(row['objective'],min(p.cost(r,'union') for r in feasible))
        self.assertAlmostEqual(row['model_value'],row['objective'])
    def test_integer_faces_and_partial_sharing_scope(self):
        ins=self.instance();row=integer_audit(ins,1.,2.)
        self.assertTrue(row['all_certified'])
        partial=Instance('partial',[1,1,1],[[0,1]],[['e0','e1']],[9],{})
        self.assertFalse(core_select(partial,1.,'core',2.)['core_exact'])
