import importlib.util
import unittest


@unittest.skipUnless(importlib.util.find_spec('skfem'),'optional scikit-fem required')
class SourceBeamChecks(unittest.TestCase):
    def test_reference_deflection_and_equilibrium(self):
        from extensions.beam_v4 import Beam,REFERENCE
        b=Beam(40,2);v,_,_,_=b.build(set(range(8)))
        self.assertLess(abs(v['a12']['tip_deflection']/REFERENCE['published_fem_tip']-1),.02)
        self.assertTrue(b.validate(v,set(range(8)),25.)['valid'])

    def test_uniform_thickness_scaling(self):
        import numpy as np
        from scipy.sparse.linalg import splu
        from extensions.beam_v4 import Beam
        b=Beam(40,2)
        a=splu(b.matrix([1.]*8)[b.free][:,b.free].tocsc()).solve(b.force[b.free])
        c=splu(b.matrix([2.]*8)[b.free][:,b.free].tocsc()).solve(b.force[b.free])
        self.assertTrue(np.allclose(a,2*c,rtol=1e-8,atol=1e-11))

    def test_volume_rules_match_all_subsets(self):
        from extensions.beam_v4 import DELTAS,make_instance
        from rework.core import Problem
        limit=25+.5*(25/8)*sum(DELTAS)
        ins=make_instance([1.]*13,[1.]*8,limit,{})
        p=Problem(ins)
        for mask in range(256):
            r={i for i in range(8) if mask>>i&1}
            volume=25+(25/8)*sum(DELTAS[i] for i in range(8) if i not in r)
            self.assertEqual(p.feasible(r),volume<=limit+1e-9)

    def test_shared_cache_matches_full_fields(self):
        import numpy as np
        from extensions.beam_v4 import Beam,make_instance
        from rework.core import Problem
        b=Beam(40,2);old,_,_,_=b.build(set())
        ins=make_instance([1.]*13,[1.]*8,28.,{})
        removed={0,2,5,7};affected=Problem(ins).affected(removed)
        a,_,_,executed=b.build(removed,old,affected);c,_,_,_=b.build(removed)
        self.assertTrue(np.allclose(a['a11'],c['a11'],rtol=1e-10,atol=1e-12))
        self.assertEqual(a['a12'],c['a12'])
        self.assertTrue(all(executed[i] for i in range(8,13)))
        self.assertEqual(sum(executed),len(removed)+5)


if __name__=='__main__':unittest.main()
