import unittest
from extensions.accounting_v5 import costs, residuals_disjoint


class AccountingContracts(unittest.TestCase):
    def test_unavoidable_core_changes_additive_selection_but_not_union(self):
        # A star conflict can be repaired by withdrawing the hub or all leaves.
        footprints=[{i,4} for i in range(4)]
        losses=[4.,1.,1.,1.]
        repairs=[{0},{1,2,3}]
        for k in [0.,.5,2.,20.]:
            scores=[costs(r,losses,[.1]*4+[k],footprints) for r in repairs]
            self.assertLess(scores[1][0],scores[0][0])
            self.assertAlmostEqual(scores[0][0],scores[0][2])
            self.assertAlmostEqual(scores[1][0],scores[1][2])
        self.assertLess(costs(repairs[1],losses,[.1]*4+[0.],footprints)[1],
                        costs(repairs[0],losses,[.1]*4+[0.],footprints)[1])
        self.assertGreater(costs(repairs[1],losses,[.1]*4+[2.],footprints)[1],
                           costs(repairs[0],losses,[.1]*4+[2.],footprints)[1])

    def test_correction_preserves_empty_choice_and_has_conditional_scope(self):
        self.assertEqual(costs(set(),[1.,1.],[2.],[{0},{0}]),(0.,0.,0.))
        footprints=[{0,2},{1,2},{3}]
        self.assertFalse(residuals_disjoint(footprints))
        union,additive,corrected=costs({0,1},[1.]*3,[1.,1.,10.,1.],footprints)
        self.assertEqual(additive,corrected)
        self.assertLess(union,corrected)  # Partial sharing still needs a union model.

    def test_disjoint_residual_condition_is_sufficient_for_every_subset(self):
        footprints=[{0,3,4},{1,3,4},{2,3,4}]
        self.assertTrue(residuals_disjoint(footprints))
        for mask in range(8):
            u,a,c=costs({i for i in range(3) if mask>>i&1},[1.,3.,2.],[1.,2.,4.,8.,16.],footprints,.7)
            self.assertAlmostEqual(u,c)


if __name__=='__main__':unittest.main()
