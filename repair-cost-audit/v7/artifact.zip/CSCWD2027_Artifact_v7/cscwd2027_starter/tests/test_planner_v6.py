import unittest
from extensions.planner_v6 import validate_plan


class PlanningProbeTests(unittest.TestCase):
    def test_two_branch_costs_and_shared_execution_once(self):
        a=['choose-a','shared-a']+['finish-a-%d'%i for i in range(4)]
        b=['choose-b']+['finish-b-%d'%i for i in range(4)]
        self.assertEqual(validate_plan(a,4,4),8)
        self.assertEqual(validate_plan(b,4,4),12)

    def test_incompatible_or_unmaterialized_plans_are_rejected(self):
        with self.assertRaises(AssertionError):validate_plan(['choose-a','finish-a-0'],1,4)
        with self.assertRaises(AssertionError):validate_plan(['choose-a','choose-b'],1,4)
        with self.assertRaises(AssertionError):validate_plan(['choose-b','finish-b-0'],2,4)


if __name__=='__main__':unittest.main()
