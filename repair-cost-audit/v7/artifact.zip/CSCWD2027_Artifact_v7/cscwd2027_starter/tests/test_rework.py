import itertools
import random
import unittest

from rework.core import Instance, Problem, exact, generate, greedy, multistart, replay_check


class RepairTests(unittest.TestCase):
    def test_shared_rework_counterexample(self):
        ins = Instance("counterexample", [1., 1., 1., 1.], [[0, 1], [2, 3]],
                       [["e0", "e2"], ["e1"], ["e3"]], [8, 5, 5], {})
        p = Problem(ins)
        self.assertEqual(p.cost({0, 2}), 10)
        self.assertEqual(p.cost({0, 2}, "additive"), 18)
        self.assertEqual(greedy(p), {1, 3})
        self.assertEqual(multistart(p), {0, 2})
        self.assertEqual(exact(p)[0], {0, 2})
        self.assertTrue(replay_check(ins, {0, 2})["replay_equal"])

    def test_exact_against_independent_enumeration(self):
        for seed in range(15):
            ins = generate(seed=seed, n=8)
            p = Problem(ins)
            subsets = [set(i for i, bit in enumerate(bits) if bit)
                       for bits in itertools.product((0, 1), repeat=8)]
            for model in ("union", "additive"):
                oracle = min(p.cost(s, model) for s in subsets if p.feasible(s))
                solution, status = exact(p, model, timeout=10)
                self.assertEqual(status, "optimal")
                self.assertEqual(p.cost(solution, model), oracle)

    def test_disjoint_cost_identity(self):
        p = Problem(generate(n=12, family="disjoint", sharing=0))
        for seed in range(10):
            removed = set(random.Random(seed).sample(range(12), 5))
            self.assertEqual(p.cost(removed), p.cost(removed, "additive"))

    def test_no_conflicts_requires_no_repair(self):
        ins = generate(n=8, density=0)
        p = Problem(ins)
        self.assertEqual(greedy(p), set())
        self.assertEqual(multistart(p), set())
        self.assertEqual(exact(p), (set(), "optimal"))

    def test_selective_replay_matches_full(self):
        for family in ("chain", "hub", "mixed", "disjoint"):
            for seed in range(5):
                ins = generate(seed=seed, n=12, family=family)
                solution = multistart(Problem(ins))
                result = replay_check(ins, solution)
                self.assertTrue(result["replay_equal"])
                self.assertTrue(result["final_valid"])

    def test_timeout_is_not_optimal(self):
        solution, status = exact(Problem(generate(n=12)), timeout=0)
        self.assertEqual(status, "timeout_feasible")
        self.assertTrue(Problem(generate(n=12)).feasible(solution))

    def test_dag_validation(self):
        ins = Instance("cycle", [1], [[0]], [["a0"]], [1], {})
        with self.assertRaises(ValueError):
            ins.validate()

    def test_reproducible_inputs(self):
        self.assertEqual(generate(seed=2), generate(seed=2))


if __name__ == "__main__":
    unittest.main()
