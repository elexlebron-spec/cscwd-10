import importlib.util
import itertools
import unittest

from rework.core import Instance, Problem, generate, solve
from rework.workflow import CabinetWorkflow, prepare


class ControlledGeneratorTests(unittest.TestCase):
    def test_sharing_changes_only_edges(self):
        for family in ("mixed", "hub", "chain"):
            for seed in (100, 101, 102, 103, 104):
                for n in (12, 20, 40):
                    low = generate(seed=seed, n=n, sharing=.3, family=family)
                    high = generate(seed=seed, n=n, sharing=.7, family=family)
                    self.assertEqual(low.losses, high.losses)
                    self.assertEqual(low.conflicts, high.conflicts)
                    self.assertEqual(low.work, high.work)
                    for a, b in zip(low.parents, high.parents):
                        self.assertLessEqual(set(a), set(b))

    def test_normalized_objective_identity(self):
        ins = generate(n=8)
        result = solve(ins, "union_greedy", alpha=.1, normalize=True)
        expected = result["intent_loss_fraction"] + .1 * result["estimated_rework_fraction"]
        self.assertAlmostEqual(result["objective"], expected)


class SemanticWorkflowTests(unittest.TestCase):
    def test_independent_validator_matches_induced_rules(self):
        for seed in (200, 201, 202):
            w = CabinetWorkflow(seed)
            ins, old, setup = prepare(w, 3)
            p = Problem(ins)
            self.assertTrue(w.independent_validate(set())["valid"])
            self.assertFalse(w.independent_validate(set(range(8)))["valid"])
            for bits in itertools.product((False, True), repeat=8):
                removed = {i for i, bit in enumerate(bits) if bit}
                direct = w.independent_validate(set(range(8)) - removed)
                self.assertEqual(p.feasible(removed), direct["valid"])
                self.assertLess(direct["balance_residual_w"], 1e-10)

    def test_semantic_cache_equals_full_for_every_repair(self):
        w = CabinetWorkflow(200)
        ins, old, _ = prepare(w, 3)
        p = Problem(ins)
        for bits in itertools.product((False, True), repeat=8):
            removed = {i for i, bit in enumerate(bits) if bit}
            cached, _, _ = w.build(removed, old, p.affected(removed))
            full, _, _ = w.build(removed)
            self.assertEqual(cached, full)


@unittest.skipUnless(importlib.util.find_spec("scipy"), "optional SciPy MILP environment required")
class MilpTests(unittest.TestCase):
    def test_milp_equals_independent_exhaustive_optimum(self):
        for seed in range(5):
            ins = generate(seed=seed, n=8)
            p = Problem(ins)
            for model in ("additive", "union"):
                values = []
                for bits in itertools.product((False, True), repeat=8):
                    removed = {i for i, bit in enumerate(bits) if bit}
                    if p.feasible(removed):
                        values.append(p.cost(removed, model))
                result = solve(ins, "milp_" + model, timeout=5)
                self.assertEqual(result["status"], "optimal")
                self.assertAlmostEqual(result["optimized_model_value"], min(values))

    def test_zero_alpha_and_no_conflicts(self):
        ins = generate(n=8, density=0)
        result = solve(ins, "milp_union", alpha=0., normalize=True)
        self.assertEqual(result["removed"], [])
        self.assertEqual(result["objective"], 0)
        self.assertEqual(result["status"], "optimal")

    def test_limit_is_not_an_optimality_claim(self):
        result = solve(generate(n=24), "milp_union", timeout=0)
        self.assertNotEqual(result["status"], "optimal")
        self.assertTrue(result["feasible"])


if __name__ == "__main__":
    unittest.main()
