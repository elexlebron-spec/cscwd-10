begin_version
3
end_version
begin_metric
1
end_metric
9
begin_variable
var0
-1
2
Atom selected()
Atom undecided()
end_variable
begin_variable
var1
-1
2
Atom g7()
NegatedAtom g7()
end_variable
begin_variable
var2
-1
2
Atom g6()
NegatedAtom g6()
end_variable
begin_variable
var3
-1
2
Atom g5()
NegatedAtom g5()
end_variable
begin_variable
var4
-1
2
Atom g4()
NegatedAtom g4()
end_variable
begin_variable
var5
-1
2
Atom g3()
NegatedAtom g3()
end_variable
begin_variable
var6
-1
2
Atom g2()
NegatedAtom g2()
end_variable
begin_variable
var7
-1
2
Atom g1()
NegatedAtom g1()
end_variable
begin_variable
var8
-1
2
Atom g0()
NegatedAtom g0()
end_variable
0
begin_state
1
1
1
1
1
1
1
1
1
end_state
begin_goal
8
1 0
2 0
3 0
4 0
5 0
6 0
7 0
8 0
end_goal
30
begin_operator
choose-126 
0
3
0 8 -1 0
0 1 -1 0
0 0 1 0
750015
end_operator
begin_operator
choose-127 
0
2
0 1 -1 0
0 0 1 0
875030
end_operator
begin_operator
choose-159 
0
3
0 3 -1 0
0 2 -1 0
0 0 1 0
750027
end_operator
begin_operator
choose-174 
0
4
0 8 -1 0
0 4 -1 0
0 2 -1 0
0 0 1 0
625013
end_operator
begin_operator
choose-175 
0
3
0 4 -1 0
0 2 -1 0
0 0 1 0
750028
end_operator
begin_operator
choose-186 
0
4
0 8 -1 0
0 6 -1 0
0 2 -1 0
0 0 1 0
625013
end_operator
begin_operator
choose-187 
0
3
0 6 -1 0
0 2 -1 0
0 0 1 0
750028
end_operator
begin_operator
choose-190 
0
3
0 8 -1 0
0 2 -1 0
0 0 1 0
750015
end_operator
begin_operator
choose-191 
0
2
0 2 -1 0
0 0 1 0
875030
end_operator
begin_operator
choose-206 
0
4
0 8 -1 0
0 4 -1 0
0 3 -1 0
0 0 1 0
625011
end_operator
begin_operator
choose-207 
0
3
0 4 -1 0
0 3 -1 0
0 0 1 0
750026
end_operator
begin_operator
choose-219 
0
3
0 6 -1 0
0 3 -1 0
0 0 1 0
750026
end_operator
begin_operator
choose-222 
0
3
0 8 -1 0
0 3 -1 0
0 0 1 0
750013
end_operator
begin_operator
choose-223 
0
2
0 3 -1 0
0 0 1 0
875028
end_operator
begin_operator
choose-231 
0
3
0 5 -1 0
0 4 -1 0
0 0 1 0
750027
end_operator
begin_operator
choose-234 
0
4
0 8 -1 0
0 6 -1 0
0 4 -1 0
0 0 1 0
625012
end_operator
begin_operator
choose-235 
0
3
0 6 -1 0
0 4 -1 0
0 0 1 0
750027
end_operator
begin_operator
choose-237 
0
3
0 7 -1 0
0 4 -1 0
0 0 1 0
750024
end_operator
begin_operator
choose-238 
0
3
0 8 -1 0
0 4 -1 0
0 0 1 0
750014
end_operator
begin_operator
choose-239 
0
2
0 4 -1 0
0 0 1 0
875029
end_operator
begin_operator
choose-246 
0
3
0 8 -1 0
0 5 -1 0
0 0 1 0
750014
end_operator
begin_operator
choose-247 
0
2
0 5 -1 0
0 0 1 0
875029
end_operator
begin_operator
choose-249 
0
3
0 7 -1 0
0 6 -1 0
0 0 1 0
750024
end_operator
begin_operator
choose-250 
0
3
0 8 -1 0
0 6 -1 0
0 0 1 0
750014
end_operator
begin_operator
choose-251 
0
2
0 6 -1 0
0 0 1 0
875029
end_operator
begin_operator
choose-252 
0
3
0 8 -1 0
0 7 -1 0
0 0 1 0
750011
end_operator
begin_operator
choose-253 
0
2
0 7 -1 0
0 0 1 0
875026
end_operator
begin_operator
choose-254 
0
2
0 8 -1 0
0 0 1 0
875016
end_operator
begin_operator
choose-255 
0
1
0 0 1 0
1000031
end_operator
begin_operator
materialize-common 
1
0 0
8
0 8 -1 0
0 7 -1 0
0 6 -1 0
0 5 -1 0
0 4 -1 0
0 3 -1 0
0 2 -1 0
0 1 -1 0
999969
end_operator
0
