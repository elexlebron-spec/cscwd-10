begin_version
3
end_version
begin_metric
1
end_metric
9
begin_variable
var0
-1
2
Atom selected()
Atom undecided()
end_variable
begin_variable
var1
-1
2
Atom g7()
NegatedAtom g7()
end_variable
begin_variable
var2
-1
2
Atom g6()
NegatedAtom g6()
end_variable
begin_variable
var3
-1
2
Atom g5()
NegatedAtom g5()
end_variable
begin_variable
var4
-1
2
Atom g4()
NegatedAtom g4()
end_variable
begin_variable
var5
-1
2
Atom g3()
NegatedAtom g3()
end_variable
begin_variable
var6
-1
2
Atom g2()
NegatedAtom g2()
end_variable
begin_variable
var7
-1
2
Atom g1()
NegatedAtom g1()
end_variable
begin_variable
var8
-1
2
Atom g0()
NegatedAtom g0()
end_variable
0
begin_state
1
1
1
1
1
1
1
1
1
end_state
begin_goal
8
1 0
2 0
3 0
4 0
5 0
6 0
7 0
8 0
end_goal
135
begin_operator
choose-102 
0
5
0 8 -1 0
0 5 -1 0
0 4 -1 0
0 1 -1 0
0 0 1 0
500011
end_operator
begin_operator
choose-103 
0
4
0 5 -1 0
0 4 -1 0
0 1 -1 0
0 0 1 0
625026
end_operator
begin_operator
choose-106 
0
5
0 8 -1 0
0 6 -1 0
0 4 -1 0
0 1 -1 0
0 0 1 0
500011
end_operator
begin_operator
choose-107 
0
4
0 6 -1 0
0 4 -1 0
0 1 -1 0
0 0 1 0
625026
end_operator
begin_operator
choose-108 
0
5
0 8 -1 0
0 7 -1 0
0 4 -1 0
0 1 -1 0
0 0 1 0
500008
end_operator
begin_operator
choose-109 
0
4
0 7 -1 0
0 4 -1 0
0 1 -1 0
0 0 1 0
625023
end_operator
begin_operator
choose-110 
0
4
0 8 -1 0
0 4 -1 0
0 1 -1 0
0 0 1 0
625013
end_operator
begin_operator
choose-111 
0
3
0 4 -1 0
0 1 -1 0
0 0 1 0
750028
end_operator
begin_operator
choose-115 
0
4
0 6 -1 0
0 5 -1 0
0 1 -1 0
0 0 1 0
625026
end_operator
begin_operator
choose-118 
0
4
0 8 -1 0
0 5 -1 0
0 1 -1 0
0 0 1 0
625013
end_operator
begin_operator
choose-119 
0
3
0 5 -1 0
0 1 -1 0
0 0 1 0
750028
end_operator
begin_operator
choose-120 
0
5
0 8 -1 0
0 7 -1 0
0 6 -1 0
0 1 -1 0
0 0 1 0
500008
end_operator
begin_operator
choose-121 
0
4
0 7 -1 0
0 6 -1 0
0 1 -1 0
0 0 1 0
625023
end_operator
begin_operator
choose-122 
0
4
0 8 -1 0
0 6 -1 0
0 1 -1 0
0 0 1 0
625013
end_operator
begin_operator
choose-123 
0
3
0 6 -1 0
0 1 -1 0
0 0 1 0
750028
end_operator
begin_operator
choose-124 
0
4
0 8 -1 0
0 7 -1 0
0 1 -1 0
0 0 1 0
625010
end_operator
begin_operator
choose-125 
0
3
0 7 -1 0
0 1 -1 0
0 0 1 0
750025
end_operator
begin_operator
choose-126 
0
3
0 8 -1 0
0 1 -1 0
0 0 1 0
750015
end_operator
begin_operator
choose-127 
0
2
0 1 -1 0
0 0 1 0
875030
end_operator
begin_operator
choose-135 
0
5
0 5 -1 0
0 4 -1 0
0 3 -1 0
0 2 -1 0
0 0 1 0
500023
end_operator
begin_operator
choose-138 
0
6
0 8 -1 0
0 6 -1 0
0 4 -1 0
0 3 -1 0
0 2 -1 0
0 0 1 0
375008
end_operator
begin_operator
choose-139 
0
5
0 6 -1 0
0 4 -1 0
0 3 -1 0
0 2 -1 0
0 0 1 0
500023
end_operator
begin_operator
choose-141 
0
5
0 7 -1 0
0 4 -1 0
0 3 -1 0
0 2 -1 0
0 0 1 0
500020
end_operator
begin_operator
choose-142 
0
5
0 8 -1 0
0 4 -1 0
0 3 -1 0
0 2 -1 0
0 0 1 0
500010
end_operator
begin_operator
choose-143 
0
4
0 4 -1 0
0 3 -1 0
0 2 -1 0
0 0 1 0
625025
end_operator
begin_operator
choose-150 
0
5
0 8 -1 0
0 5 -1 0
0 3 -1 0
0 2 -1 0
0 0 1 0
500010
end_operator
begin_operator
choose-151 
0
4
0 5 -1 0
0 3 -1 0
0 2 -1 0
0 0 1 0
625025
end_operator
begin_operator
choose-153 
0
5
0 7 -1 0
0 6 -1 0
0 3 -1 0
0 2 -1 0
0 0 1 0
500020
end_operator
begin_operator
choose-154 
0
5
0 8 -1 0
0 6 -1 0
0 3 -1 0
0 2 -1 0
0 0 1 0
500010
end_operator
begin_operator
choose-155 
0
4
0 6 -1 0
0 3 -1 0
0 2 -1 0
0 0 1 0
625025
end_operator
begin_operator
choose-156 
0
5
0 8 -1 0
0 7 -1 0
0 3 -1 0
0 2 -1 0
0 0 1 0
500007
end_operator
begin_operator
choose-157 
0
4
0 7 -1 0
0 3 -1 0
0 2 -1 0
0 0 1 0
625022
end_operator
begin_operator
choose-158 
0
4
0 8 -1 0
0 3 -1 0
0 2 -1 0
0 0 1 0
625012
end_operator
begin_operator
choose-159 
0
3
0 3 -1 0
0 2 -1 0
0 0 1 0
750027
end_operator
begin_operator
choose-162 
0
6
0 8 -1 0
0 6 -1 0
0 5 -1 0
0 4 -1 0
0 2 -1 0
0 0 1 0
375009
end_operator
begin_operator
choose-163 
0
5
0 6 -1 0
0 5 -1 0
0 4 -1 0
0 2 -1 0
0 0 1 0
500024
end_operator
begin_operator
choose-166 
0
5
0 8 -1 0
0 5 -1 0
0 4 -1 0
0 2 -1 0
0 0 1 0
500011
end_operator
begin_operator
choose-167 
0
4
0 5 -1 0
0 4 -1 0
0 2 -1 0
0 0 1 0
625026
end_operator
begin_operator
choose-168 
0
6
0 8 -1 0
0 7 -1 0
0 6 -1 0
0 4 -1 0
0 2 -1 0
0 0 1 0
375006
end_operator
begin_operator
choose-169 
0
5
0 7 -1 0
0 6 -1 0
0 4 -1 0
0 2 -1 0
0 0 1 0
500021
end_operator
begin_operator
choose-170 
0
5
0 8 -1 0
0 6 -1 0
0 4 -1 0
0 2 -1 0
0 0 1 0
500011
end_operator
begin_operator
choose-171 
0
4
0 6 -1 0
0 4 -1 0
0 2 -1 0
0 0 1 0
625026
end_operator
begin_operator
choose-172 
0
5
0 8 -1 0
0 7 -1 0
0 4 -1 0
0 2 -1 0
0 0 1 0
500008
end_operator
begin_operator
choose-173 
0
4
0 7 -1 0
0 4 -1 0
0 2 -1 0
0 0 1 0
625023
end_operator
begin_operator
choose-174 
0
4
0 8 -1 0
0 4 -1 0
0 2 -1 0
0 0 1 0
625013
end_operator
begin_operator
choose-175 
0
3
0 4 -1 0
0 2 -1 0
0 0 1 0
750028
end_operator
begin_operator
choose-178 
0
5
0 8 -1 0
0 6 -1 0
0 5 -1 0
0 2 -1 0
0 0 1 0
500011
end_operator
begin_operator
choose-179 
0
4
0 6 -1 0
0 5 -1 0
0 2 -1 0
0 0 1 0
625026
end_operator
begin_operator
choose-180 
0
5
0 8 -1 0
0 7 -1 0
0 5 -1 0
0 2 -1 0
0 0 1 0
500008
end_operator
begin_operator
choose-181 
0
4
0 7 -1 0
0 5 -1 0
0 2 -1 0
0 0 1 0
625023
end_operator
begin_operator
choose-182 
0
4
0 8 -1 0
0 5 -1 0
0 2 -1 0
0 0 1 0
625013
end_operator
begin_operator
choose-183 
0
3
0 5 -1 0
0 2 -1 0
0 0 1 0
750028
end_operator
begin_operator
choose-184 
0
5
0 8 -1 0
0 7 -1 0
0 6 -1 0
0 2 -1 0
0 0 1 0
500008
end_operator
begin_operator
choose-185 
0
4
0 7 -1 0
0 6 -1 0
0 2 -1 0
0 0 1 0
625023
end_operator
begin_operator
choose-186 
0
4
0 8 -1 0
0 6 -1 0
0 2 -1 0
0 0 1 0
625013
end_operator
begin_operator
choose-187 
0
3
0 6 -1 0
0 2 -1 0
0 0 1 0
750028
end_operator
begin_operator
choose-188 
0
4
0 8 -1 0
0 7 -1 0
0 2 -1 0
0 0 1 0
625010
end_operator
begin_operator
choose-189 
0
3
0 7 -1 0
0 2 -1 0
0 0 1 0
750025
end_operator
begin_operator
choose-190 
0
3
0 8 -1 0
0 2 -1 0
0 0 1 0
750015
end_operator
begin_operator
choose-191 
0
2
0 2 -1 0
0 0 1 0
875030
end_operator
begin_operator
choose-195 
0
5
0 6 -1 0
0 5 -1 0
0 4 -1 0
0 3 -1 0
0 0 1 0
500022
end_operator
begin_operator
choose-198 
0
5
0 8 -1 0
0 5 -1 0
0 4 -1 0
0 3 -1 0
0 0 1 0
500009
end_operator
begin_operator
choose-199 
0
4
0 5 -1 0
0 4 -1 0
0 3 -1 0
0 0 1 0
625024
end_operator
begin_operator
choose-200 
0
6
0 8 -1 0
0 7 -1 0
0 6 -1 0
0 4 -1 0
0 3 -1 0
0 0 1 0
375004
end_operator
begin_operator
choose-201 
0
5
0 7 -1 0
0 6 -1 0
0 4 -1 0
0 3 -1 0
0 0 1 0
500019
end_operator
begin_operator
choose-202 
0
5
0 8 -1 0
0 6 -1 0
0 4 -1 0
0 3 -1 0
0 0 1 0
500009
end_operator
begin_operator
choose-203 
0
4
0 6 -1 0
0 4 -1 0
0 3 -1 0
0 0 1 0
625024
end_operator
begin_operator
choose-204 
0
5
0 8 -1 0
0 7 -1 0
0 4 -1 0
0 3 -1 0
0 0 1 0
500006
end_operator
begin_operator
choose-205 
0
4
0 7 -1 0
0 4 -1 0
0 3 -1 0
0 0 1 0
625021
end_operator
begin_operator
choose-206 
0
4
0 8 -1 0
0 4 -1 0
0 3 -1 0
0 0 1 0
625011
end_operator
begin_operator
choose-207 
0
3
0 4 -1 0
0 3 -1 0
0 0 1 0
750026
end_operator
begin_operator
choose-210 
0
5
0 8 -1 0
0 6 -1 0
0 5 -1 0
0 3 -1 0
0 0 1 0
500009
end_operator
begin_operator
choose-211 
0
4
0 6 -1 0
0 5 -1 0
0 3 -1 0
0 0 1 0
625024
end_operator
begin_operator
choose-213 
0
4
0 7 -1 0
0 5 -1 0
0 3 -1 0
0 0 1 0
625021
end_operator
begin_operator
choose-214 
0
4
0 8 -1 0
0 5 -1 0
0 3 -1 0
0 0 1 0
625011
end_operator
begin_operator
choose-215 
0
3
0 5 -1 0
0 3 -1 0
0 0 1 0
750026
end_operator
begin_operator
choose-216 
0
5
0 8 -1 0
0 7 -1 0
0 6 -1 0
0 3 -1 0
0 0 1 0
500006
end_operator
begin_operator
choose-217 
0
4
0 7 -1 0
0 6 -1 0
0 3 -1 0
0 0 1 0
625021
end_operator
begin_operator
choose-218 
0
4
0 8 -1 0
0 6 -1 0
0 3 -1 0
0 0 1 0
625011
end_operator
begin_operator
choose-219 
0
3
0 6 -1 0
0 3 -1 0
0 0 1 0
750026
end_operator
begin_operator
choose-220 
0
4
0 8 -1 0
0 7 -1 0
0 3 -1 0
0 0 1 0
625008
end_operator
begin_operator
choose-221 
0
3
0 7 -1 0
0 3 -1 0
0 0 1 0
750023
end_operator
begin_operator
choose-222 
0
3
0 8 -1 0
0 3 -1 0
0 0 1 0
750013
end_operator
begin_operator
choose-223 
0
2
0 3 -1 0
0 0 1 0
875028
end_operator
begin_operator
choose-225 
0
5
0 7 -1 0
0 6 -1 0
0 5 -1 0
0 4 -1 0
0 0 1 0
500020
end_operator
begin_operator
choose-226 
0
5
0 8 -1 0
0 6 -1 0
0 5 -1 0
0 4 -1 0
0 0 1 0
500010
end_operator
begin_operator
choose-227 
0
4
0 6 -1 0
0 5 -1 0
0 4 -1 0
0 0 1 0
625025
end_operator
begin_operator
choose-228 
0
5
0 8 -1 0
0 7 -1 0
0 5 -1 0
0 4 -1 0
0 0 1 0
500007
end_operator
begin_operator
choose-229 
0
4
0 7 -1 0
0 5 -1 0
0 4 -1 0
0 0 1 0
625022
end_operator
begin_operator
choose-230 
0
4
0 8 -1 0
0 5 -1 0
0 4 -1 0
0 0 1 0
625012
end_operator
begin_operator
choose-231 
0
3
0 5 -1 0
0 4 -1 0
0 0 1 0
750027
end_operator
begin_operator
choose-232 
0
5
0 8 -1 0
0 7 -1 0
0 6 -1 0
0 4 -1 0
0 0 1 0
500007
end_operator
begin_operator
choose-233 
0
4
0 7 -1 0
0 6 -1 0
0 4 -1 0
0 0 1 0
625022
end_operator
begin_operator
choose-234 
0
4
0 8 -1 0
0 6 -1 0
0 4 -1 0
0 0 1 0
625012
end_operator
begin_operator
choose-235 
0
3
0 6 -1 0
0 4 -1 0
0 0 1 0
750027
end_operator
begin_operator
choose-236 
0
4
0 8 -1 0
0 7 -1 0
0 4 -1 0
0 0 1 0
625009
end_operator
begin_operator
choose-237 
0
3
0 7 -1 0
0 4 -1 0
0 0 1 0
750024
end_operator
begin_operator
choose-238 
0
3
0 8 -1 0
0 4 -1 0
0 0 1 0
750014
end_operator
begin_operator
choose-239 
0
2
0 4 -1 0
0 0 1 0
875029
end_operator
begin_operator
choose-240 
0
5
0 8 -1 0
0 7 -1 0
0 6 -1 0
0 5 -1 0
0 0 1 0
500007
end_operator
begin_operator
choose-241 
0
4
0 7 -1 0
0 6 -1 0
0 5 -1 0
0 0 1 0
625022
end_operator
begin_operator
choose-242 
0
4
0 8 -1 0
0 6 -1 0
0 5 -1 0
0 0 1 0
625012
end_operator
begin_operator
choose-243 
0
3
0 6 -1 0
0 5 -1 0
0 0 1 0
750027
end_operator
begin_operator
choose-244 
0
4
0 8 -1 0
0 7 -1 0
0 5 -1 0
0 0 1 0
625009
end_operator
begin_operator
choose-245 
0
3
0 7 -1 0
0 5 -1 0
0 0 1 0
750024
end_operator
begin_operator
choose-246 
0
3
0 8 -1 0
0 5 -1 0
0 0 1 0
750014
end_operator
begin_operator
choose-247 
0
2
0 5 -1 0
0 0 1 0
875029
end_operator
begin_operator
choose-248 
0
4
0 8 -1 0
0 7 -1 0
0 6 -1 0
0 0 1 0
625009
end_operator
begin_operator
choose-249 
0
3
0 7 -1 0
0 6 -1 0
0 0 1 0
750024
end_operator
begin_operator
choose-250 
0
3
0 8 -1 0
0 6 -1 0
0 0 1 0
750014
end_operator
begin_operator
choose-251 
0
2
0 6 -1 0
0 0 1 0
875029
end_operator
begin_operator
choose-252 
0
3
0 8 -1 0
0 7 -1 0
0 0 1 0
750011
end_operator
begin_operator
choose-253 
0
2
0 7 -1 0
0 0 1 0
875026
end_operator
begin_operator
choose-254 
0
2
0 8 -1 0
0 0 1 0
875016
end_operator
begin_operator
choose-255 
0
1
0 0 1 0
1000031
end_operator
begin_operator
choose-30 
0
5
0 8 -1 0
0 3 -1 0
0 2 -1 0
0 1 -1 0
0 0 1 0
500011
end_operator
begin_operator
choose-31 
0
4
0 3 -1 0
0 2 -1 0
0 1 -1 0
0 0 1 0
625026
end_operator
begin_operator
choose-43 
0
5
0 6 -1 0
0 4 -1 0
0 2 -1 0
0 1 -1 0
0 0 1 0
500025
end_operator
begin_operator
choose-46 
0
5
0 8 -1 0
0 4 -1 0
0 2 -1 0
0 1 -1 0
0 0 1 0
500012
end_operator
begin_operator
choose-47 
0
4
0 4 -1 0
0 2 -1 0
0 1 -1 0
0 0 1 0
625027
end_operator
begin_operator
choose-55 
0
4
0 5 -1 0
0 2 -1 0
0 1 -1 0
0 0 1 0
625027
end_operator
begin_operator
choose-58 
0
5
0 8 -1 0
0 6 -1 0
0 2 -1 0
0 1 -1 0
0 0 1 0
500012
end_operator
begin_operator
choose-59 
0
4
0 6 -1 0
0 2 -1 0
0 1 -1 0
0 0 1 0
625027
end_operator
begin_operator
choose-61 
0
4
0 7 -1 0
0 2 -1 0
0 1 -1 0
0 0 1 0
625024
end_operator
begin_operator
choose-62 
0
4
0 8 -1 0
0 2 -1 0
0 1 -1 0
0 0 1 0
625014
end_operator
begin_operator
choose-63 
0
3
0 2 -1 0
0 1 -1 0
0 0 1 0
750029
end_operator
begin_operator
choose-75 
0
5
0 6 -1 0
0 4 -1 0
0 3 -1 0
0 1 -1 0
0 0 1 0
500023
end_operator
begin_operator
choose-78 
0
5
0 8 -1 0
0 4 -1 0
0 3 -1 0
0 1 -1 0
0 0 1 0
500010
end_operator
begin_operator
choose-79 
0
4
0 4 -1 0
0 3 -1 0
0 1 -1 0
0 0 1 0
625025
end_operator
begin_operator
choose-90 
0
5
0 8 -1 0
0 6 -1 0
0 3 -1 0
0 1 -1 0
0 0 1 0
500010
end_operator
begin_operator
choose-91 
0
4
0 6 -1 0
0 3 -1 0
0 1 -1 0
0 0 1 0
625025
end_operator
begin_operator
choose-93 
0
4
0 7 -1 0
0 3 -1 0
0 1 -1 0
0 0 1 0
625022
end_operator
begin_operator
choose-94 
0
4
0 8 -1 0
0 3 -1 0
0 1 -1 0
0 0 1 0
625012
end_operator
begin_operator
choose-95 
0
3
0 3 -1 0
0 1 -1 0
0 0 1 0
750027
end_operator
begin_operator
materialize-common 
1
0 0
8
0 8 -1 0
0 7 -1 0
0 6 -1 0
0 5 -1 0
0 4 -1 0
0 3 -1 0
0 2 -1 0
0 1 -1 0
999969
end_operator
0
