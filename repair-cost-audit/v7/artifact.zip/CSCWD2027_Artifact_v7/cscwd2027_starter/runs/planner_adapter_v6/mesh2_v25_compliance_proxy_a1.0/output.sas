begin_version
3
end_version
begin_metric
1
end_metric
9
begin_variable
var0
-1
2
Atom selected()
Atom undecided()
end_variable
begin_variable
var1
-1
2
Atom g7()
NegatedAtom g7()
end_variable
begin_variable
var2
-1
2
Atom g6()
NegatedAtom g6()
end_variable
begin_variable
var3
-1
2
Atom g5()
NegatedAtom g5()
end_variable
begin_variable
var4
-1
2
Atom g4()
NegatedAtom g4()
end_variable
begin_variable
var5
-1
2
Atom g3()
NegatedAtom g3()
end_variable
begin_variable
var6
-1
2
Atom g2()
NegatedAtom g2()
end_variable
begin_variable
var7
-1
2
Atom g1()
NegatedAtom g1()
end_variable
begin_variable
var8
-1
2
Atom g0()
NegatedAtom g0()
end_variable
0
begin_state
1
1
1
1
1
1
1
1
1
end_state
begin_goal
8
1 0
2 0
3 0
4 0
5 0
6 0
7 0
8 0
end_goal
30
begin_operator
choose-126 
0
3
0 8 -1 0
0 1 -1 0
0 0 1 0
728358
end_operator
begin_operator
choose-127 
0
2
0 1 -1 0
0 0 1 0
999961
end_operator
begin_operator
choose-159 
0
3
0 3 -1 0
0 2 -1 0
0 0 1 0
989546
end_operator
begin_operator
choose-174 
0
4
0 8 -1 0
0 4 -1 0
0 2 -1 0
0 0 1 0
707970
end_operator
begin_operator
choose-175 
0
3
0 4 -1 0
0 2 -1 0
0 0 1 0
979573
end_operator
begin_operator
choose-186 
0
4
0 8 -1 0
0 6 -1 0
0 2 -1 0
0 0 1 0
581485
end_operator
begin_operator
choose-187 
0
3
0 6 -1 0
0 2 -1 0
0 0 1 0
853088
end_operator
begin_operator
choose-190 
0
3
0 8 -1 0
0 2 -1 0
0 0 1 0
727218
end_operator
begin_operator
choose-191 
0
2
0 2 -1 0
0 0 1 0
998821
end_operator
begin_operator
choose-206 
0
4
0 8 -1 0
0 4 -1 0
0 3 -1 0
0 0 1 0
699905
end_operator
begin_operator
choose-207 
0
3
0 4 -1 0
0 3 -1 0
0 0 1 0
971508
end_operator
begin_operator
choose-219 
0
3
0 6 -1 0
0 3 -1 0
0 0 1 0
845023
end_operator
begin_operator
choose-222 
0
3
0 8 -1 0
0 3 -1 0
0 0 1 0
719153
end_operator
begin_operator
choose-223 
0
2
0 3 -1 0
0 0 1 0
990756
end_operator
begin_operator
choose-231 
0
3
0 5 -1 0
0 4 -1 0
0 0 1 0
867709
end_operator
begin_operator
choose-234 
0
4
0 8 -1 0
0 6 -1 0
0 4 -1 0
0 0 1 0
563447
end_operator
begin_operator
choose-235 
0
3
0 6 -1 0
0 4 -1 0
0 0 1 0
835050
end_operator
begin_operator
choose-237 
0
3
0 7 -1 0
0 4 -1 0
0 0 1 0
540965
end_operator
begin_operator
choose-238 
0
3
0 8 -1 0
0 4 -1 0
0 0 1 0
709180
end_operator
begin_operator
choose-239 
0
2
0 4 -1 0
0 0 1 0
980783
end_operator
begin_operator
choose-246 
0
3
0 8 -1 0
0 5 -1 0
0 0 1 0
615354
end_operator
begin_operator
choose-247 
0
2
0 5 -1 0
0 0 1 0
886957
end_operator
begin_operator
choose-249 
0
3
0 7 -1 0
0 6 -1 0
0 0 1 0
414480
end_operator
begin_operator
choose-250 
0
3
0 8 -1 0
0 6 -1 0
0 0 1 0
582695
end_operator
begin_operator
choose-251 
0
2
0 6 -1 0
0 0 1 0
854298
end_operator
begin_operator
choose-252 
0
3
0 8 -1 0
0 7 -1 0
0 0 1 0
288610
end_operator
begin_operator
choose-253 
0
2
0 7 -1 0
0 0 1 0
560213
end_operator
begin_operator
choose-254 
0
2
0 8 -1 0
0 0 1 0
728428
end_operator
begin_operator
choose-255 
0
1
0 0 1 0
1000031
end_operator
begin_operator
materialize-common 
1
0 0
8
0 8 -1 0
0 7 -1 0
0 6 -1 0
0 5 -1 0
0 4 -1 0
0 3 -1 0
0 2 -1 0
0 1 -1 0
999969
end_operator
0
