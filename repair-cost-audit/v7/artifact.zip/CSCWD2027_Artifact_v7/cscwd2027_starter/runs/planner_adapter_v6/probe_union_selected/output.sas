begin_version
3
end_version
begin_metric
1
end_metric
6
begin_variable
var0
-1
2
Atom g7()
NegatedAtom g7()
end_variable
begin_variable
var1
-1
2
Atom g6()
NegatedAtom g6()
end_variable
begin_variable
var2
-1
2
Atom g5()
NegatedAtom g5()
end_variable
begin_variable
var3
-1
2
Atom g4()
NegatedAtom g4()
end_variable
begin_variable
var4
-1
2
Atom g3()
NegatedAtom g3()
end_variable
begin_variable
var5
-1
2
Atom g2()
NegatedAtom g2()
end_variable
0
begin_state
1
1
1
1
1
1
end_state
begin_goal
6
0 0
1 0
2 0
3 0
4 0
5 0
end_goal
1
begin_operator
materialize-common 
0
6
0 5 -1 0
0 4 -1 0
0 3 -1 0
0 2 -1 0
0 1 -1 0
0 0 -1 0
999969
end_operator
0
