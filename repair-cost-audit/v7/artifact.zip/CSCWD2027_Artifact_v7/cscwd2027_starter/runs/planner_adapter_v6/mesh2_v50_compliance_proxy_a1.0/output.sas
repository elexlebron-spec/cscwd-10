begin_version
3
end_version
begin_metric
1
end_metric
9
begin_variable
var0
-1
2
Atom selected()
Atom undecided()
end_variable
begin_variable
var1
-1
2
Atom g7()
NegatedAtom g7()
end_variable
begin_variable
var2
-1
2
Atom g6()
NegatedAtom g6()
end_variable
begin_variable
var3
-1
2
Atom g5()
NegatedAtom g5()
end_variable
begin_variable
var4
-1
2
Atom g4()
NegatedAtom g4()
end_variable
begin_variable
var5
-1
2
Atom g3()
NegatedAtom g3()
end_variable
begin_variable
var6
-1
2
Atom g2()
NegatedAtom g2()
end_variable
begin_variable
var7
-1
2
Atom g1()
NegatedAtom g1()
end_variable
begin_variable
var8
-1
2
Atom g0()
NegatedAtom g0()
end_variable
0
begin_state
1
1
1
1
1
1
1
1
1
end_state
begin_goal
8
1 0
2 0
3 0
4 0
5 0
6 0
7 0
8 0
end_goal
135
begin_operator
choose-102 
0
5
0 8 -1 0
0 5 -1 0
0 4 -1 0
0 1 -1 0
0 0 1 0
596036
end_operator
begin_operator
choose-103 
0
4
0 5 -1 0
0 4 -1 0
0 1 -1 0
0 0 1 0
867639
end_operator
begin_operator
choose-106 
0
5
0 8 -1 0
0 6 -1 0
0 4 -1 0
0 1 -1 0
0 0 1 0
563377
end_operator
begin_operator
choose-107 
0
4
0 6 -1 0
0 4 -1 0
0 1 -1 0
0 0 1 0
834980
end_operator
begin_operator
choose-108 
0
5
0 8 -1 0
0 7 -1 0
0 4 -1 0
0 1 -1 0
0 0 1 0
269292
end_operator
begin_operator
choose-109 
0
4
0 7 -1 0
0 4 -1 0
0 1 -1 0
0 0 1 0
540895
end_operator
begin_operator
choose-110 
0
4
0 8 -1 0
0 4 -1 0
0 1 -1 0
0 0 1 0
709110
end_operator
begin_operator
choose-111 
0
3
0 4 -1 0
0 1 -1 0
0 0 1 0
980713
end_operator
begin_operator
choose-115 
0
4
0 6 -1 0
0 5 -1 0
0 1 -1 0
0 0 1 0
741154
end_operator
begin_operator
choose-118 
0
4
0 8 -1 0
0 5 -1 0
0 1 -1 0
0 0 1 0
615284
end_operator
begin_operator
choose-119 
0
3
0 5 -1 0
0 1 -1 0
0 0 1 0
886887
end_operator
begin_operator
choose-120 
0
5
0 8 -1 0
0 7 -1 0
0 6 -1 0
0 1 -1 0
0 0 1 0
142807
end_operator
begin_operator
choose-121 
0
4
0 7 -1 0
0 6 -1 0
0 1 -1 0
0 0 1 0
414410
end_operator
begin_operator
choose-122 
0
4
0 8 -1 0
0 6 -1 0
0 1 -1 0
0 0 1 0
582625
end_operator
begin_operator
choose-123 
0
3
0 6 -1 0
0 1 -1 0
0 0 1 0
854228
end_operator
begin_operator
choose-124 
0
4
0 8 -1 0
0 7 -1 0
0 1 -1 0
0 0 1 0
288540
end_operator
begin_operator
choose-125 
0
3
0 7 -1 0
0 1 -1 0
0 0 1 0
560143
end_operator
begin_operator
choose-126 
0
3
0 8 -1 0
0 1 -1 0
0 0 1 0
728358
end_operator
begin_operator
choose-127 
0
2
0 1 -1 0
0 0 1 0
999961
end_operator
begin_operator
choose-135 
0
5
0 5 -1 0
0 4 -1 0
0 3 -1 0
0 2 -1 0
0 0 1 0
857224
end_operator
begin_operator
choose-138 
0
6
0 8 -1 0
0 6 -1 0
0 4 -1 0
0 3 -1 0
0 2 -1 0
0 0 1 0
552962
end_operator
begin_operator
choose-139 
0
5
0 6 -1 0
0 4 -1 0
0 3 -1 0
0 2 -1 0
0 0 1 0
824565
end_operator
begin_operator
choose-141 
0
5
0 7 -1 0
0 4 -1 0
0 3 -1 0
0 2 -1 0
0 0 1 0
530480
end_operator
begin_operator
choose-142 
0
5
0 8 -1 0
0 4 -1 0
0 3 -1 0
0 2 -1 0
0 0 1 0
698695
end_operator
begin_operator
choose-143 
0
4
0 4 -1 0
0 3 -1 0
0 2 -1 0
0 0 1 0
970298
end_operator
begin_operator
choose-150 
0
5
0 8 -1 0
0 5 -1 0
0 3 -1 0
0 2 -1 0
0 0 1 0
604869
end_operator
begin_operator
choose-151 
0
4
0 5 -1 0
0 3 -1 0
0 2 -1 0
0 0 1 0
876472
end_operator
begin_operator
choose-153 
0
5
0 7 -1 0
0 6 -1 0
0 3 -1 0
0 2 -1 0
0 0 1 0
403995
end_operator
begin_operator
choose-154 
0
5
0 8 -1 0
0 6 -1 0
0 3 -1 0
0 2 -1 0
0 0 1 0
572210
end_operator
begin_operator
choose-155 
0
4
0 6 -1 0
0 3 -1 0
0 2 -1 0
0 0 1 0
843813
end_operator
begin_operator
choose-156 
0
5
0 8 -1 0
0 7 -1 0
0 3 -1 0
0 2 -1 0
0 0 1 0
278125
end_operator
begin_operator
choose-157 
0
4
0 7 -1 0
0 3 -1 0
0 2 -1 0
0 0 1 0
549728
end_operator
begin_operator
choose-158 
0
4
0 8 -1 0
0 3 -1 0
0 2 -1 0
0 0 1 0
717943
end_operator
begin_operator
choose-159 
0
3
0 3 -1 0
0 2 -1 0
0 0 1 0
989546
end_operator
begin_operator
choose-162 
0
6
0 8 -1 0
0 6 -1 0
0 5 -1 0
0 4 -1 0
0 2 -1 0
0 0 1 0
449163
end_operator
begin_operator
choose-163 
0
5
0 6 -1 0
0 5 -1 0
0 4 -1 0
0 2 -1 0
0 0 1 0
720766
end_operator
begin_operator
choose-166 
0
5
0 8 -1 0
0 5 -1 0
0 4 -1 0
0 2 -1 0
0 0 1 0
594896
end_operator
begin_operator
choose-167 
0
4
0 5 -1 0
0 4 -1 0
0 2 -1 0
0 0 1 0
866499
end_operator
begin_operator
choose-168 
0
6
0 8 -1 0
0 7 -1 0
0 6 -1 0
0 4 -1 0
0 2 -1 0
0 0 1 0
122419
end_operator
begin_operator
choose-169 
0
5
0 7 -1 0
0 6 -1 0
0 4 -1 0
0 2 -1 0
0 0 1 0
394022
end_operator
begin_operator
choose-170 
0
5
0 8 -1 0
0 6 -1 0
0 4 -1 0
0 2 -1 0
0 0 1 0
562237
end_operator
begin_operator
choose-171 
0
4
0 6 -1 0
0 4 -1 0
0 2 -1 0
0 0 1 0
833840
end_operator
begin_operator
choose-172 
0
5
0 8 -1 0
0 7 -1 0
0 4 -1 0
0 2 -1 0
0 0 1 0
268152
end_operator
begin_operator
choose-173 
0
4
0 7 -1 0
0 4 -1 0
0 2 -1 0
0 0 1 0
539755
end_operator
begin_operator
choose-174 
0
4
0 8 -1 0
0 4 -1 0
0 2 -1 0
0 0 1 0
707970
end_operator
begin_operator
choose-175 
0
3
0 4 -1 0
0 2 -1 0
0 0 1 0
979573
end_operator
begin_operator
choose-178 
0
5
0 8 -1 0
0 6 -1 0
0 5 -1 0
0 2 -1 0
0 0 1 0
468411
end_operator
begin_operator
choose-179 
0
4
0 6 -1 0
0 5 -1 0
0 2 -1 0
0 0 1 0
740014
end_operator
begin_operator
choose-180 
0
5
0 8 -1 0
0 7 -1 0
0 5 -1 0
0 2 -1 0
0 0 1 0
174326
end_operator
begin_operator
choose-181 
0
4
0 7 -1 0
0 5 -1 0
0 2 -1 0
0 0 1 0
445929
end_operator
begin_operator
choose-182 
0
4
0 8 -1 0
0 5 -1 0
0 2 -1 0
0 0 1 0
614144
end_operator
begin_operator
choose-183 
0
3
0 5 -1 0
0 2 -1 0
0 0 1 0
885747
end_operator
begin_operator
choose-184 
0
5
0 8 -1 0
0 7 -1 0
0 6 -1 0
0 2 -1 0
0 0 1 0
141667
end_operator
begin_operator
choose-185 
0
4
0 7 -1 0
0 6 -1 0
0 2 -1 0
0 0 1 0
413270
end_operator
begin_operator
choose-186 
0
4
0 8 -1 0
0 6 -1 0
0 2 -1 0
0 0 1 0
581485
end_operator
begin_operator
choose-187 
0
3
0 6 -1 0
0 2 -1 0
0 0 1 0
853088
end_operator
begin_operator
choose-188 
0
4
0 8 -1 0
0 7 -1 0
0 2 -1 0
0 0 1 0
287400
end_operator
begin_operator
choose-189 
0
3
0 7 -1 0
0 2 -1 0
0 0 1 0
559003
end_operator
begin_operator
choose-190 
0
3
0 8 -1 0
0 2 -1 0
0 0 1 0
727218
end_operator
begin_operator
choose-191 
0
2
0 2 -1 0
0 0 1 0
998821
end_operator
begin_operator
choose-195 
0
5
0 6 -1 0
0 5 -1 0
0 4 -1 0
0 3 -1 0
0 0 1 0
712701
end_operator
begin_operator
choose-198 
0
5
0 8 -1 0
0 5 -1 0
0 4 -1 0
0 3 -1 0
0 0 1 0
586831
end_operator
begin_operator
choose-199 
0
4
0 5 -1 0
0 4 -1 0
0 3 -1 0
0 0 1 0
858434
end_operator
begin_operator
choose-200 
0
6
0 8 -1 0
0 7 -1 0
0 6 -1 0
0 4 -1 0
0 3 -1 0
0 0 1 0
114354
end_operator
begin_operator
choose-201 
0
5
0 7 -1 0
0 6 -1 0
0 4 -1 0
0 3 -1 0
0 0 1 0
385957
end_operator
begin_operator
choose-202 
0
5
0 8 -1 0
0 6 -1 0
0 4 -1 0
0 3 -1 0
0 0 1 0
554172
end_operator
begin_operator
choose-203 
0
4
0 6 -1 0
0 4 -1 0
0 3 -1 0
0 0 1 0
825775
end_operator
begin_operator
choose-204 
0
5
0 8 -1 0
0 7 -1 0
0 4 -1 0
0 3 -1 0
0 0 1 0
260087
end_operator
begin_operator
choose-205 
0
4
0 7 -1 0
0 4 -1 0
0 3 -1 0
0 0 1 0
531690
end_operator
begin_operator
choose-206 
0
4
0 8 -1 0
0 4 -1 0
0 3 -1 0
0 0 1 0
699905
end_operator
begin_operator
choose-207 
0
3
0 4 -1 0
0 3 -1 0
0 0 1 0
971508
end_operator
begin_operator
choose-210 
0
5
0 8 -1 0
0 6 -1 0
0 5 -1 0
0 3 -1 0
0 0 1 0
460346
end_operator
begin_operator
choose-211 
0
4
0 6 -1 0
0 5 -1 0
0 3 -1 0
0 0 1 0
731949
end_operator
begin_operator
choose-213 
0
4
0 7 -1 0
0 5 -1 0
0 3 -1 0
0 0 1 0
437864
end_operator
begin_operator
choose-214 
0
4
0 8 -1 0
0 5 -1 0
0 3 -1 0
0 0 1 0
606079
end_operator
begin_operator
choose-215 
0
3
0 5 -1 0
0 3 -1 0
0 0 1 0
877682
end_operator
begin_operator
choose-216 
0
5
0 8 -1 0
0 7 -1 0
0 6 -1 0
0 3 -1 0
0 0 1 0
133602
end_operator
begin_operator
choose-217 
0
4
0 7 -1 0
0 6 -1 0
0 3 -1 0
0 0 1 0
405205
end_operator
begin_operator
choose-218 
0
4
0 8 -1 0
0 6 -1 0
0 3 -1 0
0 0 1 0
573420
end_operator
begin_operator
choose-219 
0
3
0 6 -1 0
0 3 -1 0
0 0 1 0
845023
end_operator
begin_operator
choose-220 
0
4
0 8 -1 0
0 7 -1 0
0 3 -1 0
0 0 1 0
279335
end_operator
begin_operator
choose-221 
0
3
0 7 -1 0
0 3 -1 0
0 0 1 0
550938
end_operator
begin_operator
choose-222 
0
3
0 8 -1 0
0 3 -1 0
0 0 1 0
719153
end_operator
begin_operator
choose-223 
0
2
0 3 -1 0
0 0 1 0
990756
end_operator
begin_operator
choose-225 
0
5
0 7 -1 0
0 6 -1 0
0 5 -1 0
0 4 -1 0
0 0 1 0
282158
end_operator
begin_operator
choose-226 
0
5
0 8 -1 0
0 6 -1 0
0 5 -1 0
0 4 -1 0
0 0 1 0
450373
end_operator
begin_operator
choose-227 
0
4
0 6 -1 0
0 5 -1 0
0 4 -1 0
0 0 1 0
721976
end_operator
begin_operator
choose-228 
0
5
0 8 -1 0
0 7 -1 0
0 5 -1 0
0 4 -1 0
0 0 1 0
156288
end_operator
begin_operator
choose-229 
0
4
0 7 -1 0
0 5 -1 0
0 4 -1 0
0 0 1 0
427891
end_operator
begin_operator
choose-230 
0
4
0 8 -1 0
0 5 -1 0
0 4 -1 0
0 0 1 0
596106
end_operator
begin_operator
choose-231 
0
3
0 5 -1 0
0 4 -1 0
0 0 1 0
867709
end_operator
begin_operator
choose-232 
0
5
0 8 -1 0
0 7 -1 0
0 6 -1 0
0 4 -1 0
0 0 1 0
123629
end_operator
begin_operator
choose-233 
0
4
0 7 -1 0
0 6 -1 0
0 4 -1 0
0 0 1 0
395232
end_operator
begin_operator
choose-234 
0
4
0 8 -1 0
0 6 -1 0
0 4 -1 0
0 0 1 0
563447
end_operator
begin_operator
choose-235 
0
3
0 6 -1 0
0 4 -1 0
0 0 1 0
835050
end_operator
begin_operator
choose-236 
0
4
0 8 -1 0
0 7 -1 0
0 4 -1 0
0 0 1 0
269362
end_operator
begin_operator
choose-237 
0
3
0 7 -1 0
0 4 -1 0
0 0 1 0
540965
end_operator
begin_operator
choose-238 
0
3
0 8 -1 0
0 4 -1 0
0 0 1 0
709180
end_operator
begin_operator
choose-239 
0
2
0 4 -1 0
0 0 1 0
980783
end_operator
begin_operator
choose-240 
0
5
0 8 -1 0
0 7 -1 0
0 6 -1 0
0 5 -1 0
0 0 1 0
29803
end_operator
begin_operator
choose-241 
0
4
0 7 -1 0
0 6 -1 0
0 5 -1 0
0 0 1 0
301406
end_operator
begin_operator
choose-242 
0
4
0 8 -1 0
0 6 -1 0
0 5 -1 0
0 0 1 0
469621
end_operator
begin_operator
choose-243 
0
3
0 6 -1 0
0 5 -1 0
0 0 1 0
741224
end_operator
begin_operator
choose-244 
0
4
0 8 -1 0
0 7 -1 0
0 5 -1 0
0 0 1 0
175536
end_operator
begin_operator
choose-245 
0
3
0 7 -1 0
0 5 -1 0
0 0 1 0
447139
end_operator
begin_operator
choose-246 
0
3
0 8 -1 0
0 5 -1 0
0 0 1 0
615354
end_operator
begin_operator
choose-247 
0
2
0 5 -1 0
0 0 1 0
886957
end_operator
begin_operator
choose-248 
0
4
0 8 -1 0
0 7 -1 0
0 6 -1 0
0 0 1 0
142877
end_operator
begin_operator
choose-249 
0
3
0 7 -1 0
0 6 -1 0
0 0 1 0
414480
end_operator
begin_operator
choose-250 
0
3
0 8 -1 0
0 6 -1 0
0 0 1 0
582695
end_operator
begin_operator
choose-251 
0
2
0 6 -1 0
0 0 1 0
854298
end_operator
begin_operator
choose-252 
0
3
0 8 -1 0
0 7 -1 0
0 0 1 0
288610
end_operator
begin_operator
choose-253 
0
2
0 7 -1 0
0 0 1 0
560213
end_operator
begin_operator
choose-254 
0
2
0 8 -1 0
0 0 1 0
728428
end_operator
begin_operator
choose-255 
0
1
0 0 1 0
1000031
end_operator
begin_operator
choose-30 
0
5
0 8 -1 0
0 3 -1 0
0 2 -1 0
0 1 -1 0
0 0 1 0
717873
end_operator
begin_operator
choose-31 
0
4
0 3 -1 0
0 2 -1 0
0 1 -1 0
0 0 1 0
989476
end_operator
begin_operator
choose-43 
0
5
0 6 -1 0
0 4 -1 0
0 2 -1 0
0 1 -1 0
0 0 1 0
833770
end_operator
begin_operator
choose-46 
0
5
0 8 -1 0
0 4 -1 0
0 2 -1 0
0 1 -1 0
0 0 1 0
707900
end_operator
begin_operator
choose-47 
0
4
0 4 -1 0
0 2 -1 0
0 1 -1 0
0 0 1 0
979503
end_operator
begin_operator
choose-55 
0
4
0 5 -1 0
0 2 -1 0
0 1 -1 0
0 0 1 0
885677
end_operator
begin_operator
choose-58 
0
5
0 8 -1 0
0 6 -1 0
0 2 -1 0
0 1 -1 0
0 0 1 0
581415
end_operator
begin_operator
choose-59 
0
4
0 6 -1 0
0 2 -1 0
0 1 -1 0
0 0 1 0
853018
end_operator
begin_operator
choose-61 
0
4
0 7 -1 0
0 2 -1 0
0 1 -1 0
0 0 1 0
558933
end_operator
begin_operator
choose-62 
0
4
0 8 -1 0
0 2 -1 0
0 1 -1 0
0 0 1 0
727148
end_operator
begin_operator
choose-63 
0
3
0 2 -1 0
0 1 -1 0
0 0 1 0
998751
end_operator
begin_operator
choose-75 
0
5
0 6 -1 0
0 4 -1 0
0 3 -1 0
0 1 -1 0
0 0 1 0
825705
end_operator
begin_operator
choose-78 
0
5
0 8 -1 0
0 4 -1 0
0 3 -1 0
0 1 -1 0
0 0 1 0
699835
end_operator
begin_operator
choose-79 
0
4
0 4 -1 0
0 3 -1 0
0 1 -1 0
0 0 1 0
971438
end_operator
begin_operator
choose-90 
0
5
0 8 -1 0
0 6 -1 0
0 3 -1 0
0 1 -1 0
0 0 1 0
573350
end_operator
begin_operator
choose-91 
0
4
0 6 -1 0
0 3 -1 0
0 1 -1 0
0 0 1 0
844953
end_operator
begin_operator
choose-93 
0
4
0 7 -1 0
0 3 -1 0
0 1 -1 0
0 0 1 0
550868
end_operator
begin_operator
choose-94 
0
4
0 8 -1 0
0 3 -1 0
0 1 -1 0
0 0 1 0
719083
end_operator
begin_operator
choose-95 
0
3
0 3 -1 0
0 1 -1 0
0 0 1 0
990686
end_operator
begin_operator
materialize-common 
1
0 0
8
0 8 -1 0
0 7 -1 0
0 6 -1 0
0 5 -1 0
0 4 -1 0
0 3 -1 0
0 2 -1 0
0 1 -1 0
999969
end_operator
0
