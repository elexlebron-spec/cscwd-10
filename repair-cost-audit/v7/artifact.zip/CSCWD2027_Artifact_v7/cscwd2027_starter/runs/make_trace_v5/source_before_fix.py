"""Observe unmodified zlib Make recipes after controlled source invalidations.

Only timestamps change. No functional edits, collaborator histories, repair
preferences, or deployed pricing policy are invented. The wrapper records actual
upstream shell recipes and introduces instrumentation overhead; timings are not
an estimate of uninstrumented end-to-end performance.
"""
import argparse
import hashlib
import itertools
import json
import os
from pathlib import Path
import platform
import random
import shutil
import statistics
import subprocess
import sys
import tarfile
import tempfile
import time

ROOT = Path(__file__).resolve().parents[1]
ARCHIVE = ROOT / 'literature/build_source/zlib-1.3.2.tar.gz'
DIGEST = 'bb329a0a2cd0274d05519d61c667c062e06990d72e125ee2dfa8de64f0119d16'
SOURCES = ['adler32.c', 'compress.c', 'crc32.c', 'deflate.c',
           'gzclose.c', 'gzlib.c', 'gzread.c', 'gzwrite.c']

SHELL = '''#!{python}
import json, os, re, subprocess, sys, time
cmd = sys.argv[-1]
if ' -c ' in cmd:
    m = re.search(r'-o\\s+(\\S+)', cmd)
    task = 'compile:' + m.group(1)
elif cmd.startswith('ar '): task = 'archive:libz.a'
elif 'ranlib' in cmd: task = 'index:libz.a'
elif ' -o example ' in cmd: task = 'link:example'
elif ' -o minigzip ' in cmd: task = 'link:minigzip'
elif cmd.startswith('TMPST='): task = 'test:static'
elif cmd.startswith('rm -f tmpst_'): task = 'cleanup:test'
else: task = 'other:' + cmd
start = time.perf_counter()
r = subprocess.run(['/bin/sh', '-c', cmd])
elapsed = time.perf_counter() - start
with open(os.environ['CSCWD_RECIPE_LOG'], 'a') as f:
    f.write(json.dumps(dict(task=task, command=cmd, seconds=elapsed, status=r.returncode))+'\\n')
sys.exit(r.returncode)
'''


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    out = args.out.resolve()
    if out.exists():
        raise RuntimeError('Output already exists; preserve previous observations')
    assert hashlib.sha256(ARCHIVE.read_bytes()).hexdigest() == DIGEST
    protocol = json.loads((ROOT / 'docs/FROZEN_PROTOCOL_V5.json').read_text())
    for name, digest in protocol['code_sha256'].items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest
    out.mkdir(parents=True)
    shutil.copy2(ROOT / 'docs/FROZEN_PROTOCOL_V5.json', out / 'protocol.json')
    records = []
    with tempfile.TemporaryDirectory(prefix='cscwd-zlib-v5-') as tmp:
        tmp = Path(tmp)
        with tarfile.open(ARCHIVE) as archive:
            archive.extractall(tmp, filter='data')
        source = tmp / 'zlib-1.3.2'
        env = dict(os.environ, CC='/usr/bin/clang', CFLAGS='-O2', LC_ALL='C', LANG='C')
        configure = subprocess.run(['./configure', '--static'], cwd=source, env=env,
                                   text=True, capture_output=True, check=True)
        (out / 'configure.log').write_text(configure.stdout + configure.stderr)
        start = time.perf_counter()
        initial = subprocess.run(['/usr/bin/make', '-j1', 'teststatic'], cwd=source,
                                 env=env, text=True, capture_output=True, check=True)
        (out / 'initial.log').write_text(initial.stdout + initial.stderr)
        initial_seconds = time.perf_counter() - start
        assert 'zlib test OK' in initial.stdout
        shutil.copy2(source / 'Makefile', out / 'upstream-configured-Makefile')
        shutil.copy2(source / 'Makefile.in', out / 'upstream-Makefile.in')
        shutil.copy2(source / 'LICENSE', out / 'zlib-LICENSE')
        hashes = {p.relative_to(source).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                  for p in source.rglob('*') if p.is_file() and p.suffix in ('.c', '.h')}
        artifacts = [*source.glob('*.o'), source/'libz.a', source/'example', source/'minigzip']
        shell = tmp / 'observe-shell'
        shell.write_text(SHELL.format(python=sys.executable))
        shell.chmod(0o755)
        # Eight singletons, every pair, and the complete batch: no favorable subset selection.
        batches = [(i,) for i in range(8)] + list(itertools.combinations(range(8), 2)) + [tuple(range(8))]
        order = [(r, b) for r in range(protocol['build_repeats']) for b in batches]
        random.Random(protocol['order_seed']).shuffle(order)
        # An unscored instrumented warmup is preserved separately.
        for index, (repeat, batch) in enumerate([(-1, tuple(range(8)))] + order):
            old = time.time() - 600
            for p in source.rglob('*'):
                if p.is_file(): os.utime(p, (old, old))
            for p in artifacts: os.utime(p, (old+200, old+200))
            for i in batch: os.utime(source / SOURCES[i], (old+400, old+400))
            log = tmp / 'recipes.jsonl'
            log.write_text('')
            start = time.perf_counter()
            build = subprocess.run(['/usr/bin/make', '-j1', 'teststatic', 'SHELL='+str(shell)],
                                   cwd=source, env=dict(env, CSCWD_RECIPE_LOG=str(log)),
                                   text=True, capture_output=True)
            elapsed = time.perf_counter() - start
            trace = [json.loads(s) for s in log.read_text().splitlines()]
            assert build.returncode == 0 and 'zlib test OK' in build.stdout, build.stdout + build.stderr
            assert all(t['status'] == 0 for t in trace)
            assert len({t['task'] for t in trace}) == len(trace), trace
            assert not any(t['task'].startswith('other:') for t in trace), trace
            record = dict(repeat=repeat, roots=list(batch), sources=[SOURCES[i] for i in batch],
                          task_count=len(trace), trace=trace, instrumented_seconds=elapsed,
                          test_passed=True, stdout=build.stdout, stderr=build.stderr)
            if repeat == -1:
                (out / 'warmup.json').write_text(json.dumps(record, indent=2))
            else:
                records.append(record)
                with (out / 'raw.jsonl').open('a') as f: f.write(json.dumps(record)+'\n')
            if index % 15 == 0: print('completed', index, '/', len(order), flush=True)
        final_hashes = {name: hashlib.sha256((source/name).read_bytes()).hexdigest() for name in hashes}
        assert hashes == final_hashes
        (out / 'source_hashes.json').write_text(json.dumps(hashes, indent=2))
        (out / 'environment.json').write_text(json.dumps(dict(
            python=sys.version, platform=platform.platform(),
            make=subprocess.check_output(['/usr/bin/make','--version'],text=True).splitlines()[0],
            compiler=subprocess.check_output(['/usr/bin/clang','--version'],text=True).splitlines()[0],
            archive_sha256=DIGEST, initial_seconds=initial_seconds,
            source_bytes_unchanged=True, timing_scope='instrumented recipe traces; no uninstrumented speed claim'),indent=2))
    singletons = {i: {t['task'] for t in next(r for r in records if r['roots']==[i])['trace']} for i in range(8)}
    for r in records:
        predicted = set().union(*(singletons[i] for i in r['roots']))
        assert predicted == {t['task'] for t in r['trace']}
    common = set.intersection(*singletons.values())
    summary = dict(records=len(records), batches=len(batches), repeats=protocol['build_repeats'],
                   source_paths=SOURCES, common_tasks=sorted(common),
                   every_batch_equals_union_of_singletons=True, all_tests_passed=True,
                   single_task_counts=[len(singletons[i]) for i in range(8)],
                   pairs_actual=sorted({r['task_count'] for r in records if len(r['roots'])==2}),
                   all8_actual=sorted({r['task_count'] for r in records if len(r['roots'])==8}),
                   all8_isolated_sum=sum(len(singletons[i]) for i in range(8)),
                   scope='Observed upstream dependency execution, not observed collaborator decisions or deployed additive pricing')
    (out / 'summary.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary, indent=2))


if __name__ == '__main__': main()
