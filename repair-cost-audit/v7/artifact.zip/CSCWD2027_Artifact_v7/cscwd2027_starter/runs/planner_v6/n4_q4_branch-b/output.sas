begin_version
3
end_version
begin_metric
1
end_metric
4
begin_variable
var0
-1
2
Atom g3()
NegatedAtom g3()
end_variable
begin_variable
var1
-1
2
Atom g2()
NegatedAtom g2()
end_variable
begin_variable
var2
-1
2
Atom g1()
NegatedAtom g1()
end_variable
begin_variable
var3
-1
2
Atom g0()
NegatedAtom g0()
end_variable
0
begin_state
1
1
1
1
end_state
begin_goal
4
0 0
1 0
2 0
3 0
end_goal
4
begin_operator
finish-b-0 
0
1
0 3 -1 0
3
end_operator
begin_operator
finish-b-1 
0
1
0 2 -1 0
3
end_operator
begin_operator
finish-b-2 
0
1
0 1 -1 0
3
end_operator
begin_operator
finish-b-3 
0
1
0 0 -1 0
3
end_operator
0
