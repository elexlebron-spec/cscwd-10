begin_version
3
end_version
begin_metric
1
end_metric
5
begin_variable
var0
-1
3
Atom branch-b()
Atom undecided()
<none of those>
end_variable
begin_variable
var1
-1
2
Atom branch-a()
NegatedAtom branch-a()
end_variable
begin_variable
var2
-1
2
Atom shared()
NegatedAtom shared()
end_variable
begin_variable
var3
-1
2
Atom g1()
NegatedAtom g1()
end_variable
begin_variable
var4
-1
2
Atom g0()
NegatedAtom g0()
end_variable
1
begin_mutex_group
2
1 0
0 1
end_mutex_group
begin_state
1
1
1
1
1
end_state
begin_goal
2
3 0
4 0
end_goal
7
begin_operator
choose-a 
0
2
0 1 -1 0
0 0 1 2
0
end_operator
begin_operator
choose-b 
0
1
0 0 1 0
0
end_operator
begin_operator
finish-a-0 
2
1 0
2 0
1
0 4 -1 0
1
end_operator
begin_operator
finish-a-1 
2
1 0
2 0
1
0 3 -1 0
1
end_operator
begin_operator
finish-b-0 
1
0 0
1
0 4 -1 0
3
end_operator
begin_operator
finish-b-1 
1
0 0
1
0 3 -1 0
3
end_operator
begin_operator
shared-a 
1
1 0
1
0 2 -1 0
0
end_operator
0
