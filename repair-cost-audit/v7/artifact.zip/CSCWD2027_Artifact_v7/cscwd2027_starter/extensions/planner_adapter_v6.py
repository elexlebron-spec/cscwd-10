"""Cost-only planning encoding of complete candidate repairs for six beam inputs.

Each choice applies a candidate's private reset work and intent loss; one shared
materialization validates the batch. Unchanged Fast Downward add() estimates its
cost once for every invalidated receipt; ff() extracts that action once. This is
a controlled adapter, not a historical production deployment or full FE planner.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
from .accounting_v5 import common_core,residuals_disjoint
from rework.core import Instance,Problem

ROOT=Path(__file__).resolve().parents[1]


def encode(candidates,n,q,initial_mask=None):
    facts=['undecided','selected']+['g%d'%i for i in range(n)]
    actions=[]
    for mask,cost in candidates:
        kept=['(g%d)'%i for i in range(n) if not(mask>>i&1)]
        actions.append('(:action choose-%d :parameters () :precondition (undecided) :effect (and (not (undecided)) (selected) %s (increase (total-cost) %d)))'%(mask,' '.join(kept),cost))
    actions.append('(:action materialize-common :parameters () :precondition (selected) :effect (and %s (increase (total-cost) %d)))'%(' '.join('(g%d)'%i for i in range(n)),q))
    domain='(define (domain batch-repair) (:requirements :strips :action-costs) (:predicates %s) (:functions (total-cost)) %s)'%(' '.join('('+f+')' for f in facts),'\n'.join(actions))
    init='(undecided)' if initial_mask is None else '(selected) '+' '.join('(g%d)'%i for i in range(n) if not(initial_mask>>i&1))
    problem='(define (problem repair) (:domain batch-repair) (:init %s (= (total-cost) 0)) (:goal (and %s)) (:metric minimize (total-cost)))'%(init,' '.join('(g%d)'%i for i in range(n)))
    return domain,problem


def run_engine(case,domain,problem,source,binary,search,method):
    case.mkdir(parents=True,exist_ok=True)
    (case/'domain.pddl').write_text(domain);(case/'problem.pddl').write_text(problem)
    if not (case/'output.sas').exists():
        tr=subprocess.run([sys.executable,str(source/'src/translate/translate.py'),'domain.pddl','problem.pddl','--sas-file','output.sas'],cwd=case,text=True,capture_output=True,timeout=30)
        (case/'translate.log').write_text(tr.stdout+tr.stderr);assert tr.returncode==0,tr.stdout+tr.stderr
    with (case/'output.sas').open() as inp:
        r=subprocess.run([str(binary),'--search',search,'--internal-plan-file',method+'.plan'],cwd=case,stdin=inp,text=True,capture_output=True,timeout=30)
    (case/(method+'.log')).write_text(r.stdout+r.stderr);assert r.returncode==0,r.stdout+r.stderr
    actions=[s.strip()[1:-1].strip() for s in (case/(method+'.plan')).read_text().splitlines() if s.strip().startswith('(')]
    h=re.search(r'Initial heuristic value for [^:]+: (\d+)',r.stdout)
    return actions,int(re.search(r'Plan cost: (\d+)',r.stdout)[1]),int(h[1]) if h else None


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--fd-source',type=Path,required=True)
    ap.add_argument('--fd-build',type=Path,required=True);ap.add_argument('--out',type=Path,required=True)
    args=ap.parse_args();out=args.out.resolve();assert not out.exists()
    cfg=json.loads((ROOT/'docs/FROZEN_PROTOCOL_V6_ADAPTER.json').read_text())
    for name,sha in cfg['code_sha256'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==sha
    upstream=json.loads((ROOT/'docs/FROZEN_PROTOCOL_V6.json').read_text())
    for name,sha in upstream['planner_source_sha256'].items():assert hashlib.sha256((args.fd_source/name).read_bytes()).hexdigest()==sha
    out.mkdir(parents=True);(out/'protocol.json').write_text(json.dumps(cfg,indent=2))
    rows=[];case_summary=[];probes=[]
    for name in cfg['cases']:
        ins=Instance.load(ROOT/'runs/beam_main_v4'/name/'instance.json');p=Problem(ins)
        n=len(ins.losses);core=common_core(p.fp);assert residuals_disjoint(p.fp)
        coeff=[x/sum(ins.losses)+sum(ins.work[a] for a in p.fp[i]-core)/sum(ins.work) for i,x in enumerate(ins.losses)]
        q=round(cfg['integer_scale']*sum(ins.work[a] for a in core)/sum(ins.work))
        integer=[round(cfg['integer_scale']*v) for v in coeff];assert min(integer)>0
        candidates=[(mask,sum(integer[i] for i in range(n) if mask>>i&1)) for mask in range(1,1<<n) if p.feasible({i for i in range(n) if mask>>i&1})]
        by_mask=dict(candidates);exact_a=min(c+q*m.bit_count() for m,c in candidates);exact_u=min(c+q for m,c in candidates)
        case=out/name;d,pr=encode(candidates,n,q)
        data=dict(case=name,source_instance_sha256=hashlib.sha256((ROOT/'runs/beam_main_v4'/name/'instance.json').read_bytes()).hexdigest(),
                  coefficients=integer,common_cost=q,scale=cfg['integer_scale'],candidates=candidates,
                  exact_additive=exact_a,exact_union=exact_u)
        case.mkdir();(case/'input.json').write_text(json.dumps(data,indent=2))
        selected={}
        for method,search in cfg['searches'].items():
            actions,actual,h=run_engine(case,d,pr,args.fd_source,args.fd_build/'bin/downward',search,method)
            assert len(actions)==2 and actions[0].startswith('choose-') and actions[1]=='materialize-common'
            mask=int(actions[0].split('-')[1]);assert mask in by_mask
            assert actual==by_mask[mask]+q
            model_a=by_mask[mask]+q*mask.bit_count()
            if method=='add':assert model_a==exact_a
            else:assert actual==exact_u
            row=dict(case=name,method=method,removed=[i for i in range(n) if mask>>i&1],
                     integer_plan_cost=actual,integer_additive_score=model_a,exact_additive=exact_a,
                     exact_union=exact_u,initial_heuristic=h,valid=True,actions=actions)
            selected[method]=mask;rows.append(row)
            with (out/'raw.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
        primary=name=='mesh2_v25_compliance_proxy_a1.0'
        if primary:
            for label,mask in [('add_selected',selected['add']),('union_selected',selected['ff'])]:
                d,pr=encode(candidates,n,q,mask)
                for method in ['add','ff']:
                    actions,actual,h=run_engine(out/('probe_'+label),d,pr,args.fd_source,args.fd_build/'bin/downward',cfg['searches'][method],method)
                    assert actions==['materialize-common'] and actual==q
                    assert h==(q*mask.bit_count() if method=='add' else q)
                    probes.append(dict(label=label,method=method,withdrawals=mask.bit_count(),initial_heuristic=h,actual_remaining_cost=q))
        best_face=[c+q for m,c in candidates if c+q*m.bit_count()==exact_a]
        case_summary.append(dict(case=name,candidates=len(candidates),add_removed=rows[-3]['removed'],
                                 union_removed=rows[-2]['removed'],add_plan_cost=rows[-3]['integer_plan_cost'],
                                 union_plan_cost=rows[-2]['integer_plan_cost'],
                                 charitable_integer_regret=(min(best_face)-exact_u)/exact_u))
    summary=dict(cases=len(case_summary),search_runs=len(rows),remaining_state_probes=len(probes),
                 all_plans_valid=True,all_additive_choices_match_integer_additive_optima=True,
                 all_ff_and_blind_choices_match_integer_union_optima=True,
                 integer_scale=cfg['integer_scale'],maximum_per_plan_rounding_error_bound=4.5e-6,
                 primary=case_summary[0],cases_detail=case_summary,state_probes=probes,
                 scope='Controlled cost-only adapter to unchanged planner; six existing beam inputs, not six independent deployments. Integer rounding is explicit; physical results are not rerun.')
    (out/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
