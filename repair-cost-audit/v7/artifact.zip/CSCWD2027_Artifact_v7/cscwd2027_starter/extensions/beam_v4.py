"""Source-grounded cantilever FE workflow; not a reproduction of industrial edits.

Bleyer benchmark geometry, elasticity, and base loading are reimplemented with
scikit-fem P2 triangles. Eight thickness proposals and volume budgets are study
extensions. Fixed transverse service load is independent of thickness.
"""
import argparse
import hashlib
import itertools
import json
import os
import platform
import random
import shutil
import statistics
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import scipy
import skfem
from scipy.sparse.linalg import splu
from skfem import Basis, MeshTri, ElementVector, ElementTriP2, BilinearForm, LinearForm, asm
from skfem.helpers import ddot, sym_grad, div

from rework.core import Instance, Problem, solve
from rework.tie_study import normalized
from rework.milp import additive_tie_envelope

PACKAGE = Path(__file__).resolve().parents[1]
REFERENCE = dict(source='https://comet-fenics.readthedocs.io/en/latest/demo/elasticity/2D_elasticity.py.html',
                 author='Jeremy Bleyer', L=25., H=1., E=1e5, nu=.3, load_y=-1e-3,
                 published_fem_tip=5.8638e-3, euler_bernoulli_tip=5.859375e-3,
                 source_mesh=[250,10], source_element='P2 crossed triangles',
                 extension='eight spanwise thickness additions and volume-budget withdrawal',
                 fixed_load='service load per in-plane area, independent of thickness')
DELTAS = [.10,.35,.20,.40,.15,.30,.25,.45]
TASKS = ['region_%d'%i for i in range(8)] + ['volume','stiffness','factorization','displacement','report']
PARENTS = [['e%d'%i] for i in range(8)] + [['a%d'%i for i in range(8)],
           ['a%d'%i for i in range(8)],['a9'],['a10'],['a8','a11']]


class Beam:
    def __init__(self, nx, ny):
        started=time.perf_counter()
        self.nx,self.ny=nx,ny
        self.mesh=MeshTri.init_tensor(np.linspace(0,25,nx+1),np.linspace(0,1,ny+1))
        self.basis=Basis(self.mesh,ElementVector(ElementTriP2()),intorder=4)
        self.fixed=self.basis.get_dofs(lambda x:np.isclose(x[0],0)).all()
        self.free=np.setdiff1d(np.arange(self.basis.N),self.fixed)
        # Known constant load is supplied to each response task, outside edit invalidation.
        @LinearForm
        def service(v,w):return -1e-3*v[1]
        self.force=asm(service,self.basis)
        self.y_dofs=self.basis.split_indices()[1]
        self.tip=int(min(self.y_dofs,key=lambda i:abs(self.basis.doflocs[0,i]-25)*100+abs(self.basis.doflocs[1,i]-.5)))
        self.setup_seconds=time.perf_counter()-started

    def matrix(self,thickness):
        mu=1e5/(2*(1+.3));lam=1e5*.3/(1-.3**2)
        @BilinearForm
        def elastic(u,v,w):
            zone=np.minimum((w.x[0]/(25/8)).astype(int),7)
            return np.take(thickness,zone)*(2*mu*ddot(sym_grad(u),sym_grad(v))+lam*div(u)*div(v))
        return asm(elastic,self.basis).tocsc()

    def task(self,k,values,removed):
        if k<8:return 1. if k in removed else 1.+DELTAS[k]
        if k==8:return (25/8)*sum(values['a%d'%i] for i in range(8))
        if k==9:return self.matrix([values['a%d'%i] for i in range(8)])
        if k==10:return splu(values['a9'][self.free][:,self.free].tocsc())
        if k==11:
            u=np.zeros(self.basis.N);u[self.free]=values['a10'].solve(self.force[self.free]);return u
        u=values['a11']
        return dict(volume=values['a8'],tip_deflection=-float(u[self.tip]),
                    compliance=float(self.force@u),displacement_norm=float(np.linalg.norm(u)))

    def build(self,removed,old=None,affected=None):
        started=time.perf_counter();values={};times=[];executed=[]
        for k in range(len(TASKS)):
            before=time.perf_counter()
            reused=old is not None and affected is not None and k not in affected
            values['a%d'%k]=old['a%d'%k] if reused else self.task(k,values,removed)
            times.append(time.perf_counter()-before);executed.append(not reused)
        return values,time.perf_counter()-started,times,executed

    def validate(self,values,removed,budget):
        u,K=values['a11'],values['a9'];residual=K@u-self.force
        relative=float(np.linalg.norm(residual[self.free])/np.linalg.norm(self.force[self.free]))
        direct_volume=25+(25/8)*sum(DELTAS[i] for i in range(8) if i not in removed)
        energy=float(u@(K@u));compliance=float(self.force@u)
        y_fixed=np.intersect1d(self.fixed,self.y_dofs)
        reaction_error=abs(float(residual[y_fixed].sum())+float(self.force[self.y_dofs].sum()))/.025
        energy_error=abs(energy-compliance)/max(compliance,1e-15)
        assert relative<1e-5 and reaction_error<1e-5 and energy_error<1e-5
        assert abs(values['a8']-direct_volume)<1e-9
        assert direct_volume<=budget+1e-9
        return dict(relative_free_residual=relative,reaction_balance_relative_error=reaction_error,
                    energy_relative_error=energy_error,volume=direct_volume,volume_limit=budget,valid=True)


def forbidden(budget):
    result=[]
    for size in range(1,9):
        for subset in itertools.combinations(range(8),size):
            if any(set(c)<=set(subset) for c in result):continue
            if 25+(25/8)*sum(DELTAS[i] for i in subset)>budget+1e-9:result.append(list(subset))
    return result


def make_instance(costs,weights,budget,metadata):
    return Instance('source_beam',list(weights),forbidden(budget),PARENTS,list(costs),metadata).validate()


def physics_weights(beam):
    base,_,_,_=beam.build(set(range(8)))
    reference=base['a12']['compliance'];benefits=[]
    for i in range(8):
        one,_,_,_=beam.build(set(range(8))-{i})
        benefits.append(reference-one['a12']['compliance'])
    assert min(benefits)>0
    return benefits,dict(base_report=base['a12'],single_proposal_benefits=benefits,
                         interpretation='isolated compliance reduction proxy; not human preference calibration')


def source_hashes():
    paths=list((PACKAGE/'rework').glob('*.py'))+[Path(__file__)]
    return {str(p.relative_to(PACKAGE)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}


def freeze(path):
    if path.exists():raise SystemExit('Refuse to overwrite protocol')
    obj=dict(version='v4_source_grounded_extension',frozen_utc=datetime.now(timezone.utc).isoformat(),
             relationship='new benchmark designed after v3 outcomes; exploratory external extension, not a new untouched population',
             reference=REFERENCE,deltas=DELTAS,meshes=[[40,2],[120,6],[240,10]],
             retained_added_volume_fractions=[.25,.5,.75],alphas=[.1,1.,10.],primary_alpha=1.,
             weight_modes=['compliance_proxy','uniform'],repeats=7,calibration_repeats=5,
             methods=['milp_additive','milp_union'],solver_limit=1.,face_tolerance=1e-8,
             warmup='one call per method and complete FE evaluation before repeats',
             timing='isolated process, randomized method order; per-case medians; include provenance and solve; setup separately',
             comparison='same solver; replay plus solve, and same-repair full-rebuild execution reference',
             validation='benchmark tip and mesh convergence, reactions, free residual, energy; compare complete displacement vectors and reports',
             statistics='deterministic grid, paired descriptive summaries; no bootstrap population claim for three meshes',
             constraints='analytic monotone volume budget only; displacement is evaluated, not an invented acceptance bound',
             exclusions='no outcome filtering; retain all grids, choices, timeouts, and zero benefits',
             weights='positive isolated compliance reductions measured at finest mesh; uniform negative control',
             hypotheses=['common expensive footprint can change intent decisions without reducing recomputation',
                         'warm planning overhead proportion falls as meaningful FE discretization grows'],
             source_sha256=source_hashes(),python=sys.version,scipy=scipy.__version__,skfem=skfem.__version__,
             numpy=np.__version__)
    path.write_text(json.dumps(obj,indent=2));print('Frozen',hashlib.sha256(path.read_bytes()).hexdigest())


def run(protocol,out):
    if out.exists():raise SystemExit('Choose fresh output directory')
    cfg=json.loads(protocol.read_text());assert source_hashes()==cfg['source_sha256']
    out.mkdir(parents=True);(out/'source_snapshot').mkdir();shutil.copy2(protocol,out/'protocol.json')
    for path in source_hashes():
        dest=out/'source_snapshot'/path;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(PACKAGE/path,dest)
    manifest=dict(protocol_sha256=hashlib.sha256(protocol.read_bytes()).hexdigest(),platform=platform.platform(),
                  source_sha256=source_hashes(),python=sys.version,started_utc=datetime.now(timezone.utc).isoformat(),
                  threads={k:os.environ.get(k) for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','VECLIB_MAXIMUM_THREADS']})
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2))
    weights_started=time.perf_counter()
    finest=Beam(*cfg['meshes'][-1]);weights,physical=physics_weights(finest)
    physical['weight_calibration_seconds']=time.perf_counter()-weights_started
    (out/'weight_calibration.json').write_text(json.dumps(physical,indent=2))
    del finest
    with (out/'raw.jsonl').open('w') as log:
        for level,(nx,ny) in enumerate(cfg['meshes']):
            beam=Beam(nx,ny)
            base,_,_,_=beam.build(set(range(8)))
            assert abs(base['a12']['tip_deflection']/REFERENCE['published_fem_tip']-1)<.02
            candidate,initial,_,_=beam.build(set())
            calibration_started=time.perf_counter()
            samples=[beam.build(set())[2] for _ in range(cfg['calibration_repeats'])]
            calibration_seconds=time.perf_counter()-calibration_started
            costs=[max(1e-9,statistics.median(x[k] for x in samples)) for k in range(len(TASKS))]
            setup=dict(mesh=[nx,ny],dofs=int(beam.basis.N),elements=beam.mesh.nelements,
                       mesh_basis_load_setup_seconds=beam.setup_seconds,initial_seconds=initial,calibration_seconds=calibration_seconds,
                       calibration_task_seconds=samples,task_cost_estimates=costs,
                       reference_base_report=base['a12'],reference_relative_error=base['a12']['tip_deflection']/REFERENCE['published_fem_tip']-1)
            (out/('mesh_%d.json'%level)).write_text(json.dumps(setup,indent=2))
            for fraction,mode,alpha in itertools.product(cfg['retained_added_volume_fractions'],cfg['weight_modes'],cfg['alphas']):
                budget=25+fraction*(25/8)*sum(DELTAS)
                case='mesh%d_v%d_%s_a%s'%(level,round(fraction*100),mode,alpha)
                directory=out/case;directory.mkdir()
                constraint_started=time.perf_counter()
                ins=make_instance(costs,weights if mode=='compliance_proxy' else [1.]*8,budget,
                                  dict(seed=level,family='public_beam_extension',mesh=[nx,ny],fraction=fraction,weight_mode=mode))
                constraint_seconds=time.perf_counter()-constraint_started
                ins.dump(directory/'instance.json');problem=Problem(normalized(ins),alpha)
                envelope=additive_tie_envelope(problem,cfg['solver_limit'],cfg['face_tolerance'])
                (directory/'tie_envelope.json').write_text(json.dumps(envelope,indent=2))
                warm=[]
                for method in cfg['methods']:
                    row=solve(ins,method,alpha,cfg['solver_limit'],normalize=True)
                    beam.build(set(row['removed']),candidate,problem.affected(row['removed']));warm.append(row)
                (directory/'warmup.json').write_text(json.dumps(warm,indent=2))
                for repeat in range(cfg['repeats']):
                    methods=list(cfg['methods']);random.Random(case+str(repeat)).shuffle(methods)
                    for order,method in enumerate(methods):
                        row=solve(ins,method,alpha,cfg['solver_limit'],normalize=True)
                        removed=set(row['removed']);started=time.perf_counter()
                        affected=Problem(ins).affected(removed)
                        values,_,task_times,executed=beam.build(removed,candidate,affected)
                        replay=time.perf_counter()-started
                        full,full_seconds,_,_=beam.build(removed)
                        checks=beam.validate(values,removed,budget)
                        equal=bool(np.allclose(values['a11'],full['a11'],rtol=1e-10,atol=1e-12)) and values['a12']==full['a12']
                        assert equal
                        row.update(case=case,repeat=repeat,order=order,mesh_level=level,nx=nx,ny=ny,dofs=int(beam.basis.N),
                                   fraction=fraction,weight_mode=mode,alpha=alpha,replay_seconds=replay,full_seconds=full_seconds,
                                   total_seconds=row['solver_seconds']+replay,task_seconds=task_times,executed_tasks=executed,
                                   replay_equal=equal,checks=checks,physical_report=values['a12'],
                                   initial_seconds=initial,mesh_setup_seconds=beam.setup_seconds,calibration_seconds=calibration_seconds,
                                   constraint_extraction_seconds=constraint_seconds,weight_calibration_seconds=physical['weight_calibration_seconds'])
                        log.write(json.dumps(row,sort_keys=True)+'\n');log.flush()
                        if repeat==0:
                            (directory/(method+'_report.json')).write_text(json.dumps(dict(removed=sorted(removed),
                                kept=[i for i in range(8) if i not in removed],physical=values['a12'],checks=checks,
                                executed=[TASKS[k] for k,b in enumerate(executed) if b]),indent=2))
                            np.savez_compressed(directory/(method+'_state.npz'),u=values['a11'])
                print('Completed',case,flush=True)
            print('Completed mesh',level,'DOFs',beam.basis.N,flush=True)
    print('Saved source-grounded workflow',out)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('command',choices=['freeze','run','validate'])
    p.add_argument('--protocol',type=Path,default=PACKAGE/'docs/FROZEN_PROTOCOL_V4.json');p.add_argument('--out',type=Path)
    args=p.parse_args()
    if args.command=='freeze':freeze(args.protocol)
    elif args.command=='run':run(args.protocol,args.out)
    else:
        results=[]
        for nx,ny in [(40,2),(120,6),(240,10)]:
            b=Beam(nx,ny);v,sec,_,_=b.build(set(range(8)));c=b.validate(v,set(range(8)),25.)
            results.append(dict(mesh=[nx,ny],dofs=int(b.basis.N),tip=v['a12']['tip_deflection'],
                                relative_error=v['a12']['tip_deflection']/REFERENCE['published_fem_tip']-1,seconds=sec,checks=c))
        print(json.dumps(results,indent=2))
