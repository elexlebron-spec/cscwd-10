"""Exhaustive physical layout reference and fixed-seed weight permutations.

The same deterministic FE implementation is reused; this tests preference
alignment within the model and provides no human utility validation.
"""
import argparse,hashlib,json,random,time
from pathlib import Path
from dataclasses import replace
from rework.core import Instance,Problem
from rework.tie_study import normalized
from .beam_v4 import Beam,DELTAS

ROOT=Path(__file__).resolve().parents[1]
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);args=ap.parse_args()
    cfg=json.loads((ROOT/'docs/FROZEN_PROTOCOL_V7.json').read_text())
    for name,digest in cfg['code_sha256'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest
    assert not args.out.exists();args.out.mkdir(parents=True)
    (args.out/'protocol.json').write_text(json.dumps(cfg,indent=2))
    beam=Beam(240,10);reference=[]
    max_volume=25+(25/8)*sum(DELTAS)
    with (args.out/'physical_layouts.jsonl').open('w') as log:
        for mask in range(256):
            removed={i for i in range(8) if mask>>i&1}
            values,seconds,_,_=beam.build(removed);checks=beam.validate(values,removed,max_volume)
            row=dict(mask=mask,removed=sorted(removed),physical=values['a12'],checks=checks,seconds=seconds)
            reference.append(row);log.write(json.dumps(row)+'\n');log.flush()
            del values
            if (mask+1)%32==0:print('Physical layouts',mask+1,256,flush=True)
    results=[]
    for fraction in [25,50,75]:
        ins=Instance.load(ROOT/'runs/beam_main_v4'/('mesh2_v%d_compliance_proxy_a1.0'%fraction)/'instance.json')
        schemes=[('aligned',None,list(range(8))),('uniform',None,list(range(8)))]
        for seed in cfg['permutation_seeds']:
            perm=list(range(8));random.Random(seed).shuffle(perm);schemes.append(('permuted',seed,perm))
        for mode,seed,perm in schemes:
            weights=[1.]*8 if mode=='uniform' else [ins.losses[i] for i in perm]
            p=Problem(normalized(replace(ins,losses=weights)),1.)
            feasible=[r for r in reference if p.feasible(r['removed'])]
            physical_optimum=min(r['physical']['compliance'] for r in feasible)
            model_rows=[]
            for model in ['additive','union']:
                optimum=min(p.cost(r['removed'],model) for r in feasible)
                face=[r for r in feasible if abs(p.cost(r['removed'],model)-optimum)<=cfg['enumeration_tolerance']]
                by_mechanics=sorted(face,key=lambda r:(r['physical']['compliance'],r['mask']))
                best,worst=by_mechanics[0],by_mechanics[-1]
                model_rows.append(dict(model=model,optimum=optimum,face_size=len(face),
                    best_mechanical_removed=best['removed'],worst_mechanical_removed=worst['removed'],
                    min_compliance=best['physical']['compliance'],max_compliance=worst['physical']['compliance'],
                    min_mechanical_regret=(best['physical']['compliance']-physical_optimum)/physical_optimum,
                    max_mechanical_regret=(worst['physical']['compliance']-physical_optimum)/physical_optimum))
            a,u=model_rows;U=u['optimum']
            aface=[r for r in feasible if abs(p.cost(r['removed'],'additive')-a['optimum'])<=cfg['enumeration_tolerance']]
            best_union_on_add=min(p.cost(r['removed'],'union') for r in aface)
            results.append(dict(fraction=fraction,mode=mode,seed=seed,permutation=perm,physical_optimum=physical_optimum,
                physical_optimal_removed=[r['removed'] for r in feasible if abs(r['physical']['compliance']-physical_optimum)<=1e-14],
                additive=a,union=u,charitable_objective_regret=(best_union_on_add-U)/U,
                physical_improvement_best_faces=(a['min_compliance']-u['min_compliance'])/a['min_compliance']))
    (args.out/'selection.json').write_text(json.dumps(results,indent=2))
    print('Saved physical reference and permutation selections',len(results),flush=True)
if __name__=='__main__':main()
