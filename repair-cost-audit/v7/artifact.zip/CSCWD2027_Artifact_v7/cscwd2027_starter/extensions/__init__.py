"""Disclosed extensions kept separate from the frozen v3 research modules."""
