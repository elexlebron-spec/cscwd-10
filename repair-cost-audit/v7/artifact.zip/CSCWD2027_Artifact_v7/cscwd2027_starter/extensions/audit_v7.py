"""Revision v7: explicit core baseline and integer-coefficient certification.

The old modules are imported unchanged. Solver status is distinct from exact
Python integer recomputation and independent membership checks.
"""
import argparse
from dataclasses import replace
from fractions import Fraction
import hashlib,json,math,random,statistics,time
from pathlib import Path
import numpy as np
from rework.core import Instance,Problem
from rework.tie_study import normalized
from rework.milp import _formulation,_run,_candidate,_diagnostics
from .accounting_v5 import common_core,residuals_disjoint

ROOT=Path(__file__).resolve().parents[1]

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def integer_vectors(ins,alpha):
    assert all(int(x)==x for x in ins.losses+ins.work)
    p=Problem(ins,alpha);P=sum(map(int,ins.losses));C=sum(map(int,ins.work))
    ratio=Fraction(str(alpha));num,den=ratio.numerator,ratio.denominator
    u=[den*C*int(x) for x in ins.losses]+[num*P*int(x) for x in ins.work]
    a=[den*C*int(x)+num*P*sum(int(ins.work[k]) for k in p.fp[i]) for i,x in enumerate(ins.losses)]+[0]*len(ins.work)
    assert sum(abs(x) for x in u+a)<2**53
    return u,a,den*P*C

def integer_value(ins,removed,alpha,model):
    u,a,scale=integer_vectors(ins,alpha);p=Problem(ins,alpha)
    if model=='additive':return sum(a[i] for i in removed)
    return sum(u[i] for i in removed)+sum(u[len(ins.losses)+k] for k in p.affected(removed))

def core_select(ins,alpha,model,timeout):
    start=time.perf_counter();p=Problem(normalized(ins),alpha)
    linked=model=='union';u,a,A,lo,hi=_formulation(p,linked)
    constant=0.
    if model=='union':c=u
    elif model=='additive':c=a
    else:
        core=common_core(p.fp);constant=alpha*sum(p.instance.work[k] for k in core)
        c=np.array([x+alpha*sum(p.instance.work[k] for k in p.fp[i]-core) for i,x in enumerate(p.instance.losses)])
        if not p.edges:
            return dict(model=model,removed=[],status=0,certified=True,objective=0.,intent=0.,work=0.,model_value=0.,seconds=time.perf_counter()-start,core_exact=residuals_disjoint(p.fp),mip_gap=0.,mip_dual_bound=0.)
    result=_run(c*1e6,A,lo,hi,timeout);removed=_candidate(result,p)
    elapsed=time.perf_counter()-start
    assert removed is not None
    return dict(model=model,removed=sorted(removed),status=int(result.status),certified=bool(result.status==0 and result.success),
                objective=p.cost(removed,'union'),intent=sum(p.instance.losses[i] for i in removed),
                work=sum(p.instance.work[k] for k in p.affected(removed)),
                model_value=float(sum(c[i] for i in removed)+constant) if not linked else p.cost(removed,'union'),
                seconds=elapsed,core_exact=residuals_disjoint(p.fp),objective_scale=1000000,**_diagnostics(result))

def integer_audit(ins,alpha,timeout):
    p=Problem(ins,alpha);u,a,scale=integer_vectors(ins,alpha)
    _,_,A,lo,hi=_formulation(p,True);steps={};first=None
    for label in ['additive','best_face','worst_face','union']:
        c=a if label=='additive' else ([-x for x in u] if label=='worst_face' else u)
        if label.endswith('face') and first is None:continue
        extra=(a,first,first) if label.endswith('face') else None
        r=_run(c,A,lo,hi,timeout,extra=extra);removed=_candidate(r,p)
        d=dict(**_diagnostics(r,label),removed=sorted(removed) if removed is not None else None)
        if removed is not None:
            av=integer_value(ins,removed,alpha,'additive');uv=integer_value(ins,removed,alpha,'union')
            value=av if label=='additive' else (-uv if label=='worst_face' else uv)
            bound=getattr(r,'mip_dual_bound',None)
            d.update(additive_integer=av,union_integer=uv,
                exact_face_member=(av==first) if label.endswith('face') else True,
                objective_recomputation=abs(float(r.fun)-value)<=1e-5,
                integer_bound_matches=bound is not None and math.isfinite(bound) and math.ceil(bound-1e-6)==value)
            d['certified']=bool(r.status==0 and r.success and d['exact_face_member'] and d['objective_recomputation'] and d['integer_bound_matches'])
        else:d['certified']=False
        steps[label]=d
        if label=='additive' and d['certified']:first=av
    certified=len(steps)==4 and all(x['certified'] for x in steps.values())
    row=dict(alpha=alpha,scale=scale,steps=steps,all_certified=certified)
    if certified:
        opt=steps['union']['union_integer'];best=steps['best_face']['union_integer'];worst=steps['worst_face']['union_integer']
        assert opt<=best<=worst
        row.update(best_regret=(best-opt)/opt,positive=best>opt,tie_sensitive=worst>best)
    return row

def run_baseline(cfg,out):
    raw=[];warms=[];models=cfg['models']
    cases=sorted((ROOT/'runs/beam_main_v4').glob('mesh*_v*/instance.json'))
    assert len(cases)==54
    for f in cases:
        ins=Instance.load(f);alpha=float(f.parent.name.rsplit('_a',1)[1])
        for model in models:warms.append(dict(case=f.parent.name,**core_select(ins,alpha,model,cfg['solver_limit'])))
    # Timing happens alone, with no concurrent tests or FE runs.
    with (out/'baseline_raw.jsonl').open('w') as log:
        for repeat in range(cfg['repeats']):
            order=list(cases);random.Random(270700+repeat).shuffle(order)
            for f in order:
                ins=Instance.load(f);alpha=float(f.parent.name.rsplit('_a',1)[1]);methods=list(models)
                random.Random(str(repeat)+f.parent.name).shuffle(methods)
                for position,model in enumerate(methods):
                    row=dict(case=f.parent.name,repeat=repeat,order=position,input_sha256=sha(f),**core_select(ins,alpha,model,cfg['solver_limit']))
                    assert row['certified'];raw.append(row);log.write(json.dumps(row)+'\n');log.flush()
            print('Baseline repeat',repeat+1,flush=True)
    (out/'baseline_warmup.json').write_text(json.dumps(warms,indent=2))
    # One-shot decision audit on existing structural inputs; no timing comparison.
    with (out/'structural_core.jsonl').open('w') as log:
        for f in sorted((ROOT/'runs/structural_main_v3/instances').glob('*.json')):
            row=dict(instance_id=f.stem,input_sha256=sha(f),**core_select(Instance.load(f),1.,'core',cfg['solver_limit']))
            log.write(json.dumps(row)+'\n')
    print('Baseline saved',len(raw),flush=True)

def run_integer(cfg,out):
    old=[json.loads(s) for s in (ROOT/'runs/structural_main_v3/raw.jsonl').read_text().splitlines()]
    with (out/'integer_raw.jsonl').open('w') as log:
        for i,r in enumerate(old):
            f=ROOT/'runs/structural_main_v3/instances'/(r['instance_id']+'.json')
            row=dict(instance_id=r['instance_id'],old_certified=r['all_certified'],input_sha256=sha(f),**integer_audit(Instance.load(f),r['alpha'],cfg['solver_limit']))
            if r['all_certified'] and row['all_certified']:row['old_regret_deviation']=row['best_regret']-r['best_regret']
            log.write(json.dumps(row)+'\n');log.flush()
            if (i+1)%100==0:print('Integer audit',i+1,len(old),flush=True)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['baseline','integer']);ap.add_argument('--out',type=Path,required=True);args=ap.parse_args()
    cfg=json.loads((ROOT/'docs/FROZEN_PROTOCOL_V7.json').read_text())
    for name,digest in cfg['code_sha256'].items():assert sha(ROOT/name)==digest,name
    assert not args.out.exists();args.out.mkdir(parents=True)
    (args.out/'protocol.json').write_text(json.dumps(cfg,indent=2))
    (run_baseline if args.mode=='baseline' else run_integer)(cfg,args.out)
if __name__=='__main__':main()
