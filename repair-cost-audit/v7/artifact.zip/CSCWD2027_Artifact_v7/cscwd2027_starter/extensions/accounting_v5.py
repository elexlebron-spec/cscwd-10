"""Contract checks for common work. Elementary identities, not a new optimizer.

The cost scale must remain fixed during a common-cost intervention. Renormalizing
by a changing total would also change preferences and invalidate the test.
"""
from collections import Counter


def common_core(footprints):
    return set.intersection(*(set(f) for f in footprints)) if footprints else set()


def residuals_disjoint(footprints):
    core = common_core(footprints)
    counts = Counter(a for f in footprints for a in set(f) - core)
    return all(v == 1 for v in counts.values())


def costs(removed, losses, work, footprints, beta=1.):
    """Union, isolated-sum, and common-core-corrected values in fixed units."""
    removed = set(removed)
    loss = sum(losses[i] for i in removed)
    affected = set().union(*(set(footprints[i]) for i in removed)) if removed else set()
    union = loss + beta * sum(work[a] for a in affected)
    additive = loss + beta * sum(sum(work[a] for a in footprints[i]) for i in removed)
    k = sum(work[a] for a in common_core(footprints))
    corrected = additive - beta * k * max(len(removed) - 1, 0)
    return union, additive, corrected


def optimum_face(rows, position, tolerance=1e-8):
    best = min(r[position] for r in rows)
    return [r for r in rows if abs(r[position] - best) <= tolerance]
