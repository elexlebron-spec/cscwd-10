"""Run unchanged Fast Downward on prespecified controlled sharing probes.

This is an implementation witness for additive goal-cost aggregation, not a
claim about an industrial repair deployment or a novel planning heuristic.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]


def pddl(n,q,initial='undecided'):
    predicates=' '.join('('+x+')' for x in ['undecided','branch-a','branch-b','shared']+
                        ['g%d'%i for i in range(n)])
    actions=[]
    def action(name,pre,add,cost,delete=()):
        effects=['('+s+')' for s in add]+['(not ('+s+'))' for s in delete]
        effects+=['(increase (total-cost) %d)'%cost]
        actions.append('(:action %s :parameters () :precondition (and %s) :effect (and %s))'%(
            name,' '.join('('+s+')' for s in pre),' '.join(effects)))
    action('choose-a',['undecided'],['branch-a'],0,['undecided'])
    action('choose-b',['undecided'],['branch-b'],0,['undecided'])
    action('shared-a',['branch-a'],['shared'],q)
    for i in range(n):
        action('finish-a-%d'%i,['branch-a','shared'],['g%d'%i],1)
        action('finish-b-%d'%i,['branch-b'],['g%d'%i],3)
    domain='(define (domain sharing-probe) (:requirements :strips :action-costs) (:predicates %s) (:functions (total-cost)) %s)'%(predicates,'\n'.join(actions))
    problem='(define (problem p) (:domain sharing-probe) (:init (%s) (= (total-cost) 0)) (:goal (and %s)) (:metric minimize (total-cost)))'%(initial,' '.join('(g%d)'%i for i in range(n)))
    return domain,problem


def validate_plan(actions,n,q,initial='undecided'):
    facts={initial};cost=0
    for name in actions:
        if name in ['choose-a','choose-b']:
            assert 'undecided' in facts
            facts.remove('undecided');facts.add('branch-'+name[-1])
        elif name=='shared-a':
            assert 'branch-a' in facts
            facts.add('shared');cost+=q
        elif name.startswith('finish-'):
            _,branch,index=name.split('-');i=int(index)
            assert 0<=i<n and 'branch-'+branch in facts
            if branch=='a':assert 'shared' in facts
            facts.add('g%d'%i);cost+=1 if branch=='a' else 3
        else:raise AssertionError(name)
    assert all('g%d'%i in facts for i in range(n))
    return cost


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--fd-source',type=Path,required=True)
    ap.add_argument('--fd-build',type=Path,required=True)
    ap.add_argument('--out',type=Path,required=True)
    args=ap.parse_args();out=args.out.resolve()
    assert not out.exists(),'Preserve existing observations'
    cfg=json.loads((ROOT/'docs/FROZEN_PROTOCOL_V6.json').read_text())
    for name,sha in cfg['code_sha256'].items():
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==sha
    for name,sha in cfg['planner_source_sha256'].items():
        assert hashlib.sha256((args.fd_source/name).read_bytes()).hexdigest()==sha
    out.mkdir(parents=True)
    (out/'protocol.json').write_text(json.dumps(cfg,indent=2))
    translator=args.fd_source/'src/translate/translate.py'
    binary=args.fd_build/'bin/downward'
    settings=[(n,q,'undecided') for n in cfg['goals'] for q in cfg['shared_costs']]
    settings += [(4,4,'branch-a'),(4,4,'branch-b')]
    rows=[]
    for n,q,initial in settings:
        case=out/('n%d_q%d_%s'%(n,q,initial));case.mkdir()
        d,p=pddl(n,q,initial)
        (case/'domain.pddl').write_text(d);(case/'problem.pddl').write_text(p)
        trans=subprocess.run([sys.executable,str(translator),'domain.pddl','problem.pddl',
                              '--sas-file','output.sas'],cwd=case,text=True,capture_output=True,timeout=30)
        (case/'translate.log').write_text(trans.stdout+trans.stderr)
        assert trans.returncode==0,trans.stdout+trans.stderr
        methods=cfg['searches'] if initial=='undecided' else {k:v for k,v in cfg['searches'].items() if k!='optimal_blind'}
        for method,search in methods.items():
            plan=method+'.plan'
            with (case/'output.sas').open() as stream:
                run=subprocess.run([str(binary),'--search',search,'--internal-plan-file',plan],
                                   cwd=case,stdin=stream,text=True,capture_output=True,timeout=30)
            (case/(method+'.log')).write_text(run.stdout+run.stderr)
            assert run.returncode==0,run.stdout+run.stderr
            lines=(case/plan).read_text().splitlines()
            actions=[s.strip()[1:-1].strip() for s in lines if s.strip().startswith('(')]
            actual=validate_plan(actions,n,q,initial)
            printed=int(re.search(r'Plan cost: (\d+)',run.stdout)[1]);assert actual==printed
            h=re.search(r'Initial heuristic value for [^:]+: (\d+)',run.stdout)
            optimum=min(q+n,3*n) if initial=='undecided' else q+n if initial=='branch-a' else 3*n
            if method=='optimal_blind':assert actual==optimum
            row=dict(case=case.name,n=n,shared_cost=q,initial=initial,method=method,
                     initial_heuristic=int(h[1]) if h else None,plan_cost=actual,
                     analytical_optimum=optimum,absolute_regret=actual-optimum,
                     selected_branch='a' if any('a'==s[-1] for s in actions if s.startswith('choose-')) else
                                     'b' if initial=='undecided' else initial[-1],
                     actions=actions,valid=True,source_unchanged=True,
                     search=search)
            rows.append(row)
            with (out/'raw.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
    primary=[r for r in rows if r['n']==4 and r['shared_cost']==4]
    probe={r['initial']+'_'+r['method']:r for r in primary}
    assert probe['branch-a_add']['initial_heuristic']==20
    assert probe['branch-a_ff']['initial_heuristic']==8
    assert probe['branch-b_add']['initial_heuristic']==12
    assert probe['branch-b_ff']['initial_heuristic']==12
    summary=dict(source_commit=cfg['planner_commit'],settings=12,branch_state_probes=2,
                 engine_runs=len(rows),all_plans_valid=True,unchanged_upstream_source=True,
                 primary=dict(add_cost=probe['undecided_add']['plan_cost'],
                              ff_cost=probe['undecided_ff']['plan_cost'],
                              optimum=probe['undecided_optimal_blind']['plan_cost'],
                              shared_branch_hadd=20,shared_branch_hff=8,independent_branch_estimate=12),
                 additive_suboptimal=sum(r['absolute_regret']>0 for r in rows if r['initial']=='undecided' and r['method']=='add'),
                 ff_suboptimal=sum(r['absolute_regret']>0 for r in rows if r['initial']=='undecided' and r['method']=='ff'),
                 scope='Controlled implementation witness. add() is a search heuristic, not the final action-cost objective or an industrial repair selector.')
    (out/'summary.json').write_text(json.dumps(summary,indent=2))
    (out/'source_receipt.json').write_text(json.dumps(dict(
        commit=cfg['planner_commit'],source_hashes=cfg['planner_source_sha256'],
        binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
        python=sys.version,command_template='python -m extensions.planner_v6 --fd-source <SOURCE> --fd-build <BUILD> --out <NEW_OUTPUT>'),indent=2))
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
