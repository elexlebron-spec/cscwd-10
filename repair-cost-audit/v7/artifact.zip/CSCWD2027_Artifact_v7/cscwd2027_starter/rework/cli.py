import argparse
import csv
import hashlib
import itertools
import json
import platform
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

from .core import METHODS, Instance, generate, overlap, rebuild, replay_check, solve


def csv_list(text, kind):
    return [kind(x) for x in text.split(",")]


def main():
    parser = argparse.ArgumentParser(description="Shared-rework research scaffold")
    commands = parser.add_subparsers(dest="command", required=True)
    run = commands.add_parser("run")
    run.add_argument("--config", type=Path, required=True)
    run.add_argument("--out", type=Path, required=True)
    summary = commands.add_parser("summarize")
    summary.add_argument("--run", type=Path, required=True)
    args = parser.parse_args()
    if args.command == "summarize":
        summarize(args.run)
        return
    config = json.loads(args.config.read_text())
    if args.out.exists():
        raise SystemExit("Output exists; choose a fresh --out directory to preserve evidence")
    args.out.mkdir(parents=True)
    (args.out / "instances").mkdir()
    (args.out / "config.json").write_text(json.dumps(config, indent=2))
    try:
        revision = subprocess.check_output(["git", "rev-parse", "HEAD"], stderr=subprocess.DEVNULL, text=True).strip()
        dirty = bool(subprocess.check_output(["git", "status", "--porcelain"], text=True).strip())
    except (subprocess.CalledProcessError, FileNotFoundError):
        revision, dirty = "unversioned", True
    # Code hashes are authoritative even when Git history is absent or dirty.
    hashes = {str(p.relative_to(Path(__file__).parent)): hashlib.sha256(p.read_bytes()).hexdigest()
              for p in sorted(Path(__file__).parent.rglob("*.py"))}
    manifest = dict(created_utc=datetime.now(timezone.utc).isoformat(),
                    python=sys.version, platform=platform.platform(), machine=platform.machine(),
                    git_revision=revision, git_dirty=dirty, source_sha256=hashes,
                    config_sha256=hashlib.sha256(args.config.read_bytes()).hexdigest(),
                    evidence_status=config.get("evidence_status", "development_only"))
    (args.out / "manifest.json").write_text(json.dumps(manifest, indent=2))
    counts = 0
    jobs = []
    for family in config["families"]:
        sharing_values = [0.0] if family == "disjoint" else config["sharing"]
        jobs.extend((family, n, sharing, density, seed)
                    for n, sharing, density, seed in itertools.product(
                        config["sizes"], sharing_values, config["densities"], config["seeds"]))
    with (args.out / "raw.jsonl").open("w") as output:
        for job_no, (family, n, sharing, density, seed) in enumerate(jobs):
            ins = generate(seed=seed, n=n, sharing=sharing, density=density, family=family)
            instance_id = "case_%05d" % job_no
            ins.dump(args.out / "instances" / (instance_id + ".json"))
            old = rebuild(ins, set(), config.get("replay_scale", 10))
            for method in config["methods"]:
                if method not in METHODS:
                    raise ValueError("Unknown method: " + method)
                if method.startswith("exact_") and n > config.get("exact_max_n", 22):
                    continue
                row = solve(ins, method, config.get("alpha", 1.0), config.get("exact_timeout", 5.0),
                            normalize=config.get("normalize_objective", False), random_seed=seed)
                row.update(replay_check(ins, row["removed"], config.get("replay_scale", 10), old))
                if not row["replay_equal"] or not row["final_valid"]:
                    raise RuntimeError("Independent replay validation failed: " + instance_id)
                row.update(instance_id=instance_id, instance_name=ins.name, family=family, n=n,
                           sharing_control=sharing, density_control=density, seed=seed,
                           overlap=overlap(ins), conflict_count=len(ins.conflicts),
                           artifact_count=len(ins.parents), alpha=config.get("alpha", 1.0),
                           evidence_status=manifest["evidence_status"])
                output.write(json.dumps(row, sort_keys=True) + "\n")
                output.flush()
                counts += 1
            if (job_no + 1) % 25 == 0:
                print("Completed %d/%d instances" % (job_no + 1, len(jobs)), flush=True)
    print("Saved %d method-instance records to %s" % (counts, args.out))
    summarize(args.out)


def summarize(run):
    import statistics
    rows = [json.loads(s) for s in (run / "raw.jsonl").read_text().splitlines()]
    result = []
    for method in sorted(set(r["method"] for r in rows)):
        group = [r for r in rows if r["method"] == method]
        result.append(dict(method=method, records=len(group),
                           mean_objective=statistics.mean(r["objective"] for r in group),
                           mean_rework_units=statistics.mean(r["rework_units"] for r in group),
                           mean_intent_loss=statistics.mean(r["intent_loss"] for r in group),
                           mean_solver_ms=1000 * statistics.mean(r["solver_seconds"] for r in group),
                           certified_optima=sum(r["status"] == "optimal" for r in group),
                           timeouts=sum(r["status"] == "timeout_feasible" or r.get("milp_status") == 1 for r in group),
                           noncertified_reference=sum((r["method"].startswith(("exact_", "milp_"))
                                                       and r["status"] != "optimal") for r in group),
                           all_replay_valid=all(r["replay_equal"] and r["final_valid"] for r in group)))
    if result:
        with (run / "summary.csv").open("w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(result[0]))
            writer.writeheader()
            writer.writerows(result)
    print(json.dumps(result, indent=2))
    print("Descriptive development summary only. Compare paired instances and strata before inference.")


if __name__ == "__main__":
    main()
