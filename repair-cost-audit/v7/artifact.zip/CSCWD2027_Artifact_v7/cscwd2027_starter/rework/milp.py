"""A conventional binary MILP baseline using SciPy/HiGHS, not a new algorithm.

x_i withdraws edit i; z_a is the OR of withdrawals affecting artifact a.
The formulation has one hit constraint per forbidden combination and exact
OR-link constraints. The additive baseline uses the SAME solver and inputs.
"""
import math


def _libraries():
    try:
        import numpy as np
        from scipy.optimize import Bounds, LinearConstraint, milp
        from scipy.sparse import coo_matrix
    except ImportError as error:
        raise RuntimeError("MILP requires optional SciPy: use the documented .venv-research environment") from error
    return np, Bounds, LinearConstraint, milp, coo_matrix


def _formulation(problem, linked):
    np, Bounds, LinearConstraint, milp, coo_matrix = _libraries()
    n, artifacts = len(problem.instance.losses), len(problem.instance.work)
    dim = n + artifacts if linked else n
    union_cost = list(problem.instance.losses) + ([problem.alpha * c for c in problem.instance.work] if linked else [])
    additive_cost = [p + problem.alpha * sum(problem.instance.work[a] for a in problem.fp[i])
                     for i, p in enumerate(problem.instance.losses)] + ([0.] * artifacts if linked else [])
    row_indexes, columns, coefficients, lower, upper = [], [], [], [], []
    def constraint(items, lo, hi):
        r = len(lower)
        for col, value in items:
            row_indexes.append(r); columns.append(col); coefficients.append(value)
        lower.append(lo); upper.append(hi)
    for edge in problem.edges:
        constraint([(i, 1) for i in sorted(edge)], 1, np.inf)
    if linked:
        for a in range(artifacts):
            roots = [i for i in range(n) if a in problem.fp[i]]
            for i in roots:
                constraint([(n + a, 1), (i, -1)], 0, np.inf)
            constraint([(n + a, 1)] + [(i, -1) for i in roots], -np.inf, 0)
    matrix = coo_matrix((coefficients, (row_indexes, columns)), shape=(len(lower), dim)).tocsc()
    return np.array(union_cost), np.array(additive_cost), matrix, np.array(lower), np.array(upper)


def _run(objective, matrix, lower, upper, timeout, extra=None):
    np, Bounds, LinearConstraint, milp, coo_matrix = _libraries()
    constraints = [LinearConstraint(matrix, lower, upper)] if len(lower) else []
    if extra is not None:
        vector, lo, hi = extra
        constraints.append(LinearConstraint(np.array([vector]), [lo], [hi]))
    return milp(np.array(objective, dtype=float), integrality=np.ones(len(objective)),
                bounds=Bounds(np.zeros(len(objective)), np.ones(len(objective))), constraints=constraints,
                options={"time_limit": max(0., timeout), "mip_rel_gap": 0., "presolve": True})


def _candidate(result, problem):
    if result.x is not None and all(abs(v - round(v)) <= 1e-5 for v in result.x):
        candidate = {i for i in range(len(problem.instance.losses)) if result.x[i] > .5}
        if problem.feasible(candidate):
            return candidate
    return None


def _diagnostics(result, prefix="milp"):
    def finite(field):
        value = getattr(result, field, None)
        return float(value) if value is not None and math.isfinite(value) else None
    return {prefix + "_status": int(result.status), prefix + "_message": str(result.message),
            prefix + "_gap": finite("mip_gap"), prefix + "_dual_bound": finite("mip_dual_bound"),
            prefix + "_nodes": finite("mip_node_count")}


def milp_repair(problem, model="union", timeout=5.0):
    from .core import greedy
    if model not in ("union", "additive"):
        raise ValueError(model)
    u, a, matrix, lower, upper = _formulation(problem, model == "union")
    objective = u if model == "union" else a
    result = _run(objective, matrix, lower, upper, timeout)
    removed = _candidate(result, problem)
    if removed is None:
        removed = greedy(problem, model)
        status = "milp_no_incumbent_fallback_feasible"
    else:
        status = "optimal" if result.status == 0 and result.success else "milp_limit_feasible"
    return removed, status, dict(**_diagnostics(result),
                                 milp_variable_count=len(objective), milp_constraint_count=len(lower))


def additive_tie_envelope(problem, timeout=1., tolerance=1e-8):
    """Best/worst union cost on the additive-optimal face, within stated tolerance.

    Three conventional MILPs, each with its own solver time limit. Negative
    union objective is used for the worst case; no new algorithm is claimed.
    """
    u, a, matrix, lower, upper = _formulation(problem, True)
    first = _run(a, matrix, lower, upper, timeout)
    first_removed = _candidate(first, problem)
    base = dict(primary_certified=bool(first.status == 0 and first.success and first_removed is not None),
                tolerance=tolerance, per_solve_time_limit=timeout, **_diagnostics(first, "primary"))
    if not base["primary_certified"]:
        return dict(**base, range_certified=False, reason="primary not certified")
    optimal = problem.cost(first_removed, "additive")
    base.update(additive_optimum=optimal, default_removed=sorted(first_removed),
                default_union_cost=problem.cost(first_removed, "union"))
    results = {}
    for label, direction in (("best", 1), ("worst", -1)):
        result = _run(direction * u, matrix, lower, upper, timeout,
                      extra=(a, optimal - tolerance, optimal + tolerance))
        removed = _candidate(result, problem)
        in_face = removed is not None and abs(problem.cost(removed, "additive") - optimal) <= tolerance * 1.01
        certified = bool(result.status == 0 and result.success and in_face)
        results[label + "_certified"] = certified
        results.update(_diagnostics(result, label))
        if removed is not None:
            results[label + "_removed"] = sorted(removed)
            results[label + "_union_cost"] = problem.cost(removed, "union")
            results[label + "_additive_deviation"] = problem.cost(removed, "additive") - optimal
    return dict(**base, **results, range_certified=results["best_certified"] and results["worst_certified"])
