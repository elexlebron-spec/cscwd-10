"""Paired, seed-cluster bootstrap. Smoke estimates are descriptive only."""
import argparse
import csv
import json
import random
import statistics
from collections import defaultdict
from pathlib import Path


def percentile(values, fraction):
    s = sorted(values)
    x = (len(s) - 1) * fraction
    lo = int(x)
    hi = min(lo + 1, len(s) - 1)
    return s[lo] * (hi - x) + s[hi] * (x - lo) if hi != lo else s[lo]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", required=True, type=Path)
    parser.add_argument("--bootstrap", type=int, default=2000)
    args = parser.parse_args()
    if args.bootstrap < 1:
        raise SystemExit("bootstrap must be positive")
    records = [json.loads(x) for x in (args.run / "raw.jsonl").read_text().splitlines()]
    by_case = defaultdict(dict)
    for r in records:
        by_case[r["instance_id"]][r["method"]] = r
    comparisons = [("union_multistart", "additive_multistart"),
                   ("union_greedy", "additive_greedy"),
                   ("union_multistart", "union_greedy"),
                   ("exact_union", "exact_additive")]
    results = []
    for target, base in comparisons:
        strata = defaultdict(list)
        for case in by_case.values():
            if target not in case or base not in case:
                continue
            t, b = case[target], case[base]
            if target.startswith("exact") and (t["status"] != "optimal" or b["status"] != "optimal"):
                continue
            value = (b["objective"] - t["objective"]) / b["objective"] if b["objective"] else 0.0
            for stratum in [("ALL", "ALL", "ALL", "ALL"),
                            (t["family"], t["n"], t["sharing_control"], t["density_control"])]:
                strata[stratum].append((t["seed"], value))
        for stratum, values in strata.items():
            clusters = defaultdict(list)
            for seed, value in values:
                clusters[seed].append(value)
            seeds = sorted(clusters)
            rng = random.Random(20271027)
            samples = []
            for _ in range(args.bootstrap):
                chosen = [rng.choice(seeds) for _ in seeds]
                samples.append(statistics.mean(v for s in chosen for v in clusters[s]))
            results.append(dict(target=target, baseline=base, family=stratum[0], n=stratum[1],
                                sharing_control=stratum[2], density_control=stratum[3],
                                instances=len(values), independent_seed_clusters=len(seeds),
                                mean_relative_objective_reduction=statistics.mean(v for _, v in values),
                                ci95_low=percentile(samples, .025), ci95_high=percentile(samples, .975),
                                positive_instances=sum(v > 0 for _, v in values),
                                negative_instances=sum(v < 0 for _, v in values),
                                interpretation="development_only" if len(seeds) < 20 else "check_frozen_protocol"))
    out = args.run / "paired_analysis.csv"
    with out.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(results[0]) if results else ["target"])
        writer.writeheader()
        writer.writerows(results)
    print("Saved", out)
    print("Primary comparison must be chosen before test data. Cost-model improvements alone do not establish practical speedups.")


if __name__ == "__main__":
    main()
