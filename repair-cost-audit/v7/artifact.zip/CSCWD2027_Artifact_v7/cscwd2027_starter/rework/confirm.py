"""Run held-out evaluation only against an immutable, hash-checked protocol."""
import argparse
import hashlib
import itertools
import json
import platform
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

from .core import generate
from .tie_study import evaluate


def code_hashes():
    return {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(Path(__file__).parent.glob("*.py"))}


def freeze(path):
    if path.exists():
        raise SystemExit("Freeze exists; amendments require a new version and disclosed reason")
    import scipy, numpy
    protocol = dict(version="v3", frozen_utc=datetime.now(timezone.utc).isoformat(),
                    title="When Additive Repair Costs Mislead Collaborative Design Workflows",
                    scope="held-out validation within one synthetic generator and one illustrative function-chain family",
                    novelty_status="amber; publisher article full text unresolved; public artifact inspected separately",
                    primary_alpha=1., alphas=[.1, 1., 10.], tolerance=1e-8, per_milp_time_limit=1.,
                    families=["disjoint", "mixed", "hub"], sizes=[12, 20, 40], sharing=[.3, .7], density=1.,
                    structural_seeds=list(range(1000, 1030)), semantic_seeds=list(range(2000, 2030)),
                    semantic_repeats=7, semantic_methods=["milp_additive", "milp_union", "exact_additive", "exact_union"],
                    primary_metric="(best_union_cost_on_additive_optimal_face - union_optimum) / union_optimum",
                    secondary_metrics=["default and worst tie regret", "nonzero regret incidence", "intent loss fraction", "measured solve+replay and full rebuild"],
                    analysis="seed-cluster percentile bootstrap, 2000 resamples, fixed RNG 20261028; per-instance timing medians first",
                    certification="all four MILPs certified for regret; report full coverage and incomplete rows",
                    thresholds=dict(positive_regret=1e-8, practically_nonzero_regret=.01, desired_certificate_coverage=.95),
                    timing_policy="semantic run executed separately; no structural-kernel speed claim; include provenance overhead and shared setup",
                    exclusion_policy="no outcome-based exclusions; retain invalid and incomplete rows and stop on independent validation failure",
                    alpha_policy="alpha 1 primary, .1 and 10 sensitivity regardless of outcomes",
                    python=sys.version, scipy=scipy.__version__, numpy=numpy.__version__, code_sha256=code_hashes())
    path.write_text(json.dumps(protocol, indent=2))
    print("Frozen protocol before held-out generation:", path)
    print("SHA256:", hashlib.sha256(path.read_bytes()).hexdigest())


def execute(protocol_path, out, kind):
    if out.exists():
        raise SystemExit("Choose a fresh run directory")
    p = json.loads(protocol_path.read_text())
    if code_hashes() != p["code_sha256"]:
        raise SystemExit("Code differs from frozen protocol. Disclose an amendment before any new run.")
    digest = hashlib.sha256(protocol_path.read_bytes()).hexdigest()
    if kind == "semantic":
        from .workflow import run
        run(out, p["semantic_seeds"], p["semantic_repeats"], p["semantic_methods"], p["primary_alpha"],
            p["per_milp_time_limit"], evidence_status="held_out_frozen_parameter_validation", protocol_sha256=digest)
        shutil.copy2(protocol_path, out / "frozen_protocol.json")
        return
    out.mkdir(parents=True)
    (out / "instances").mkdir(); (out / "source_snapshot").mkdir()
    for module in Path(__file__).parent.glob("*.py"):
        shutil.copy2(module, out / "source_snapshot" / module.name)
    shutil.copy2(protocol_path, out / "frozen_protocol.json")
    manifest = dict(protocol_sha256=digest, code_sha256=code_hashes(), python=sys.version,
                    platform=platform.platform(), evidence_status="held_out_frozen_controlled_benchmark",
                    started_utc=datetime.now(timezone.utc).isoformat())
    (out / "manifest.json").write_text(json.dumps(manifest, indent=2))
    cases = []
    for family in p["families"]:
        controls = [0.] if family == "disjoint" else p["sharing"]
        cases.extend((family, n, sharing, seed) for n, sharing, seed in itertools.product(p["sizes"], controls, p["structural_seeds"]))
    with (out / "raw.jsonl").open("w") as log:
        for i, (family, n, sharing, seed) in enumerate(cases):
            ins = generate(seed=seed, n=n, sharing=sharing, density=p["density"], family=family)
            ins.dump(out / "instances" / ("case_%05d.json" % i))
            for alpha in p["alphas"]:
                result = evaluate(ins, p["per_milp_time_limit"], p["tolerance"], alpha)
                result.update(instance_id="case_%05d" % i, evidence_status=manifest["evidence_status"])
                log.write(json.dumps(result, sort_keys=True) + "\n"); log.flush()
            if (i + 1) % 25 == 0:
                print("Frozen structural cases %d/%d" % (i + 1, len(cases)), flush=True)
    print("Saved", len(cases), "held-out inputs across", len(p["alphas"]), "alphas")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["freeze", "structural", "semantic"])
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    if args.mode == "freeze":
        freeze(args.protocol)
    else:
        if args.out is None:
            parser.error("--out is required for execution")
        execute(args.protocol, args.out, args.mode)
