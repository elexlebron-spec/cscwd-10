"""Executable illustrative cabinet configuration, with no padded work loops.

The real functions create three BOMs, electrical/volume summaries, a four-node
steady-state thermal network solution, validation and a JSON release report.
Parameters are explicitly illustrative, not calibrated industrial/safety data.
"""
import argparse
import hashlib
import itertools
import json
import platform
import random
import statistics
import sys
import time
from dataclasses import asdict, dataclass
from pathlib import Path

from .core import Instance, Problem, solve


@dataclass
class Feature:
    name: str
    role: str
    volume_l: float
    power_w: float
    heat_w: float
    thermal_node: int
    price_units: float
    intent_weight: float


def linear_solve(matrix, rhs):
    """Partial-pivot Gaussian elimination on the small physical network."""
    a = [list(row) + [float(b)] for row, b in zip(matrix, rhs)]
    n = len(a)
    for col in range(n):
        pivot = max(range(col, n), key=lambda row: abs(a[row][col]))
        a[col], a[pivot] = a[pivot], a[col]
        if abs(a[col][col]) < 1e-12:
            raise ValueError("singular conductance matrix")
        for row in range(col + 1, n):
            ratio = a[row][col] / a[col][col]
            for k in range(col, n + 1):
                a[row][k] -= ratio * a[col][k]
    answer = [0.] * n
    for row in range(n - 1, -1, -1):
        answer[row] = (a[row][n] - sum(a[row][j] * answer[j] for j in range(row + 1, n))) / a[row][row]
    return answer


def thermal(parts, ambient=25.):
    sink = [.9, .7, .8, .6]  # illustrative conductance to ambient, W/K
    links = [(0, 1, .25), (1, 2, .2), (2, 3, .25), (3, 0, .15)]
    matrix = [[sink[i] if i == j else 0. for j in range(4)] for i in range(4)]
    heat = [2.] * 4  # base cabinet heat, W
    for part in parts:
        heat[part["thermal_node"]] += part["heat_w"]
    for i, j, conductance in links:
        matrix[i][i] += conductance; matrix[j][j] += conductance
        matrix[i][j] -= conductance; matrix[j][i] -= conductance
    rhs = [ambient * sink[i] + heat[i] for i in range(4)]
    values = linear_solve(matrix, rhs)
    residual = max(abs(sum(matrix[i][j] * values[j] for j in range(4)) - rhs[i]) for i in range(4))
    return {"node_temperatures_c": values, "max_temperature_c": max(values),
            "balance_residual_w": residual}


class CabinetWorkflow:
    groups = [[0, 6], [1, 2, 3], [4, 5, 7]]
    task_names = ["drive_bom", "control_bom", "interface_bom", "power_summary",
                  "drive_volume", "control_volume", "interface_volume", "thermal_network",
                  "integration_checks", "release_report"]
    parents = [["e0", "e6"], ["e1", "e2", "e3"], ["e4", "e5", "e7"],
               ["a0", "a1", "a2"], ["a0"], ["a1"], ["a2"],
               ["a0", "a1", "a2"], ["a3", "a4", "a5", "a6", "a7"],
               ["a0", "a1", "a2", "a8"]]

    def __init__(self, seed=200):
        # Seeds are development scenario variants, not independent industrial datasets.
        rng = random.Random(seed)
        specs = [("servo_drive", "electrical", 6, 90, 22, 0, 120, 8),
                 ("io_bank", "control", 2, 18, 9, 1, 35, 5),
                 ("controller_boost", "control", 1, 14, 8, 1, 40, 4),
                 ("safety_relay", "control", 2, 12, 5, 2, 25, 6),
                 ("network_gateway", "interface", 1, 8, 4, 2, 30, 3),
                 ("operator_panel", "interface", 3, 22, 10, 3, 45, 4),
                 ("backup_module", "electrical", 4, 35, 15, 0, 70, 7),
                 ("sensor_array", "interface", 2, 16, 6, 3, 20, 5)]
        self.features = []
        for name, role, volume, power, heat, node, price, intent in specs:
            factor = rng.uniform(.9, 1.1)
            self.features.append(Feature(name, role, volume * factor, power * factor,
                                         heat * factor, node, price, intent))
        self.seed = seed
        self.limits = dict(volume_l=17., power_w=210., temperature_c=53.)

    def selected_parts(self, kept):
        return [asdict(f) for i, f in enumerate(self.features) if i in kept]

    def independent_validate(self, kept):
        # Deliberately does not read the forbidden-combination list or cached reports.
        parts = self.selected_parts(kept)
        volume = 2. + sum(p["volume_l"] for p in parts)
        power = 45. + sum(p["power_w"] for p in parts)
        heat = thermal(parts)
        return {"valid": volume <= self.limits["volume_l"] + 1e-9
                         and power <= self.limits["power_w"] + 1e-9
                         and heat["max_temperature_c"] <= self.limits["temperature_c"] + 1e-9,
                "volume_l": volume, "power_w": power, **heat}

    def forbidden_combinations(self):
        # Complete enumeration is possible because this illustrative case has eight edits.
        forbidden = []
        for size in range(1, 9):
            for combination in itertools.combinations(range(8), size):
                s = set(combination)
                if any(set(c) <= s for c in forbidden):
                    continue
                if not self.independent_validate(s)["valid"]:
                    forbidden.append(list(combination))
        return forbidden

    def task(self, k, values):
        if k < 3:
            return [asdict(self.features[i]) for i in self.groups[k] if values["e%d" % i]]
        if k == 3:
            power = 45. + sum(part["power_w"] for j in range(3) for part in values["a%d" % j])
            return {"load_w": power, "supply_limit_w": self.limits["power_w"],
                    "current_at_24v_a": power / 24., "headroom_w": self.limits["power_w"] - power}
        if 4 <= k <= 6:
            parts = values["a%d" % (k - 4)]
            return {"parts": len(parts), "volume_l": sum(p["volume_l"] for p in parts)}
        if k == 7:
            return thermal([part for j in range(3) for part in values["a%d" % j]])
        if k == 8:
            volume = 2. + sum(values["a%d" % j]["volume_l"] for j in range(4, 7))
            return {"valid": volume <= self.limits["volume_l"] + 1e-9
                             and values["a3"]["load_w"] <= self.limits["power_w"] + 1e-9
                             and values["a7"]["max_temperature_c"] <= self.limits["temperature_c"] + 1e-9,
                    "volume_l": volume, "power_w": values["a3"]["load_w"],
                    "max_temperature_c": values["a7"]["max_temperature_c"]}
        parts = [part for j in range(3) for part in values["a%d" % j]]
        return json.dumps({"bom": [p["name"] for p in parts],
                           "bill_price_units": sum(p["price_units"] for p in parts),
                           "checks": values["a8"], "release_allowed": values["a8"]["valid"]},
                          sort_keys=True, separators=(",", ":"))

    def build(self, removed, old=None, affected=None, trace=False):
        start = time.perf_counter_ns()
        values = {"e%d" % i: i not in removed for i in range(8)}
        events = []
        for k, name in enumerate(self.task_names):
            key = "a%d" % k
            cached = old is not None and affected is not None and k not in affected
            before = time.perf_counter_ns()
            value = old[key] if cached else self.task(k, values)
            elapsed = time.perf_counter_ns() - before
            values[key] = value
            events.append({"task_id": key, "name": name, "reused": cached,
                           "elapsed_ns": elapsed,
                           **({"inputs": {p: values[p] for p in self.parents[k]}, "output": value} if trace else {})})
        elapsed = (time.perf_counter_ns() - start) / 1e9
        return values, elapsed, events


def prepare(workflow, calibration_repeats=9):
    started = time.perf_counter()
    mining_started = time.perf_counter()
    forbidden = workflow.forbidden_combinations()
    mining_seconds = time.perf_counter() - mining_started
    old, initial_seconds, _ = workflow.build(set())
    calibration_started = time.perf_counter()
    measurements = []
    # Repeated actual executions estimate tiny task costs; no padding is added.
    for _ in range(calibration_repeats):
        _, _, trace = workflow.build(set())
        measurements.append([e["elapsed_ns"] for e in trace])
    estimates = [max(1., statistics.median(row[k] for row in measurements)) for k in range(10)]
    ins = Instance("cabinet_illustrative_seed%d" % workflow.seed,
                   [f.intent_weight for f in workflow.features], forbidden,
                   workflow.parents, estimates,
                   {"source": "illustrative_semantic_functions_not_industrial_data", "seed": workflow.seed,
                    "cost_unit": "estimated_task_nanoseconds", "calibration_repeats": calibration_repeats})
    ins.validate()
    return ins, old, {"shared_setup_seconds": time.perf_counter() - started,
                      "constraint_mining_seconds": mining_seconds,
                      "initial_materialization_seconds": initial_seconds,
                      "calibration_seconds": time.perf_counter() - calibration_started,
                      "task_cost_samples_ns": measurements, "task_cost_estimates_ns": estimates}


def run(out, seeds, repeats, methods, alpha, budget,
        evidence_status="development_semantic_validation_not_confirmatory", protocol_sha256=None):
    if out.exists():
        raise SystemExit("Choose a fresh output directory")
    if repeats < 5:
        raise ValueError("at least five timing repetitions required")
    out.mkdir(parents=True)
    source_hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in Path(__file__).parent.glob("*.py")}
    try:
        import scipy
        scipy_version = scipy.__version__
    except ImportError:
        scipy_version = None
    manifest = dict(evidence_status=evidence_status, protocol_sha256=protocol_sha256,
                    seeds=seeds, repeats=repeats, methods=methods, alpha=alpha, budget_seconds=budget,
                    python=sys.version, platform=platform.platform(), scipy=scipy_version,
                    source_sha256=source_hashes, model="illustrative_four_node_cabinet_v1",
                    padding=False, time_scope="warm in-process; setup and cold start separately recorded")
    (out / "manifest.json").write_text(json.dumps(manifest, indent=2))
    with (out / "raw.jsonl").open("w") as log:
        for seed in seeds:
            directory = out / ("scenario_%d" % seed)
            directory.mkdir()
            workflow = CabinetWorkflow(seed)
            ins, old, setup = prepare(workflow)
            ins.dump(directory / "instance.json")
            (directory / "scenario.json").write_text(json.dumps({"features": [asdict(f) for f in workflow.features],
                                                                "limits": workflow.limits, "tasks": workflow.task_names,
                                                                "parents": workflow.parents, "base_flags": [0] * 8,
                                                                "candidate_flags": [1] * 8, "setup": setup}, indent=2))
            _, _, initial_trace = workflow.build(set(), trace=True)
            (directory / "initial_cache_trace.json").write_text(json.dumps(initial_trace, indent=2))
            # Record cold first-solve time separately, not hidden in a claimed steady-state gain.
            warmup = [solve(ins, m, alpha, budget, normalize=True, random_seed=seed) for m in methods]
            (directory / "warmup.json").write_text(json.dumps(warmup, indent=2))
            for repeat in range(repeats):
                order = list(methods)
                random.Random(seed * 1000 + repeat).shuffle(order)
                for order_index, method in enumerate(order):
                    row = solve(ins, method, alpha, budget, normalize=True, random_seed=seed * 100 + repeat)
                    removed = set(row["removed"])
                    # Provenance query is part of measured selective completion overhead.
                    before = time.perf_counter()
                    affected = Problem(ins).affected(removed)
                    selective, _, events = workflow.build(removed, old, affected)
                    selective_seconds = time.perf_counter() - before
                    full, full_seconds, _ = workflow.build(removed)
                    direct = workflow.independent_validate(set(range(8)) - removed)
                    equal = selective == full
                    valid = direct["valid"] and full["a8"]["valid"]
                    row.update(seed=seed, instance_id="cabinet_%d" % seed, repeat=repeat, order=order_index,
                               workflow="illustrative_cabinet", family="semantic_cabinet", n=8,
                               sharing_control="fixed_design", density_control="induced_complete_rules",
                               alpha=alpha, replay_equal=equal, final_valid=valid,
                               selective_seconds=selective_seconds, full_seconds=full_seconds,
                               total_seconds=row["solver_seconds"] + selective_seconds,
                               total_with_shared_setup_seconds=setup["shared_setup_seconds"] + row["solver_seconds"] + selective_seconds,
                               independent_state=direct, **{k: v for k, v in setup.items() if k.endswith("seconds")})
                    log.write(json.dumps(row, sort_keys=True) + "\n"); log.flush()
                    if repeat == 0:
                        _, _, detailed = workflow.build(removed, old, affected, trace=True)
                        (directory / (method + "_final_trace.json")).write_text(json.dumps(detailed, indent=2))
                    if not equal or not valid:
                        raise RuntimeError("independent semantic validation failed")
    print("Semantic replay records saved to", out)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--seeds", default="200,201,202,203,204")
    parser.add_argument("--repeats", type=int, default=5)
    parser.add_argument("--alpha", type=float, default=1.)
    parser.add_argument("--budget-seconds", type=float, default=.05)
    parser.add_argument("--without-milp", action="store_true")
    args = parser.parse_args()
    methods = ["loss_greedy", "additive_greedy", "union_greedy", "additive_multistart", "union_multistart",
               "exact_additive", "exact_union", "random_feasible"]
    if not args.without_milp:
        methods.extend(["milp_additive", "milp_union"])
    run(args.out, [int(s) for s in args.seeds.split(",")], args.repeats, methods, args.alpha, args.budget_seconds)


if __name__ == "__main__":
    main()
