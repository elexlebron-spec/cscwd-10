"""Separate objective, intent and measured time; collapse timing repetitions.

This supports development evidence. A CI does not confer confirmatory status.
"""
import argparse
import csv
import json
import random
import statistics
from collections import defaultdict
from pathlib import Path

from .analyze import percentile


METRICS = {"objective": "relative_reduction", "intent_loss_fraction": "absolute_fraction_reduction",
           "estimated_rework_fraction": "absolute_fraction_reduction",
           "total_seconds": "relative_reduction", "selective_seconds": "relative_reduction",
           "solver_seconds": "relative_reduction", "affected_artifacts": "relative_reduction"}


def analyze(run, bootstraps=2000):
    raw = [json.loads(s) for s in (run / "raw.jsonl").read_text().splitlines()]
    grouped = defaultdict(list)
    for row in raw:
        grouped[row["instance_id"], row["method"]].append(row)
    cases = defaultdict(dict)
    for (case, method), rows in grouped.items():
        collapsed = dict(rows[0])
        for metric in METRICS:
            if all(metric in r for r in rows):
                collapsed[metric] = statistics.median(r[metric] for r in rows)
        collapsed["all_optimal"] = all(r["status"] == "optimal" for r in rows)
        collapsed["repetitions"] = len(rows)
        cases[case][method] = collapsed
    pairs = [("milp_union", "milp_additive"), ("union_multistart", "additive_multistart"),
             ("union_greedy", "additive_greedy"), ("exact_union", "exact_additive"),
             ("union_multistart", "milp_union")]
    results, coverage, pareto = [], [], {}
    for target, baseline in pairs:
        paired = [(case[target], case[baseline]) for case in cases.values() if target in case and baseline in case]
        certified = [(a, b) for a, b in paired if a["all_optimal"] and b["all_optimal"]]
        require_optimal = (target.startswith("milp_") and baseline.startswith("milp_")) or target.startswith("exact_")
        usable = certified if require_optimal else paired
        coverage.append(dict(target=target, baseline=baseline, paired_cases=len(paired),
                             jointly_certified_cases=len(certified), used_cases=len(usable),
                             note="all feasible rows retained in raw; certified subset can be selective"))
        if not usable:
            continue
        buckets = defaultdict(list)
        for t, b in usable:
            strata = [("ALL", "ALL", "ALL", "ALL"),
                      (t["family"], t["n"], t["sharing_control"], t["density_control"])]
            for metric, units in METRICS.items():
                if metric not in t or metric not in b:
                    continue
                if units == "relative_reduction" and b[metric] <= 0:
                    continue
                change = ((b[metric] - t[metric]) / b[metric] if units == "relative_reduction"
                          else b[metric] - t[metric])
                for stratum in strata:
                    buckets[(metric, *stratum)].append((t["seed"], change))
        for (metric, family, size, sharing, density), values in buckets.items():
            clusters = defaultdict(list)
            for seed, value in values:
                clusters[seed].append(value)
            seeds = sorted(clusters)
            rng = random.Random(20271027)
            samples = []
            for _ in range(bootstraps):
                selected = [rng.choice(seeds) for _ in seeds]
                samples.append(statistics.mean(v for s in selected for v in clusters[s]))
            results.append(dict(target=target, baseline=baseline, metric=metric, units=METRICS[metric],
                                family=family, n=size, sharing_control=sharing, density_control=density,
                                cases=len(values), seed_clusters=len(seeds),
                                mean_paired_change=statistics.mean(v for _, v in values),
                                median_paired_change=statistics.median(v for _, v in values),
                                ci95_low=percentile(samples, .025), ci95_high=percentile(samples, .975),
                                better=sum(v > 1e-10 for _, v in values), equal=sum(abs(v) <= 1e-10 for _, v in values),
                                worse=sum(v < -1e-10 for _, v in values),
                                evidence_status="development_only; repetitions_collapsed_before_seed_bootstrap"))
        counts = dict(target_dominates=0, baseline_dominates=0, tradeoff=0, equal=0)
        for t, b in usable:
            if "total_seconds" not in t or "total_seconds" not in b:
                continue
            loss = t["intent_loss_fraction"] - b["intent_loss_fraction"]
            elapsed = t["total_seconds"] - b["total_seconds"]
            if loss <= 1e-10 and elapsed <= 0 and (loss < -1e-10 or elapsed < 0):
                counts["target_dominates"] += 1
            elif loss >= -1e-10 and elapsed >= 0 and (loss > 1e-10 or elapsed > 0):
                counts["baseline_dominates"] += 1
            elif abs(loss) <= 1e-10 and elapsed == 0:
                counts["equal"] += 1
            else:
                counts["tradeoff"] += 1
        pareto[target + "_vs_" + baseline] = counts
    with (run / "paired_metrics_v2.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(results[0]) if results else ["target"])
        writer.writeheader(); writer.writerows(results)
    (run / "certification_coverage.json").write_text(json.dumps(coverage, indent=2))
    summary = dict(records=len(raw), cases=len(cases),
                   all_valid=all(r["feasible"] and r["final_valid"] and r["replay_equal"] for r in raw),
                   evidence_status="development_only", global_comparisons=[r for r in results if r["family"] == "ALL"],
                   descriptive_pareto_counts=pareto,
                   note="Timing medians then paired seed bootstrap; no empirical significance or industrial generalization claim.")
    (run / "revision_summary.json").write_text(json.dumps(summary, indent=2))
    print("Wrote separate metrics, certificate coverage and descriptive tradeoffs to", run)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", type=Path, required=True)
    parser.add_argument("--bootstrap", type=int, default=2000)
    args = parser.parse_args()
    if args.bootstrap < 1:
        raise SystemExit("positive bootstrap count required")
    analyze(args.run, args.bootstrap)


if __name__ == "__main__":
    main()
