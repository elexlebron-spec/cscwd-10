"""Audit the same 90 controlled sharing pairs raised in the review."""
import argparse
import itertools
import json
from pathlib import Path

from .core import generate


def audit():
    comparisons = []
    for family, n, density, seed in itertools.product(
            ("mixed", "hub", "chain"), (12, 20, 40), (.5, 1.), range(100, 105)):
        low, high = [generate(seed, n, sharing, density, family) for sharing in (.3, .7)]
        comparisons.append(dict(family=family, n=n, density=density, seed=seed,
                                identical_costs=low.work == high.work,
                                identical_losses=low.losses == high.losses,
                                identical_conflicts=low.conflicts == high.conflicts,
                                nested_edges=all(set(a) <= set(b) for a, b in zip(low.parents, high.parents))))
    assert all(all(r[k] for k in ("identical_costs", "identical_losses", "identical_conflicts", "nested_edges"))
               for r in comparisons)
    return dict(generator="v2_independent_streams", pairs=len(comparisons), all_controls_fixed=True,
                comparisons=comparisons)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    args.out.write_text(json.dumps(audit(), indent=2))
    print("90 controlled sharing pairs passed:", args.out)
