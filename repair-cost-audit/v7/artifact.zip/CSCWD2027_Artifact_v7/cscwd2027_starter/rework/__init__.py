"""CPU-only research scaffold for shared-rework-aware design repair."""

__version__ = "0.1.0"
