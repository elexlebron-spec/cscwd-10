"""Prespecified analysis of frozen cost-model audit; no outcome-dependent filters."""
import argparse
import csv
import json
import random
import statistics
from collections import defaultdict
from pathlib import Path

from .analyze import percentile


def interval(pairs):
    clusters = defaultdict(list)
    for seed, value in pairs:
        clusters[seed].append(value)
    seeds = sorted(clusters)
    rng = random.Random(20261028)
    draws = []
    for _ in range(2000):
        selected = [rng.choice(seeds) for _ in seeds]
        draws.append(statistics.mean(x for seed in selected for x in clusters[seed]))
    values = [v for _, v in pairs]
    return dict(mean=statistics.mean(values), median=statistics.median(values),
                ci95_low=percentile(draws, .025), ci95_high=percentile(draws, .975),
                p95=percentile(values, .95), maximum=max(values), independent_seeds=len(seeds))


def analyze(run):
    rows = [json.loads(s) for s in (run / "raw.jsonl").read_text().splitlines()]
    strata = defaultdict(list)
    for r in rows:
        for key in ((r["alpha"], "ALL", "ALL", "ALL"),
                    (r["alpha"], r["family"], r["n"], r["sharing_control"])):
            strata[key].append(r)
    summary, intervals = [], []
    for (alpha, family, n, sharing), records in strata.items():
        certified = [r for r in records if r["all_certified"]]
        item = dict(alpha=alpha, family=family, n=n, sharing=sharing, cases=len(records),
                    certified=len(certified), certificate_coverage=len(certified) / len(records),
                    nonzero_best_regret=sum(r.get("best_regret", 0) > 1e-8 for r in certified),
                    best_regret_over_one_percent=sum(r.get("best_regret", 0) > .01 for r in certified),
                    tie_sensitive=sum(r.get("tie_sensitive", False) for r in certified))
        if certified:
            for metric in ("default_regret", "best_regret", "worst_regret"):
                stats = interval([(r["seed"], r[metric]) for r in certified])
                intervals.append(dict(alpha=alpha, family=family, n=n, sharing=sharing, metric=metric, **stats))
                item[metric + "_mean"] = stats["mean"]
                item[metric + "_median"] = stats["median"]
            incidence = interval([(r["seed"], float(r["best_regret"] > 1e-8)) for r in certified])
            item["nonzero_incidence_ci95"] = [incidence["ci95_low"], incidence["ci95_high"]]
        summary.append(item)
    with (run / "regret_intervals.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(intervals[0])); writer.writeheader(); writer.writerows(intervals)
    (run / "study_summary.json").write_text(json.dumps(dict(
        raw_rows=len(rows), distinct_inputs=len({r["instance_id"] for r in rows}), strata=summary,
        interpretation="fixed benchmark and parameter variants; not a population estimate for industrial design"), indent=2))
    print(json.dumps([s for s in summary if s["family"] == "ALL"], indent=2))


if __name__ == "__main__":
    p = argparse.ArgumentParser(); p.add_argument("--run", required=True, type=Path)
    analyze(p.parse_args().run)
