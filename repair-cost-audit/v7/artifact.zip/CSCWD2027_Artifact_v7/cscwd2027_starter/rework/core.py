"""Restricted, explicit model: monotone forbidden-feature constraints and a DAG.

All quantities called costs below are synthetic work units, not measured seconds
or human effort. Algorithms share the same constraint oracle and information.
"""
import hashlib
import json
import math
import random
import time
from dataclasses import asdict, dataclass, replace
from typing import Dict, FrozenSet, List, Optional, Set, Tuple


@dataclass
class Instance:
    name: str
    losses: List[float]
    # A rule forbids retaining ALL edits in its list. Empty is invalid input.
    conflicts: List[List[int]]
    # Artifact k can depend on edits e0... or earlier artifacts a0...
    parents: List[List[str]]
    work: List[float]
    metadata: dict

    def validate(self):
        n = len(self.losses)
        if any(not math.isfinite(x) or x <= 0 for x in self.losses):
            raise ValueError("losses must be positive and finite")
        if len(self.parents) != len(self.work) or any(not math.isfinite(w) or w <= 0 for w in self.work):
            raise ValueError("one positive work count per artifact required")
        for c in self.conflicts:
            if not c or len(set(c)) != len(c) or any(i < 0 or i >= n for i in c):
                raise ValueError("invalid forbidden combination")
        for k, ps in enumerate(self.parents):
            for p in ps:
                if len(p) < 2 or p[0] not in "ea" or not p[1:].isdigit():
                    raise ValueError("invalid parent id")
                if int(p[1:]) >= (n if p[0] == "e" else k):
                    raise ValueError("artifact DAG must be topologically ordered")
        return self

    def footprints(self) -> List[FrozenSet[int]]:
        """Transitive edit-to-artifact reachability, including direct consumers."""
        ancestry: List[Set[int]] = []
        for ps in self.parents:
            roots: Set[int] = set()
            for p in ps:
                roots.update({int(p[1:])} if p[0] == "e" else ancestry[int(p[1:])])
            ancestry.append(roots)
        return [frozenset(k for k, roots in enumerate(ancestry) if i in roots)
                for i in range(len(self.losses))]

    def dump(self, path):
        path.write_text(json.dumps(asdict(self), ensure_ascii=False, indent=2), encoding="utf-8")

    @classmethod
    def load(cls, path):
        return cls(**json.loads(path.read_text(encoding="utf-8"))).validate()


class Problem:
    def __init__(self, instance: Instance, alpha: float = 1.0):
        self.instance = instance.validate()
        if not math.isfinite(alpha) or alpha < 0:
            raise ValueError("alpha must be nonnegative and finite")
        self.alpha = alpha
        self.edges = [frozenset(e) for e in instance.conflicts]
        self.fp = instance.footprints()
        self.calls = 0

    def affected(self, removed) -> Set[int]:
        return set().union(*(self.fp[i] for i in removed)) if removed else set()

    def feasible(self, removed) -> bool:
        return all(e.intersection(removed) for e in self.edges)

    def cost(self, removed, model="union") -> float:
        self.calls += 1
        ins = self.instance
        loss = sum(ins.losses[i] for i in removed)
        if model == "loss":
            return loss
        if model == "additive":
            work = sum(sum(ins.work[a] for a in self.fp[i]) for i in removed)
        elif model == "union":
            work = sum(ins.work[a] for a in self.affected(removed))
        else:
            raise ValueError(model)
        return loss + self.alpha * work


def prune(problem: Problem, removed, model="union") -> Set[int]:
    """Remove redundant withdrawals, with deterministic tie breaking."""
    result = set(removed)
    for i in sorted(result, key=lambda i: (-problem.instance.losses[i], i)):
        candidate = result - {i}
        if problem.feasible(candidate) and problem.cost(candidate, model) <= problem.cost(result, model):
            result = candidate
    return result


def greedy(problem: Problem, model="union", seed=None) -> Set[int]:
    if not problem.edges:
        return set()
    removed = set() if seed is None else {seed}
    while not problem.feasible(removed):
        uncovered = [e for e in problem.edges if not e.intersection(removed)]
        choices = sorted(set().union(*uncovered))
        base = problem.cost(removed, model)
        def rank(i):
            gain = sum(i in e for e in uncovered)
            delta = problem.cost(removed | {i}, model) - base
            return (delta / gain, delta, i)
        removed.add(min(choices, key=rank))
    return prune(problem, removed, model)


def multistart(problem: Problem, model="union", seed_limit=16) -> Set[int]:
    """Standard seeded greedy heuristic; no approximation claim is made."""
    incumbent = greedy(problem, model)
    # Same seed ids for both cost models; independent of test performance.
    candidates = sorted(set().union(*problem.edges)) if problem.edges else []
    if len(candidates) > seed_limit:
        indexes = [round(i * (len(candidates) - 1) / (seed_limit - 1))
                   for i in range(seed_limit)] if seed_limit > 1 else [0]
        candidates = [candidates[i] for i in indexes]
    for i in candidates:
        option = greedy(problem, model, i)
        if (problem.cost(option, model), sorted(option)) < (problem.cost(incumbent, model), sorted(incumbent)):
            incumbent = option
    return incumbent


def exact(problem: Problem, model="union", timeout=5.0) -> Tuple[Set[int], str]:
    """Branch on an uncovered forbidden combination; monotone-cost bound.

    A returned feasible incumbent is NOT an optimum if the timeout is reached.
    This is a small-instance reference solver, not a new research contribution.
    """
    deadline = time.perf_counter() + timeout
    incumbent = greedy(problem, model)
    best = problem.cost(incumbent, model)
    visited = set()
    timed_out = False

    def visit(removed: FrozenSet[int]):
        nonlocal incumbent, best, timed_out
        if time.perf_counter() >= deadline:
            timed_out = True
            return
        if removed in visited:
            return
        visited.add(removed)
        value = problem.cost(removed, model)
        if value >= best:
            return
        unhit = [e for e in problem.edges if not e.intersection(removed)]
        if not unhit:
            incumbent, best = set(removed), value
            return
        edge = min(unhit, key=lambda e: (len(e), tuple(sorted(e))))
        for i in sorted(edge, key=lambda i: (problem.cost(removed | {i}, model), i)):
            visit(removed | {i})
            if timed_out:
                return

    visit(frozenset())
    return incumbent, "timeout_feasible" if timed_out else "optimal"


METHODS = ("loss_greedy", "additive_greedy", "union_greedy", "additive_multistart",
           "union_multistart", "exact_additive", "exact_union", "milp_additive", "milp_union",
           "random_feasible", "additive_equal_time", "union_equal_time")


def solve(instance, method, alpha=1.0, timeout=5.0, normalize=False, random_seed=0):
    start = time.perf_counter()
    original = instance
    if normalize:
        instance = replace(instance,
                           losses=[p / sum(instance.losses) for p in instance.losses],
                           work=[c / sum(instance.work) for c in instance.work])
    problem = Problem(instance, alpha)
    preprocess_seconds = time.perf_counter() - start
    status = "heuristic_feasible"
    diagnostics = {}
    model = "union"
    if method.startswith("milp_"):
        from .milp import milp_repair
        model = method.split("_", 1)[1]
        removed, status, diagnostics = milp_repair(problem, model, timeout)
    elif method == "random_feasible":
        order = list(range(len(instance.losses)))
        random.Random(random_seed).shuffle(order)
        removed = set()
        for i in order:
            if problem.feasible(removed):
                break
            removed.add(i)
        removed = prune(problem, removed)
    elif method.endswith("_equal_time"):
        model = method.split("_", 1)[0]
        deadline = time.perf_counter() + timeout
        removed = greedy(problem, model)
        starts = 0
        seeds = sorted(set().union(*problem.edges)) if problem.edges else []
        for i in seeds:
            if time.perf_counter() >= deadline:
                break
            option = greedy(problem, model, i)
            starts += 1
            if (problem.cost(option, model), sorted(option)) < (problem.cost(removed, model), sorted(removed)):
                removed = option
        diagnostics = {"completed_starts": starts, "search_budget_seconds": timeout,
                       "budget_scope": "soft boundary between complete greedy starts"}
    elif method.startswith("exact_"):
        model = method.split("_", 1)[1]
        removed, status = exact(problem, method.split("_", 1)[1], timeout)
    elif method.endswith("_multistart"):
        model = method.split("_", 1)[0]
        removed = multistart(problem, method.split("_", 1)[0])
    elif method.endswith("_greedy"):
        model = method.split("_", 1)[0]
        removed = greedy(problem, method.split("_", 1)[0])
    else:
        raise ValueError(method)
    seconds = time.perf_counter() - start
    optimization_cost_calls = problem.calls
    assert problem.feasible(removed)
    affected = problem.affected(removed)
    raw_loss = sum(original.losses[i] for i in removed)
    raw_work = sum(original.work[k] for k in affected)
    return dict(method=method, removed=sorted(removed), status=status,
                objective=problem.cost(removed), optimized_model_value=problem.cost(removed, model),
                optimized_model=model, objective_units="normalized_fraction" if normalize else "raw_weighted_units",
                intent_loss=raw_loss, intent_loss_fraction=raw_loss / sum(original.losses),
                estimated_rework_fraction=raw_work / sum(original.work), rework_units=raw_work,
                affected_artifacts=len(affected), withdrawn_edits=len(removed),
                feasible=True, solver_seconds=seconds, preprocess_seconds=preprocess_seconds,
                cost_calls=optimization_cost_calls,
                retained_value=sum(original.losses) - raw_loss, **diagnostics)


def generate(seed=0, n=16, sharing=0.5, density=1.0, family="mixed") -> Instance:
    """Synthetic forbidden-feature rules + materialized dependency DAG.

    sharing is a generator control, NOT measured overlap. Families are topology
    variants of one simulator, not independent real-world datasets.
    """
    if n < 4 or not 0 <= sharing <= 1 or density < 0:
        raise ValueError("n >= 4, 0 <= sharing <= 1, density >= 0 required")
    if family not in ("chain", "hub", "mixed", "disjoint"):
        raise ValueError(family)
    def stream(tag):
        key = ("generator-v2:%d:%d:%s" % (seed, n, tag)).encode()
        return random.Random(int.from_bytes(hashlib.sha256(key).digest()[:8], "big"))
    loss_rng, conflict_rng, cost_rng = stream("loss"), stream("conflicts"), stream("cost")
    losses = [float(loss_rng.randint(1, 8)) for _ in range(n)]
    edges = set()
    for _ in range(round(n * density)):
        arity = conflict_rng.choice([2, 2, 3, 4])
        edges.add(tuple(sorted(conflict_rng.sample(range(n), arity))))
    # Remove non-minimal supersets; equivalent forbidden-combination semantics.
    edges = {e for e in edges if not any(set(f) < set(e) for f in edges)}
    parents = [["e%d" % i] for i in range(n)]
    work = [cost_rng.randint(1, 6) for _ in range(n)]
    work += [cost_rng.randint(2, 12) for _ in range(2 * n)]
    for k in range(2 * n):
        edge_rng = stream("edge_%d" % k)
        root = k % n
        ps = {"e%d" % root}
        gate = edge_rng.random()
        extra_roots = edge_rng.sample(range(n), edge_rng.randint(2, min(5, n)))
        previous_gate = edge_rng.random()
        previous = edge_rng.randrange(n + k)
        if family != "disjoint" and gate < sharing:
            ps.update("e%d" % i for i in extra_roots)
        if family == "chain" and k > 0:
            ps.add("a%d" % (n + k - 1))
        elif family == "hub" and k >= n:
            ps.add("a%d" % (n + k % n))
        elif family == "mixed" and k > 0 and previous_gate < sharing:
            ps.add("a%d" % previous)
        parents.append(sorted(ps))
    return Instance("synthetic_%s_n%d_s%d_seed%d" % (family, n, round(sharing * 100), seed),
                    losses, [list(e) for e in sorted(edges)], parents, work,
                    dict(source="synthetic", generator_version="v2_independent_streams", seed=seed, family=family,
                         sharing_control=sharing, density_control=density)).validate()


def overlap(instance: Instance) -> float:
    fp = instance.footprints()
    total = sum(sum(instance.work[a] for a in s) for s in fp)
    unique = sum(instance.work[a] for a in set().union(*fp)) if fp else 0
    return 1.0 - unique / total if total else 0.0


def compute_artifact(values, units, scale):
    value = hashlib.sha256("|".join(values).encode()).digest()
    for _ in range(units * scale):
        value = hashlib.sha256(value).digest()
    return value.hex()


def rebuild(instance, removed, scale=10, old=None, affected=None):
    """Serial materialization. Unaffected cached artifacts may be reused."""
    outputs: Dict[str, str] = {"e%d" % i: "0" if i in removed else "1"
                               for i in range(len(instance.losses))}
    for k, ps in enumerate(instance.parents):
        key = "a%d" % k
        if old is not None and affected is not None and k not in affected:
            outputs[key] = old[key]
        else:
            outputs[key] = compute_artifact([outputs[p] for p in ps], instance.work[k], scale)
    return outputs


def replay_check(instance, removed, scale=10, old=None):
    if scale < 1:
        raise ValueError("scale >= 1 required")
    # Speculative candidate artifacts can exist before a valid merge is chosen.
    old = rebuild(instance, set(), scale) if old is None else old
    affected = Problem(instance).affected(removed)
    t0 = time.perf_counter()
    selective = rebuild(instance, set(removed), scale, old, affected)
    selective_seconds = time.perf_counter() - t0
    t0 = time.perf_counter()
    full = rebuild(instance, set(removed), scale)
    full_seconds = time.perf_counter() - t0
    # A deterministic validator independent from the repair's cached edge hits.
    final_valid = all(not all(full["e%d" % i] == "1" for i in c)
                      for c in instance.conflicts)
    return dict(replay_equal=selective == full, final_valid=final_valid,
                selective_seconds=selective_seconds, full_seconds=full_seconds,
                kernel="sha256_serial_synthetic", kernel_scale=scale)
