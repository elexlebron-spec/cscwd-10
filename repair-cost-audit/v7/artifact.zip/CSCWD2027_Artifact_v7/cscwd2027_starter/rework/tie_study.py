"""Audit cost-model loss after charitable and adversarial tie handling."""
import argparse
import hashlib
import json
import platform
import shutil
import sys
import time
from dataclasses import replace
from pathlib import Path

from .core import Instance, Problem, overlap
from .milp import additive_tie_envelope, milp_repair


def normalized(ins):
    return replace(ins, losses=[x / sum(ins.losses) for x in ins.losses],
                   work=[x / sum(ins.work) for x in ins.work])


def evaluate(ins, timeout=1., tolerance=1e-8, alpha=1.):
    p = Problem(normalized(ins), alpha)
    started = time.perf_counter()
    envelope = additive_tie_envelope(p, timeout, tolerance)
    removed, union_status, diagnostics = milp_repair(p, "union", timeout)
    optimum = p.cost(removed, "union")
    certified = envelope["range_certified"] and union_status == "optimal"
    row = dict(**envelope, union_status=union_status, union_removed=sorted(removed),
               union_cost=optimum, all_certified=certified,
               solve_total_seconds=time.perf_counter() - started, **diagnostics)
    if certified:
        denominator = optimum if optimum > tolerance else 1.
        for label in ("default", "best", "worst"):
            value = (envelope[label + "_union_cost"] - optimum) / denominator
            if value < -1e-6:
                raise RuntimeError("a certified additive solution beats certified union optimum")
            row[label + "_regret"] = max(0., value)
        row["tie_sensitive"] = envelope["worst_union_cost"] - envelope["best_union_cost"] > tolerance
        row["mismatch_survives_best_tie"] = envelope["best_union_cost"] - optimum > tolerance
    row.update(source_name=ins.name, alpha=alpha, seed=ins.metadata["seed"], family=ins.metadata.get("family", "semantic"),
               n=len(ins.losses), sharing_control=ins.metadata.get("sharing_control", "semantic"),
               density_control=ins.metadata.get("density_control", "semantic"), overlap=overlap(ins))
    return row


def run(source, out, timeout):
    if out.exists():
        raise SystemExit("Choose a fresh output directory")
    out.mkdir(parents=True)
    snapshots = out / "source_snapshot"; snapshots.mkdir()
    hashes = {}
    for path in Path(__file__).parent.glob("*.py"):
        hashes[path.name] = hashlib.sha256(path.read_bytes()).hexdigest()
        shutil.copy2(path, snapshots / path.name)
    files = sorted((source / "instances").glob("*.json")) if (source / "instances").is_dir() else sorted(source.glob("scenario_*/instance.json"))
    manifest = dict(evidence_status="development_tie_audit", input_run=str(source.resolve()),
                    source_sha256=hashes, files=len(files), timeout_per_milp=timeout,
                    normalization="loss/P + unique_cost/C_total", alpha=1., tie_face_tolerance=1e-8,
                    python=sys.version, platform=platform.platform())
    (out / "manifest.json").write_text(json.dumps(manifest, indent=2))
    inputs = out / "instances"; inputs.mkdir()
    with (out / "raw.jsonl").open("w") as log:
        for i, path in enumerate(files):
            ins = Instance.load(path)
            row = evaluate(ins, timeout)
            row["instance_id"] = "case_%05d" % i
            ins.dump(inputs / (row["instance_id"] + ".json"))
            log.write(json.dumps(row, sort_keys=True) + "\n"); log.flush()
            if (i + 1) % 25 == 0:
                print("Tie audit %d/%d" % (i + 1, len(files)), flush=True)
    summarize(out)


def summarize(out):
    import statistics
    rows = [json.loads(x) for x in (out / "raw.jsonl").read_text().splitlines()]
    valid = [r for r in rows if r["all_certified"]]
    summary = dict(cases=len(rows), certified_cases=len(valid),
                   tie_sensitive=sum(r["tie_sensitive"] for r in valid),
                   mismatch_survives_best_tie=sum(r["mismatch_survives_best_tie"] for r in valid))
    for name in ("default", "best", "worst"):
        values = [r[name + "_regret"] for r in valid]
        if values:
            summary[name + "_mean_regret"] = statistics.mean(values)
            summary[name + "_median_regret"] = statistics.median(values)
            summary[name + "_max_regret"] = max(values)
    (out / "summary.json").write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--timeout", type=float, default=1.)
    args = parser.parse_args()
    run(args.source, args.out, args.timeout)
