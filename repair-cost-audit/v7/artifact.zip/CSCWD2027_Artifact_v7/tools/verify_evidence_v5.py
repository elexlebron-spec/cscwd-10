"""Read-only scientific integrity checks, then write a compact audit receipt."""
import csv
import hashlib
import json
from collections import Counter
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1];P=ROOT/'cscwd2027_starter'
def j(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    v3=j(P/'docs/FROZEN_PROTOCOL_V3.json')
    for name,digest in v3['code_sha256'].items(): assert sha(P/'rework'/name)==digest,name
    v4=j(P/'docs/FROZEN_PROTOCOL_V4.json')
    for name,digest in v4['source_sha256'].items(): assert sha(P/name)==digest,name
    v5=j(P/'docs/FROZEN_PROTOCOL_V5.json')
    for name,digest in v5['code_sha256'].items(): assert sha(P/name)==digest,name
    r=P/'runs/make_trace_v5_final'
    assert sha(r/'protocol.json')==sha(P/'docs/FROZEN_PROTOCOL_V5.json')
    assert sha(P/'literature/build_source/zlib-1.3.2.tar.gz')==v5['build_source_sha256']
    rows=[json.loads(s) for s in (r/'raw.jsonl').read_text().splitlines()]
    assert len(rows)==111
    groups=Counter(tuple(x['roots']) for x in rows)
    assert len(groups)==37 and set(groups.values())=={3}
    single={}
    for row in rows:
        tasks=[t['task'] for t in row['trace']]
        assert len(tasks)==len(set(tasks))==row['task_count']
        assert row['test_passed'] and 'zlib test OK' in row['stdout']
        assert all(t['status']==0 for t in row['trace'])
        if len(row['roots'])==1:
            root=row['roots'][0]
            if root in single:assert single[root]==set(tasks)
            single[root]=set(tasks)
    core=set.intersection(*single.values())
    assert len(core)==6
    for row in rows:
        assert {t['task'] for t in row['trace']}==set.union(*(single[i] for i in row['roots']))
        assert row['task_count']==len(row['roots'])+6
    assert j(r/'environment.json')['source_bytes_unchanged']
    audit=P/'runs/common_audit_v5'
    assert j(audit/'protocol.json')==v5
    interventions=list(csv.DictReader((audit/'interventions.csv').open()))
    assert len(interventions)==324
    by_case={}
    for row in interventions:
        assert row['union_invariant']==row['corrected_equals_union']=='True'
        by_case.setdefault(row['case'],[]).append(row)
    assert len(by_case)==54
    def face(s):return frozenset(tuple(map(int,r.split(';'))) for r in s.split('|'))
    switched=0;primary_switched=0
    for case,rs in by_case.items():
        assert len(rs)==6
        assert len({r['union_face'] for r in rs})==1
        first=next(r for r in rs if float(r['core_multiplier'])==0)
        flip=any(not(face(first['additive_face']) & face(r['additive_face'])) for r in rs)
        switched+=flip
        if first['mode']=='uniform':assert not flip
        if first['mode']=='compliance_proxy' and float(first['alpha'])==1:primary_switched+=flip
    assert switched==18 and primary_switched==6
    failed=[]
    for f in sorted((P/'runs/beam_main_v4').glob('*/tie_envelope.json')):
        e=j(f)
        if not e['range_certified']:
            assert '_uniform_' in f.parent.name
            assert e['best_status']==e['worst_status']==0
            deviation=max(abs(e['best_additive_deviation']),abs(e['worst_additive_deviation']))
            assert deviation>1e-8
            failed.append(dict(case=f.parent.name,maximum_face_deviation=deviation,
                               best_solver_status=e['best_status'],worst_solver_status=e['worst_status']))
    assert len(failed)==11
    result=dict(date='2026-10-28',v3_v4_frozen_sources_unchanged=True,
                v5_protocol_sha256=sha(P/'docs/FROZEN_PROTOCOL_V5.json'),
                build_records=len(rows),unique_batches=len(groups),all_build_tests_passed=True,
                build_trace_union_identity=True,common_recipes=6,
                all8_batch_recipes=14,all8_separate_recipes=56,
                beam_settings=54,common_cost_interventions=324,
                additive_optimum_face_switches=switched,primary_switches=primary_switched,
                all_union_faces_invariant=True,all_corrected_scores_equal_union=True,
                all11_strict_face_failures_are_uniform_numerical_membership_failures=True,
                maximum_failed_face_deviation=max(r['maximum_face_deviation'] for r in failed),
                tests_expected=25,
                claim_scope='Actual upstream execution semantics; no observed deployed additive-pricing policy or industrial collaboration',
                public_artifact_status='Local reviewer bundle ready; no public archival URL created',
                nearest_article_fulltext_status='Unavailable in checked public publisher and institutional sources',
                verifier_sha256=sha(Path(__file__)))
    out=P/'runs/revision_evidence_v5';out.mkdir(exist_ok=True)
    (out/'summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    (out/'beam_face_failures.json').write_text(json.dumps(failed,indent=2))
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
