"""Verify frozen planner sources, independent plan costs, and delivered evidence."""
from pathlib import Path
import hashlib,json,subprocess,sys
ROOT=Path(__file__).resolve().parents[1];P=ROOT/'cscwd2027_starter'
def j(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    old=subprocess.run([sys.executable,str(ROOT/'tools/verify_evidence_v5.py')],capture_output=True,text=True)
    assert old.returncode==0,old.stderr
    for name in ['FROZEN_PROTOCOL_V6.json','FROZEN_PROTOCOL_V6_ADAPTER.json']:
        protocol=j(P/'docs'/name)
        for f,digest in protocol['code_sha256'].items():assert sha(P/f)==digest,f
    cfg=j(P/'docs/FROZEN_PROTOCOL_V6.json')
    assert sha(P/'literature/planner_source/fast-downward-24.06.1.tar.gz')==cfg['planner_archive_sha256']
    for name,digest in cfg['planner_source_sha256'].items():assert sha(P/'literature/planner_source'/Path(name).name)==digest
    generic=j(P/'runs/planner_v6/summary.json')
    assert generic['engine_runs']==40 and generic['all_plans_valid']
    assert generic['primary']['add_cost']==12 and generic['primary']['ff_cost']==8
    adapter=j(P/'runs/planner_adapter_v6/summary.json')
    rows=[json.loads(x) for x in (P/'runs/planner_adapter_v6/raw.jsonl').read_text().splitlines()]
    assert len(rows)==18 and adapter['remaining_state_probes']==4
    for row in rows:
        data=j(P/'runs/planner_adapter_v6'/row['case']/'input.json')
        assert sha(P/'runs/beam_main_v4'/row['case']/'instance.json')==data['source_instance_sha256']
        choices=dict(data['candidates']);q=data['common_cost']
        mask=sum(1<<i for i in row['removed']);assert mask in choices
        assert row['integer_plan_cost']==choices[mask]+q
        assert row['integer_additive_score']==choices[mask]+q*mask.bit_count()
        minimum_a=min(c+q*m.bit_count() for m,c in choices.items())
        minimum_u=min(c+q for m,c in choices.items())
        if row['method']=='add':assert row['integer_additive_score']==minimum_a
        else:assert row['integer_plan_cost']==minimum_u
        plan=(P/'runs/planner_adapter_v6'/row['case']/(row['method']+'.plan')).read_text()
        assert '(choose-%d'%mask in plan and '(materialize-common' in plan
    assert adapter['primary']['add_removed']==[1,3,5,6,7]
    assert adapter['primary']['union_removed']==[2,3,4,5,6,7]
    assert abs(adapter['primary']['charitable_integer_regret']-.21328688423449396)<1e-12
    result=dict(version=6,tests_expected=27,old_frozen_evidence_verified=True,
        planner_source_commit=cfg['planner_commit'],generic_engine_runs=40,adapter_engine_runs=22,
        total_engine_invocations=62,adapter_cases=6,all_delivered_adapter_costs_independently_verified=True,
        nearest_fulltext_review='Resolved using legally supplied institutional PDF; redistribution excluded',
        adoption_scope='Actual planner heuristic aggregation; controlled engineering cost adapter; no industrial deployment observation',
        verifier_sha256=sha(Path(__file__)))
    out=P/'runs/revision_evidence_v6';out.mkdir(exist_ok=True)
    (out/'summary.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
