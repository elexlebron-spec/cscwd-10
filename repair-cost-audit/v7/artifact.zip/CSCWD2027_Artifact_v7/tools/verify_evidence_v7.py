"""Read-only source/data checks followed by deterministic derived receipts."""
from pathlib import Path
import json,hashlib,subprocess,sys,math
R=Path(__file__).resolve().parents[1];P=R/'cscwd2027_starter';sys.path.insert(0,str(P))
from rework.core import Instance,Problem
from extensions.audit_v7 import integer_value
from extensions.beam_v4 import DELTAS

def read(p):return [json.loads(s) for s in p.read_text().splitlines()]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 old=subprocess.run([sys.executable,str(R/'tools/verify_evidence_v6.py')],capture_output=True,text=True);assert old.returncode==0,old.stderr
 cfg=json.loads((P/'docs/FROZEN_PROTOCOL_V7.json').read_text())
 for f,h in cfg['code_sha256'].items():assert sha(P/f)==h,f
 for f in ['baseline_v7','integer_v7','physics_v7']:assert json.loads((P/'runs'/f/'protocol.json').read_text())==cfg
 integers=read(P/'runs/integer_v7/integer_raw.jsonl');assert len(integers)==1350
 failures=[]
 for r in integers:
  f=P/'runs/structural_main_v3/instances'/(r['instance_id']+'.json');assert sha(f)==r['input_sha256'];ins=Instance.load(f);p=Problem(ins)
  for label,d in r['steps'].items():
   if d['removed'] is not None:
    assert p.feasible(d['removed'])
    for model in ['additive','union']:assert integer_value(ins,d['removed'],r['alpha'],model)==d[model+'_integer']
   if label.endswith('face') and d.get('certified'):assert d['additive_integer']==r['steps']['additive']['additive_integer']
  if not r['all_certified']:failures.append(dict(instance_id=r['instance_id'],alpha=r['alpha'],failed_steps=[k for k,d in r['steps'].items() if not d['certified']]))
 assert failures==[dict(instance_id='case_00267',alpha=1.,failed_steps=['union']),dict(instance_id='case_00421',alpha=10.,failed_steps=['union'])]
 layouts=read(P/'runs/physics_v7/physical_layouts.jsonl');assert len(layouts)==256 and {r['mask'] for r in layouts}==set(range(256))
 for r in layouts:
  volume=25+25/8*sum(DELTAS[i] for i in range(8) if i not in r['removed'])
  assert abs(r['physical']['volume']-volume)<1e-9 and r['checks']['valid']
  for field in ['relative_free_residual','reaction_balance_relative_error','energy_relative_error']:assert 0<=r['checks'][field]<1e-5
  assert math.isfinite(r['physical']['compliance']) and r['physical']['compliance']>0
 analysis=subprocess.run([sys.executable,str(R/'tools/analyze_v7.py')],capture_output=True,text=True);assert analysis.returncode==0,analysis.stderr
 s=json.loads((P/'runs/revision_evidence_v7/summary.json').read_text())
 assert s['baseline']['all_core_equal_union'] and s['baseline']['core_union_same_selected']==53
 assert s['components']=={'no_advantage':207,'pareto':120,'more_intent_less_work':64,'less_intent_more_work':57}
 assert s['paired_dependency']['complete']==178
 assert sum(r['union_physically_better'] for r in s['physics'])==12
 assert sum(r['union_physically_worse'] for r in s['physics'])==30
 result=dict(version=7,tests_expected=30,frozen_v3_to_v7_sources_verified=True,baseline_records=1134,baseline_max_objective_deviation=s['baseline']['max_objective_deviation'],integer_evaluations=1350,integer_strict_failures=failures,physical_layouts=256,weight_permutation_settings=96,weight_controls=6,dependency_pairs=178,source_and_data_checks_passed=True,verifier_sha256=sha(Path(__file__)))
 (P/'runs/revision_evidence_v7/verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
if __name__=='__main__':main()
