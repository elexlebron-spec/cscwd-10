"""Independent enumeration and descriptive analysis of the frozen v7 extension."""
from pathlib import Path
import json,csv,sys,statistics as st,random,hashlib
from collections import defaultdict,Counter
R=Path(__file__).resolve().parents[1];P=R/'cscwd2027_starter';sys.path.insert(0,str(P))
from rework.core import Instance,Problem
from rework.tie_study import normalized
from extensions.accounting_v5 import costs,residuals_disjoint

def read(p):return [json.loads(x) for x in p.read_text().splitlines()]
def csvout(p,rows):
 with p.open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def category(r,p):
 a=set(r['best_removed']);u=set(r['union_removed'])
 dl=sum(p.instance.losses[i] for i in u)-sum(p.instance.losses[i] for i in a)
 dw=sum(p.instance.work[k] for k in p.affected(u))-sum(p.instance.work[k] for k in p.affected(a))
 if r['best_regret']<=1e-8:label='no_advantage'
 elif dl<=1e-8 and dw<=1e-8:label='pareto'
 elif dl>1e-8:label='more_intent_less_work'
 else:label='less_intent_more_work'
 return dl,dw,label

def main():
 out=P/'runs/revision_evidence_v7';out.mkdir(exist_ok=True)
 baseline=read(P/'runs/baseline_v7/baseline_raw.jsonl');assert len(baseline)==1134
 groups=defaultdict(list)
 for r in baseline:groups[r['case'],r['model']].append(r)
 cases=[];maxerr=0.
 for case in sorted({r['case'] for r in baseline}):
  ins=Instance.load(P/'runs/beam_main_v4'/case/'instance.json');alpha=float(case.rsplit('_a',1)[1]);p=Problem(normalized(ins),alpha)
  feasible=[{i for i in range(8) if m>>i&1} for m in range(256) if p.feasible({i for i in range(8) if m>>i&1})]
  minima={'additive':min(p.cost(r,'additive') for r in feasible),'union':min(p.cost(r,'union') for r in feasible)};minima['core']=minima['union']
  info=dict(case=case,core_exact=residuals_disjoint(p.fp))
  for model in ['additive','core','union']:
   rows=groups[case,model];assert len(rows)==7
   for r in rows:
    assert p.feasible(r['removed']);assert abs(r['objective']-p.cost(r['removed'],'union'))<1e-12
    value=costs(r['removed'],p.instance.losses,p.instance.work,p.fp,alpha)[{'union':0,'additive':1,'core':2}[model]]
    err=value-minima[model];maxerr=max(maxerr,abs(err));assert abs(err)<=1e-8,(case,model,err)
   info[model+'_ms']=1000*st.median(r['seconds'] for r in rows)
   for key in ['objective','intent','work']:info[model+'_'+key]=st.median(r[key] for r in rows)
   info[model+'_removed']=';'.join(map(str,rows[0]['removed']))
  assert abs(info['core_objective']-info['union_objective'])<1e-8
  info['core_union_same_selection']=info['core_removed']==info['union_removed']
  cases.append(info)
 csvout(out/'baseline_cases.csv',cases)
 modelstats={m:dict(median_selection_ms=st.median(r[m+'_ms'] for r in cases),mean_selection_ms=st.mean(r[m+'_ms'] for r in cases)) for m in ['additive','core','union']}
 bs=dict(cases=54,records=1134,all_models_verified_by_enumeration=True,max_objective_deviation=maxerr,all_core_equal_union=True,core_union_same_selected=sum(r['core_union_same_selection'] for r in cases),modelstats=modelstats,
         core_over_union_median_case_ratio=st.median(r['core_ms']/r['union_ms'] for r in cases),
         core_over_additive_median_case_ratio=st.median(r['core_ms']/r['additive_ms'] for r in cases),primary_finest=[r for r in cases if r['case'].startswith('mesh2') and 'compliance_proxy_a1.0' in r['case']])
 old=read(P/'runs/structural_main_v3/raw.jsonl');primary=[r for r in old if r['alpha']==1. and r['all_certified']]
 component=[]
 for r in primary:
  ins=Instance.load(P/'runs/structural_main_v3/instances'/(r['instance_id']+'.json'));p=Problem(normalized(ins),1.)
  dl,dw,kind=category(r,p)
  component.append(dict(instance_id=r['instance_id'],family=r['family'],n=r['n'],control=r['sharing_control'],seed=r['seed'],regret=r['best_regret'],intent_delta=dl,work_delta=dw,category=kind))
 csvout(out/'components.csv',component)
 subgroup=[]
 for field in ['family','n','control']:
  for val in sorted({r[field] for r in component},key=str):
   rows=[r for r in component if r[field]==val]
   subgroup.append(dict(factor=field,value=val,certified=len(rows),positive=sum(r['regret']>1e-8 for r in rows),mean_regret=st.mean(r['regret'] for r in rows),median_regret=st.median(r['regret'] for r in rows),pareto=sum(r['category']=='pareto' for r in rows),tradeoff=sum(r['category'] in ['more_intent_less_work','less_intent_more_work'] for r in rows)))
 csvout(out/'subgroups.csv',subgroup)
 paired=defaultdict(dict)
 for r in old:
  if r['alpha']==1. and r['family']!='disjoint':paired[r['family'],r['n'],r['seed']][r['sharing_control']]=r
 pairs=[]
 for (family,n,seed),by in paired.items():
  low,high=by[.3],by[.7]
  li=Instance.load(P/'runs/structural_main_v3/instances'/(low['instance_id']+'.json'));hi=Instance.load(P/'runs/structural_main_v3/instances'/(high['instance_id']+'.json'))
  assert li.losses==hi.losses and li.work==hi.work and li.conflicts==hi.conflicts
  if low['all_certified'] and high['all_certified']:pairs.append(dict(family=family,n=n,seed=seed,low_regret=low['best_regret'],high_regret=high['best_regret'],delta=high['best_regret']-low['best_regret']))
 csvout(out/'dependency_pairs.csv',pairs)
 seedgroups=defaultdict(list)
 for r in pairs:seedgroups[r['seed']].append(r['delta'])
 rng=random.Random(202610287);means=[];seeds=sorted(seedgroups)
 for _ in range(2000):
  sample=[x for seed in rng.choices(seeds,k=len(seeds)) for x in seedgroups[seed]];means.append(st.mean(sample))
 means.sort();pairedstats=dict(possible=180,complete=len(pairs),inputs_preserve_cost_intent_conflicts=180,mean_delta=st.mean(r['delta'] for r in pairs),cluster95=[means[49],means[1949]],higher=sum(r['delta']>1e-8 for r in pairs),lower=sum(r['delta']<-1e-8 for r in pairs),equal=sum(abs(r['delta'])<=1e-8 for r in pairs))
 sc=read(P/'runs/baseline_v7/structural_core.jsonl');lookup={r['instance_id']:r for r in primary};scrows=[]
 for r in sc:
  if r['instance_id'] in lookup and r['certified']:
   ref=lookup[r['instance_id']];scrows.append(dict(instance_id=r['instance_id'],core_exact=r['core_exact'],core_regret=(r['objective']-ref['union_cost'])/ref['union_cost'],additive_charitable_regret=ref['best_regret']))
 csvout(out/'structural_core_cases.csv',scrows)
 scstats=dict(attempted=len(sc),solver_optimal=sum(r['certified'] for r in sc),matched_certified=len(scrows),residual_condition_true=sum(r['core_exact'] for r in scrows),positive_residual_regret=sum(r['core_regret']>1e-8 for r in scrows),mean_core_regret=st.mean(r['core_regret'] for r in scrows),mean_additive_charitable_regret=st.mean(r['additive_charitable_regret'] for r in scrows))
 integers=read(P/'runs/integer_v7/integer_raw.jsonl');assert len(integers)==1350
 intstats=[]
 for alpha in [.1,1.,10.]:
  rows=[r for r in integers if r['alpha']==alpha];valid=[r for r in rows if r['all_certified']]
  intstats.append(dict(alpha=alpha,attempted=len(rows),certified=len(valid),positive=sum(r['positive'] for r in valid),tie_sensitive=sum(r['tie_sensitive'] for r in valid),mean_regret=st.mean(r['best_regret'] for r in valid),old_certified_lost=sum(r['old_certified'] and not r['all_certified'] for r in rows),old_incomplete_now_certified=sum(not r['old_certified'] and r['all_certified'] for r in rows),max_regret_deviation=max(abs(r.get('old_regret_deviation',0.)) for r in valid)))
 physics=json.loads((P/'runs/physics_v7/selection.json').read_text());ph=[]
 for frac in [25,50,75]:
  rs=[r for r in physics if r['fraction']==frac and r['mode']=='permuted'];aligned=next(r for r in physics if r['fraction']==frac and r['mode']=='aligned');uniform=next(r for r in physics if r['fraction']==frac and r['mode']=='uniform')
  ph.append(dict(fraction=frac,permutations=len(rs),positive_objective=sum(r['charitable_objective_regret']>1e-8 for r in rs),union_physically_better=sum(r['physical_improvement_best_faces']>1e-8 for r in rs),union_physically_worse=sum(r['physical_improvement_best_faces']<-1e-8 for r in rs),physically_equal=sum(abs(r['physical_improvement_best_faces'])<=1e-8 for r in rs),mean_physical_improvement=st.mean(r['physical_improvement_best_faces'] for r in rs),aligned=aligned,uniform=uniform))
 summary=dict(baseline=bs,structural_core=scstats,integer_audit=intstats,subgroups=subgroup,components=dict(Counter(r['category'] for r in component)),paired_dependency=pairedstats,physics=ph)
 (out/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
