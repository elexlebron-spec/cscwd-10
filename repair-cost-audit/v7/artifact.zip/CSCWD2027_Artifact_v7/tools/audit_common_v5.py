"""Exploratory, fixed-scale intervention on every frozen beam configuration."""
import csv
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
PKG = ROOT / 'cscwd2027_starter'
sys.path.insert(0, str(PKG))
from extensions.accounting_v5 import common_core, costs, optimum_face, residuals_disjoint
from rework.core import Instance, Problem


def main():
    out = PKG / 'runs/common_audit_v5'
    if out.exists(): raise RuntimeError('Preserve existing audit')
    protocol = json.loads((PKG/'docs/FROZEN_PROTOCOL_V5.json').read_text())
    for name, digest in protocol['code_sha256'].items():
        path = ROOT/name[3:] if name.startswith('../') else PKG/name
        assert hashlib.sha256(path.read_bytes()).hexdigest() == digest
    out.mkdir()
    (out/'protocol.json').write_text(json.dumps(protocol, indent=2))
    rows=[]; case_rows=[]; witnesses=[]
    for path in sorted((PKG/'runs/beam_main_v4').glob('*/instance.json')):
        ins=Instance.load(path);p=Problem(ins)
        alpha=float(ins.metadata['alpha']) if 'alpha' in ins.metadata else None
        # Read the saved row; never infer preferences from the selected repair.
        record=next(json.loads(line) for line in (PKG/'runs/beam_main_v4/raw.jsonl').read_text().splitlines()
                    if json.loads(line)['case']==path.parent.name)
        alpha=record['alpha'];beta=alpha/sum(ins.work)
        losses=[x/sum(ins.losses) for x in ins.losses]
        core=common_core(p.fp); k=sum(ins.work[a] for a in core)
        assert residuals_disjoint(p.fp)
        feasible=[tuple(i for i in range(8) if mask>>i&1) for mask in range(256)
                  if p.feasible({i for i in range(8) if mask>>i&1})]
        assert all(feasible), 'All repairs must be nonempty for common-cost invariance'
        baseline=None; base_add=None; changes=0; max_regret=0.
        all_union_faces=[]; all_add_faces=[]
        for factor in protocol['core_multipliers']:
            work=[v*(factor if a in core else 1.) for a,v in enumerate(ins.work)]
            values=[(r,*costs(r,losses,work,p.fp,beta)) for r in feasible]
            u=optimum_face(values,1,1e-10);a=optimum_face(values,2,1e-10);c=optimum_face(values,3,1e-10)
            uf={r[0] for r in u};af={r[0] for r in a};cf={r[0] for r in c}
            assert uf==cf
            # Check every feasible score, not just its minimum.
            assert max(abs(r[1]-r[3]) for r in values)<1e-12
            if baseline is None:baseline=uf;base_add=af
            assert uf==baseline
            changed=not bool(af & base_add)
            changes+=changed
            gap=min(r[1] for r in a)-u[0][1]
            max_regret=max(max_regret,gap)
            rows.append(dict(case=path.parent.name,mesh=record['mesh_level'],fraction=record['fraction'],
                             mode=record['weight_mode'],alpha=alpha,core_multiplier=factor,
                             union_face='|'.join(';'.join(map(str,x)) for x in sorted(uf)),
                             additive_face='|'.join(';'.join(map(str,x)) for x in sorted(af)),
                             union_invariant=True,corrected_equals_union=True,
                             additive_disjoint_from_factor0=changed,absolute_charitable_gap=gap))
            all_union_faces.append(sorted(uf));all_add_faces.append(sorted(af))
        flipped=any(not(set(all_add_faces[0]) & set(face)) for face in all_add_faces[1:])
        case_rows.append(dict(case=path.parent.name,mode=record['weight_mode'],alpha=alpha,
                              union_invariant=True,corrected_equals_union=True,additive_flipped=flipped,
                              core_cost_fraction=k/sum(ins.work),maximum_absolute_gap=max_regret))
        if flipped:witnesses.append(dict(case=path.parent.name,core_multipliers=protocol['core_multipliers'],
                                         union_faces=all_union_faces,additive_faces=all_add_faces))
    assert len(case_rows)==54
    for name,data in [('interventions.csv',rows),('cases.csv',case_rows)]:
        with (out/name).open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
    summary=dict(settings=len(case_rows),interventions=len(rows),all_union_faces_invariant=True,
                 all_corrected_faces_equal_union=True,all_residuals_disjoint=True,
                 additive_face_disjoint_from_factor0=sum(r['additive_flipped'] for r in case_rows),
                 primary_settings=sum(r['mode']=='compliance_proxy' and r['alpha']==1 for r in case_rows),
                 primary_flipped=sum(r['additive_flipped'] for r in case_rows if r['mode']=='compliance_proxy' and r['alpha']==1),
                 uniform_flipped=sum(r['additive_flipped'] for r in case_rows if r['mode']=='uniform'),
                 protocol_sha256=hashlib.sha256((PKG/'docs/FROZEN_PROTOCOL_V5.json').read_bytes()).hexdigest(),
                 scope='Revision-stage mechanism audit on existing inputs; no new independent populations or timing claims')
    (out/'summary.json').write_text(json.dumps(summary,indent=2))
    (out/'witnesses.json').write_text(json.dumps(witnesses,indent=2))
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
