"""Inspect a rework Instance and report whether common-core correction is exact.

This utility does not infer an execution contract from a graph or certify human
preferences. It reports a structural sufficient condition that the caller must
connect to actual task traces.
"""
import argparse
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'cscwd2027_starter'))
from rework.core import Instance
from extensions.accounting_v5 import common_core,residuals_disjoint

parser=argparse.ArgumentParser()
parser.add_argument('instance',type=Path)
parser.add_argument('--alpha',type=float,default=1.)
args=parser.parse_args()
if args.alpha<0:parser.error('alpha must be nonnegative')
ins=Instance.load(args.instance);fp=ins.footprints();core=common_core(fp)
exact=residuals_disjoint(fp)
print(json.dumps(dict(
    instance=ins.name,common_tasks=sorted(core),
    common_cost_fraction=sum(ins.work[a] for a in core)/sum(ins.work),
    residuals_pairwise_disjoint=exact,common_core_correction_exact=exact,
    corrected_linear_coefficients=[ins.losses[i]/sum(ins.losses)+args.alpha*
                                   sum(ins.work[a] for a in fp[i]-core)/sum(ins.work)
                                   for i in range(len(ins.losses))] if exact else None,
    nonempty_batch_constant=args.alpha*sum(ins.work[a] for a in core)/sum(ins.work),
    conditions=['once per affected task per batch','fixed normalization and preference scale',
                'nonempty feasible repair for ignoring the constant','task identities validated against execution'],
    recommendation='Conventional edit-only hitting set is sufficient under the stated conditions' if exact
                   else 'Residual sharing remains; common-core correction alone is not exact'),indent=2))
