import unittest
from extensions.fixture_cost_v8 import partitions,group_cost,audit,ledger

IDS=['test_validation.py::test_mesh_a[.5]','test_validation.py::test_mesh_a[1.]','test_validation.py::test_mesh_b[.5]','test_validation.py::test_mesh_b[1.]']

class FixtureCostChecks(unittest.TestCase):
    def test_complete_partition_reference_and_scope_counts(self):
        self.assertEqual(len(partitions(IDS)),7);self.assertEqual(len(partitions(IDS,True)),3)
        for a,b in partitions(IDS):self.assertEqual(set(a)|set(b),set(IDS));self.assertFalse(set(a)&set(b))
        private=dict.fromkeys(IDS,1.);shared={'a':10.,'b':3.}
        self.assertEqual(group_cost(IDS,private,shared),17.)
        self.assertEqual(sum(group_cost(g,private,shared) for g in [IDS[:2],IDS[2:]]),17.)
    def test_scalar_file_does_not_determine_sharing(self):
        # Same standalone duration6 for every item; two hidden sharing worlds
        # require different optimal bipartitions. This is an information witness.
        labels=[(0,0,1,1),(0,1,0,1)];optimal=[]
        for mapping in labels:
            scores=[]
            for groups in partitions(list(range(4))):
                value=max(len(g)+5*len({mapping[i] for i in g}) for g in groups)
                scores.append((groups,value))
            best=min(v for g,v in scores);self.assertEqual(best,7)
            optimal.append({tuple(sorted(tuple(sorted(g)) for g in groups)) for groups,v in scores if v==best})
        self.assertFalse(optimal[0]&optimal[1])
    def test_fixture_ownership_changes_scalar_history_not_joint_ledger(self):
        private=dict.fromkeys(IDS,1.);shared={'a':10.,'b':3.}
        durations=dict(private);durations[IDS[0]]+=10;durations[IDS[2]]+=3
        traces=[dict(fixture_events=[dict(family='a',owner=IDS[0],seconds=10.),dict(family='b',owner=IDS[2],seconds=3.)])]
        p,s=ledger(durations,traces);self.assertEqual(p,private);self.assertEqual(s,shared)
        result=audit(IDS,durations,p,s);self.assertEqual(result['scope_optimum'],12.)
        self.assertGreater(result['charitable_regret'],0.)
