"""Reproduce a sourced scalar-duration interface with unchanged pytest-split.

Profiles and replay use real FE setup/validation; no sleep, padded loops, or
hand-edited duration files. The reporter's private project is not reproduced.
"""
import argparse,hashlib,importlib.metadata,json,os,platform,random,shutil,subprocess,sys,time
from pathlib import Path
import pytest_split
from pytest_split.algorithms import Algorithms
from .fixture_cost_v8 import ledger,audit,group_cost,family

ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def j(p):return json.loads(p.read_text())

class Node:
    def __init__(self,nodeid):self.nodeid=nodeid
    def __str__(self):return '<Function '+self.nodeid.split('::')[-1]+'>'

def session(directory,ids,label,extra=None):
    directory.mkdir(parents=True,exist_ok=True)
    for name in ['conftest.py','test_validation.py']:shutil.copy2(ROOT/'extensions/validation_suite_v8'/name,directory/name)
    env=os.environ.copy();env['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1';env['PYTHONPATH']=str(ROOT)
    env['CSCWD_V8_TRACE']=label+'.json'
    for name in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','VECLIB_MAXIMUM_THREADS']:env[name]='1'
    command=[sys.executable,'-m','pytest','--rootdir=.','-q','-p','pytest_split.plugin','--durations-path','.test_durations',*ids,*(extra or [])]
    start=time.perf_counter();r=subprocess.run(command,cwd=directory,env=env,capture_output=True,text=True,timeout=60)
    wall=time.perf_counter()-start;(directory/(label+'.log')).write_text(r.stdout+r.stderr)
    assert r.returncode==0,r.stdout+r.stderr
    trace=j(directory/(label+'.json'));assert trace['exitstatus']==0
    assert all(x['outcome']=='passed' for x in trace['reports'])
    trace.update(wall_seconds=wall,phase_seconds=sum(x['duration'] for x in trace['reports']),
                 fixture_seconds=sum(x['seconds'] for x in trace['fixture_events']),
                 command_template=['<PYTHON>',*command[1:]],fixture_count=len(trace['fixture_events']))
    (directory/(label+'.json')).write_text(json.dumps(trace,indent=2))
    return trace

def run(cfg,out):
    assert not out.exists();out.mkdir(parents=True)
    (out/'protocol.json').write_text(json.dumps(cfg,indent=2))
    versions={x:importlib.metadata.version(x) for x in ['pytest','pytest-split','numpy','scipy','scikit-fem','pluggy','packaging','iniconfig','pygments']}
    assert versions['pytest']=='8.4.2' and versions['pytest-split']=='0.11.0'
    upstream=Path(pytest_split.__file__).parent
    for name,h in cfg['upstream_source_sha256'].items():assert sha(upstream/name)==h
    (out/'environment.json').write_text(json.dumps(dict(versions=versions,platform=platform.platform(),python=sys.version,threads=1),indent=2))
    ids=cfg['nodeids'];session(out/'warmup',ids,'warmup')
    profiles=[]
    for repeat in range(cfg['profile_repeats']):
        contexts=['pooled_forward','pooled_reverse','isolated'];random.Random(8800+repeat).shuffle(contexts)
        for context in contexts:
            key=context+'_'+str(repeat);directory=out/'profiles'/key
            order=list(reversed(ids)) if context=='pooled_reverse' else list(ids)
            traces=[]
            if context=='isolated':
                for i,nodeid in enumerate(order):traces.append(session(directory,[nodeid],'part_%d'%i,['--store-durations']))
            else:traces.append(session(directory,order,'pooled',['--store-durations']))
            durations=j(directory/'.test_durations');assert set(durations)==set(ids)
            reports={n:sum(r['duration'] for t in traces for r in t['reports'] if r['nodeid']==n) for n in ids}
            assert max(abs(reports[n]-durations[n]) for n in ids)<1e-9
            private,shared=ledger(durations,traces);nodes=[Node(n) for n in order]
            plans={};certificates={}
            for algorithm in cfg['algorithms']:
                native=Algorithms[algorithm].value(2,nodes,durations)
                groups=[[n.nodeid for n in g.selected] for g in native]
                assert sorted(n for g in groups for n in g)==sorted(ids)
                plans['native_'+algorithm]=groups
                certificate=audit(order,durations,private,shared,algorithm=='duration_based_chunks',cfg['face_tolerance'])
                certificates[algorithm]=certificate
                plans['scope_'+algorithm]=certificate['scope_groups']
            record=dict(key=key,context=context,repeat=repeat,order=order,durations=durations,duration_file_sha256=sha(directory/'.test_durations'),
                private=private,shared=shared,fixture_events=[e for t in traces for e in t['fixture_events']],certificates=certificates,plans=plans)
            (directory/'planning.json').write_text(json.dumps(record,indent=2));profiles.append(record)
            print('Profile',key,flush=True)
    (out/'profiles.json').write_text(json.dumps(profiles,indent=2))
    # Independent execution uses only profile repeat0; other repeats check profile variability.
    tasks=[(p,m,rep,g) for p in profiles if p['repeat']==0 for m in p['plans'] for rep in range(cfg['replay_repeats']) for g in range(2)]
    random.Random(cfg['replay_seed']).shuffle(tasks);rows=[]
    with (out/'replay.jsonl').open('w') as log:
        for i,(p,method,repeat,g) in enumerate(tasks):
            directory=out/'replay'/p['key']/method/('r%d_g%d'%(repeat,g));directory.mkdir(parents=True)
            shutil.copy2(out/'profiles'/p['key']/'.test_durations',directory/'.test_durations')
            if method.startswith('native_'):
                algorithm=method.removeprefix('native_');options=['--splits','2','--group',str(g+1),'--splitting-algorithm',algorithm]
                trace=session(directory,p['order'],'trace',options)
            else:trace=session(directory,p['plans'][method][g],'trace')
            assert trace['selected']==p['plans'][method][g],(method,trace['selected'],p['plans'][method][g])
            assert sha(directory/'.test_durations')==p['duration_file_sha256']
            present={family(n) for n in trace['selected']}
            assert trace['fixture_count']==len(present)
            assert {e['family'] for e in trace['fixture_events']}==present
            row=dict(profile=p['key'],context=p['context'],method=method,repeat=repeat,group=g,
                selected=trace['selected'],fixture_count=trace['fixture_count'],phase_seconds=trace['phase_seconds'],
                fixture_seconds=trace['fixture_seconds'],wall_seconds=trace['wall_seconds'],
                scalar_estimate=sum(p['durations'][n] for n in trace['selected']),
                scope_estimate=group_cost(trace['selected'],p['private'],p['shared']))
            rows.append(row);log.write(json.dumps(row)+'\n');log.flush()
            if (i+1)%10==0:print('Replay',i+1,len(tasks),flush=True)
    result=dict(profiling_invocations=cfg['profile_repeats']*10,replay_invocations=len(rows),warmup_invocations=1,
        profile_inputs=len(profiles),all_tests_passed=True,all_native_partitions_match_unchanged_algorithm=True,
        all_durations_are_native_unedited_reports=True,scope='Actual supported scalar-duration planner and test executor; constructed physical validation workload; no access to reporting user project or industrial repair deployment')
    (out/'receipt.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);args=ap.parse_args()
    cfg=j(ROOT/'docs/FROZEN_PROTOCOL_V8.json')
    for name,h in cfg['code_sha256'].items():assert sha(ROOT/name)==h,name
    run(cfg,args.out)
if __name__=='__main__':main()
