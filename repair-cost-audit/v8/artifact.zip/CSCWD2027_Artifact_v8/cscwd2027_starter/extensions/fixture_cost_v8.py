"""Cost-interface checks for partitioned validation. No new optimizer claim."""
from itertools import combinations

def family(nodeid):
    if 'test_mesh_a[' in nodeid:return 'a'
    if 'test_mesh_b[' in nodeid:return 'b'
    raise ValueError(nodeid)

def partitions(items,contiguous=False):
    if contiguous:
        return [(tuple(items[:k]),tuple(items[k:])) for k in range(1,len(items))]
    # Unordered nonempty bipartitions: fix first item in the first group.
    result=[]
    for mask in range(1<<(len(items)-1)):
        first=(items[0],)+tuple(x for i,x in enumerate(items[1:]) if mask>>i&1)
        other=tuple(x for x in items if x not in first)
        if other:result.append((first,other))
    return result

def ledger(durations,traces):
    import statistics
    setups={f:[] for f in ['a','b']};owned={node:0. for node in durations}
    for trace in traces:
        for event in trace['fixture_events']:
            setups[event['family']].append(event['seconds'])
            owned[event['owner']]+=event['seconds']
    shared={f:statistics.median(samples) for f,samples in setups.items()}
    private={node:durations[node]-owned[node] for node in durations}
    assert min(private.values())>=-1e-9
    return {n:max(0.,v) for n,v in private.items()},shared

def group_cost(group,private,shared):
    return sum(private[n] for n in group)+sum(shared[f] for f in {family(n) for n in group})

def audit(items,durations,private,shared,contiguous=False,tolerance=1e-10):
    candidates=partitions(items,contiguous)
    rows=[(groups,max(sum(durations[n] for n in g) for g in groups),max(group_cost(g,private,shared) for g in groups)) for groups in candidates]
    additive=min(a for _,a,u in rows);union=min(u for _,a,u in rows)
    aface=[(g,u) for g,a,u in rows if abs(a-additive)<=tolerance]
    uface=[g for g,a,u in rows if abs(u-union)<=tolerance]
    best=min(u for _,u in aface)
    return dict(candidate_partitions=len(rows),scalar_optimum=additive,scope_optimum=union,
        charitable_regret=(best-union)/union,scalar_face_size=len(aface),
        scope_groups=[list(g) for g in min(uface)],
        scalar_groups=[list(g) for g in min(g for g,u in aface)],
        best_scalar_face_scope_cost=best)
