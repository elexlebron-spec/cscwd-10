"""Eight design-validation checks over four real service loads and two discretizations."""
import numpy as np
import pytest

def check(resource,multiplier):
    beam,values=resource;force=beam.force*multiplier
    u=np.zeros(beam.basis.N);u[beam.free]=values['a10'].solve(force[beam.free])
    K=values['a9'];residual=K@u-force
    assert np.linalg.norm(residual[beam.free])/np.linalg.norm(force[beam.free])<1e-5
    assert abs(float(u@(K@u))-float(force@u))/float(force@u)<1e-5
    assert np.allclose(u,multiplier*values['a11'],rtol=1e-9,atol=1e-12)
    y_fixed=np.intersect1d(beam.fixed,beam.y_dofs)
    assert abs(float(residual[y_fixed].sum())+float(force[beam.y_dofs].sum()))/(.025*multiplier)<1e-5

@pytest.mark.parametrize('multiplier',[.5,1.,1.5,2.])
def test_mesh_a(beam_a,multiplier):check(beam_a,multiplier)

@pytest.mark.parametrize('multiplier',[.5,1.,1.5,2.])
def test_mesh_b(beam_b,multiplier):check(beam_b,multiplier)
