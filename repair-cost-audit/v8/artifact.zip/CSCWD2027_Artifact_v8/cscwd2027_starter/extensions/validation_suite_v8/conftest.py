"""Observe native pytest reports and meaningful shared FE setup, without edits to pytest-split."""
import json,os,time
from pathlib import Path
import pytest
from extensions.beam_v4 import Beam

OWNER=None
TRACE=dict(fixture_events=[],reports=[],selected=[])

@pytest.hookimpl(tryfirst=True)
def pytest_runtest_setup(item):
    global OWNER
    OWNER=item.nodeid

def fixture(family,shape):
    started=time.perf_counter();beam=Beam(*shape);values,_,_,_=beam.build(set())
    TRACE['fixture_events'].append(dict(family=family,owner=OWNER,seconds=time.perf_counter()-started,mesh=list(shape),dofs=int(beam.basis.N)))
    return beam,values

@pytest.fixture(scope='session')
def beam_a():return fixture('a',(240,10))

@pytest.fixture(scope='session')
def beam_b():return fixture('b',(120,6))

def pytest_collection_finish(session):TRACE['selected']=[x.nodeid for x in session.items]

def pytest_runtest_logreport(report):
    TRACE['reports'].append(dict(nodeid=report.nodeid,when=report.when,duration=report.duration,outcome=report.outcome))

@pytest.hookimpl(trylast=True)
def pytest_sessionfinish(session,exitstatus):
    TRACE['exitstatus']=int(exitstatus)
    Path(os.environ.get('CSCWD_V8_TRACE','trace.json')).write_text(json.dumps(TRACE,indent=2))
